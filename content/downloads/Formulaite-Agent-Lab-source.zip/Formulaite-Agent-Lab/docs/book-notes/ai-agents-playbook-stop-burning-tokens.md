# Notes: *AI Agents Playbook: Stop Burning Tokens and Work Smarter* (Peter J. Kober) — agent infrastructure

Prose/config book for IDE-agent users; no Python. Infrastructure lives in rule files (`AGENTS.md`, `MANIFEST.md`, `SKILL.md`), MCP JSON configs, and iteration/budget guards. Each chapter's "Rules of Thumb & Token Saver Alerts" and "Pitfall to Avoid" are the densest parts.

## (a) The agent loop

- **Ch.1 §2 The Autonomous Agent Loop**: **PLAN → ACT → OBSERVE → CORRECT**; on failure loop back to PLAN "rather than returning a broken guess." Chatbot = single turn; agent = loop + tools + persistent workspace state.
- **Ch.1 §4 The "Quest" Pattern**: micro-tasks with a concrete objective, an explicit win condition, and a verifiable deliverable (`tasks/task-NNN.md` marked done).
- **Ch.4 §2 "Plan First, Execute Second"**: mandatory planning phase before any mutation; if 80% of thinking tokens go to clarifying the prompt, the rules are underspecified.
- **Ch.11 §1 The Verification Loop Architecture**: edit → run verification command → exit code 0? → else parse the *un-truncated* log → targeted fix; `max_iterations: 3`, then halt and report.

## (b) Tools / MCP

- **Ch.8 §2 Core MCP Primitives**: Tools (actions, schema + permission), Resources (read-only URIs), Prompts (templates). **Eager vs. Lazy-Loaded Tools**: eager ≈150 tokens/schema for core `read_file`/`write_file`; heavy schemas live in `<toolName>.json`, fetched via a `call_mcp_tool` dispatcher on demand (≈90% startup-context saving).
- **Ch.8 §2 Configuration**: `mcp.json` declares command/args; secrets as `${process.env.KEY}`; reject community servers whose tools "accept raw shell string arguments."
- **Ch.13 §2 Multi-Tier Fallback Trees**: live API → cached replica/CSV → emergency (search/schema reflection); backoff 2s→4s→8s on 429, honour `Retry-After`, cap at 3.
- **Ch.7 §2 Anatomy of a Skill**: `SKILL.md` = YAML frontmatter (`name`, `description` with trigger phrases) + body loaded only on trigger; optional `references/`, `scripts/`.

## (c) Memory / context

- **Ch.2 §2 Context Window Dynamics**: everything counts; "Lost in the Middle" → rules at top, live query + recent tool output at bottom; **Rule of 70% Capacity**. Pitfall **Phantom Memory Trap**: nothing outside the window or a file persists.
- **Ch.6 §2 MANIFEST.md Navigation**: core files indexed file-level; auto-incrementing dirs (`tasks/`, `.agents/history/`) directory-level so new files need no manifest edits.
- **Ch.12 §2 State Persistence & Checkpointing**: `tasks/task-NNN.md` holds milestones/blockers; **Resume Protocol** reads the latest task file, never the transcript.
- **Ch.14 §2 Trimming History Payloads**: replace growing history with a summary artifact so per-turn cost stays flat.
- **Ch.9 §2.2 Syntax Overhead Tax**: JSON +40–60%, YAML +35%, Markdown near baseline — store agent knowledge as Markdown with light frontmatter.

## (d) Validation / gates

- **Ch.11 §2 Prohibiting Superficial Symptom Patches**: ban swallowing exceptions, deleting assertions, dummy fallbacks, type suppression; never complete "based solely on file edits."
- **Ch.11 Testing Your AGENTS.md**: synthetic suites — rule-compliance, boundary-gate (halt for consent above a threshold), log-first.
- **Ch.15 §2 Mandatory Source Citation Rules**: every claim carries `file.md#L12-L24`; directive "state 'Information not found in workspace' rather than guessing"; **Fact-Checking Sub-Agent** re-checks quotes word-for-word.
- **Ch.16 §2 DLP Protocols**: human consent gate before `DROP`, `DELETE` w/o WHERE, `rm -rf`; show exact targets, wait.

## (e) Observability / evaluation

- **Ch.4 §2 Analyzing Reasoning Traces** and **Ch.13 §2 Log-First Rule**: read `<thought>` logs when output deviates; first action after any failure is reading stdout/stderr.
- **Appendix B §3–4**: metrics = Rule Adherence (regex/AST assertions), Faithfulness (LLM-as-judge), Token Efficiency Index, Cost Per Resolution; 20–50 case `evals/dataset.json`, `promptfoo eval`; merge a rule edit only if score rises and tokens grow <10%.

## (f) Multi-agent

- **Ch.10 §2 Diagnostic**: multi-agent only if payload >50K tokens, sub-tasks independent, or isolated permissions needed; "80% of production workflows are best solved by a single agent." Patterns: **Router/Supervisor** (ephemeral sub-agents return and terminate) and **Sequential Pipeline** (each stage reads only the prior artifact).
- **Ch.10 Context Handover & Payload Hygiene**: pass disk artifacts, never transcripts (a translation swarm drifted "stock options" into soup broth for $450). **Ch.2 Sub-Agent Hand-Off**: Tier 1 extractor writes Markdown excerpts; Tier 3 reads only those.

## (g) Security & failure modes

- **Ch.16 §2**: DLP, credential isolation (`process.env`, redact logs, `.gitignore` secrets), injection defence (sanitise fetched HTML, no write/shell tools for browsing agents, rule files outrank retrieved text).
- **Appendix F Rules 1 & 3**: filesystem servers scoped to subdirs, DBs read-only (`PRAGMA query_only = ON`), no wildcard approvals; wrap external content in `<DATA_PAYLOAD>` tags and hard-halt on "IGNORE PREVIOUS INSTRUCTIONS".
- **Ch.17 §3 Ten Most Common Agent Mistakes**: one-shot oracle, phantom memory, frontier-by-default, DeepThink waste, rule bloat (>100 lines), monolithic skills, unrestricted tools, commented-out assertions, swarm explosion. **Ch.13 §2 Transaction Safety**: `git checkout -- .` after a failed 3-try loop.

## (h) Token economy / cost control

- **Ch.2 §2 Asymmetric Pricing**: output 3–5× input; 50K prompt × 20 turns = $2.60 vs $0.05 trimmed. **Runaway Billing Spiral** → hard dashboard caps, `max_iterations`, prepaid buffers for unattended jobs, 50/75/90% budget webhooks.
- **Ch.3 §2 Three Tiers + Tier 1 Gatekeeper Pattern**: a cheap model classifies Routine vs Complex and routes ~80% away from frontier; tiers are "time-agnostic", tasks cascade downward over months.
- **Ch.4 §2 Mode Escalation**: Default → Search → Think → DeepThink; never default to DeepThink.
- **Ch.14 §2 Prompt Caching**: static rules first for prefix cache (≈90% off input); guardrails: max 15K input/query, default Tier 1, halt for sign-off if est. cost > $0.50; request terse JSON.
- **Ch.12 §2 Reactive Wakeup vs Active Polling**: anything >10s runs in background with a one-shot `schedule()` timer; 252 polling turns cost $45 vs $0.35.

## (i) Python constructs

None — "code" is Markdown rule files, JSON MCP configs, and one GitHub Actions YAML (**Ch.18 §2**).

## Best ideas to borrow for a small ingredient-research agent

- Versioned `AGENTS.md` (<100 lines) with citation format `source.md#L12-L24`, a "not found → say so" directive, and `max_iterations: 3`.
- Tier-1 gatekeeper: cheap model extracts ingredient snippets to Markdown; strong model synthesises only from those excerpts.
- Hand off between stages via disk artifacts (`data/<ingredient>-summary.md`), never transcripts; resume from `tasks/task-NNN.md`.
- Per-source fallback tree: live API → cached JSON → web search, with backoff and a 3-try cap, then halt with the raw log.
- Wrap fetched pages in `<DATA_PAYLOAD>` tags, keep the browsing step read-only, and put static rules first to hit the prompt cache.
