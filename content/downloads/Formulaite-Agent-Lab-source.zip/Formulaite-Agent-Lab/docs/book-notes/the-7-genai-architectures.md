# Notes: The 7 GenAI Architectures — agent infrastructure

Source: `/home/claude/lab/books-md/the-7-genai-architectures.md`. One incident-triage task built eight times with measured cost; architecture is "a cost ordering," not a maturity ladder.

## (a) The 7 architectures and the decision criteria

Headings: *Ch 2 "What a rung actually is", "The eight rungs", "The two boundary tests", "The Failure Receipt", "Building the diagnostic"*; *Appendix D*.

Level 0 deterministic code is "the floor, not a rung"; each level adds exactly one capability:

| Lvl | Architecture | Adds | Question that puts you here |
|---|---|---|---|
| 1 | Prompt Application | language understanding, one call | no test can specify the correct output |
| 2 | RAG | facts outside request and model | answer needs facts not in request/model |
| 3 | LLM Workflow | several calls in a sequence *you* control | one call can't do it, you can draw the steps |
| 4 | Tool-Using LLM | live data / actions with effects | a step needs live data or an action |
| 5 | Multi-Step Reasoning | model picks next step from last result, finite chain | next step depends on earlier results |
| 6 | Autonomous Agent | system decides when it is done | you cannot state a max call count up front |
| 7 | Multi-Agent System | roles with separate authority + handoffs | measurement shows specialists beat one system |

Criteria, all mechanical:
- **Floor Test**: can a unit test fully specify the output? If yes, no model.
- **Termination Test**: can you state the max model calls before the run? `max_iterations=10` fails it — "a capped loop is an unbounded loop with a circuit breaker." Tell: if hitting the cap means "we return what we have," it's L6.
- **Break-Even Test** (*Ch 10*): R = crew cost / agent cost; if the agent already scores above 1/R no crew can break even.
- **Failure Receipt**: to climb, show a reproducible input, the actual bad output, and a missing *capability* (not quality). "An unconvincing receipt is a result, not a formality."
- Diagnose top-down, per request type; `diagnose.py` uses a frozen `TaskProfile` whose fields are `bool | None` — `None` stops the review.

## (b) Agent loop / orchestration

Headings: *Ch 8 "The seam that holds the framework", "The step list is the architecture"*; *Ch 9 "The diff that changes the rung", "Wiring it up"*; *Ch 7 "Deep dive: why not just let it loop?"*.

- L4: no loop. One call picks tools, all run together, one call answers with a schema; refuse if no tools were requested.
- L5: `Chain.walk(nodes, initial, done)` over `Step(name, purpose)` roles (observe → localize → confirm); `MAX_MODEL_CALLS = 2 * len(STEPS)`. Early exit only shortens: "Down only is a chain. Up is a loop."
- L6: `while not done(state): state = node(state)`, with `done = state.finished or _bound(...) is not None` — "that lambda is the whole architecture."
- Stating the budget changes behaviour: told "one round," the model made 8.84 calls and never asked for more; told nothing, 4.13 calls and asked again 14/15 times. At L6 the prompt says there is no number.
- L7: investigator (read tools) → reviewer (no tools) → remediator (write tools, facts from a deterministic lookup); handoffs are objects; `blocked_at` names the refusing role.

## (c) Tool design

Headings: *Ch 7 "The Blast Radius Schema", "The menu is the boundary", "What breaks in production"*.

- `ToolSpec(name, description, parameters, consequence: Literal["read","write"])` — no default, stripped before serialisation; `menu_for()` filters on it; `blast_radius()` lists write tools; tests assert the default menu has none.
- `strict: True`; enums instead of free ints; no tool takes a timestamp — the caller binds the window. "Every field you leave out is a field a model cannot get wrong."
- Errors name what *is* available so the model corrects within the round; empty results are `is_error=False`; keep vendor exception messages.
- Separate tool timeout and budget from the model call; cache within a request; measure fan-out. Before any write tool: indistinguishable dry-run, out-of-band audit log, reversibility. Compute blast radius over tool *combinations*.

## (d) Memory & context

Headings: *Ch 8 "The Context Ratchet", "The carried state"*; *Ch 9 "Three memory layers", "Compaction is lossy"*.

- State only accumulates; carry conclusions, never raw results (a test asserts result bytes are not re-sent). Re-send the original input every step — dropping it is what kills the Downstream Veto.
- Three layers by lifetime: scratchpad (`AgentState`), journal (one frozen `Entry` per run — routed, cause, rounds, `stopped_by`, tools; "deliberately not a transcript"), recall (journal indexed lexically, excluding the same incident, on the *report* not the verdict).
- L6 keeps the last `CARRY_VERBATIM` findings in full, collapses older ones to their cause. Checkpoint resumption saved 23k tokens; re-invoking with input silently replays from zero.

## (e) Validation / gates

Headings: *Ch 4 (Format Illusion)*; *Ch 7 "The check that is new"*; *Ch 9 "The check that guarded the context blocked the only voluntary exit"*.

- "A schema validates the shape of a model's output and never its truth."
- Pydantic `Finding` with `evidence_tool` / `evidence_value` copied verbatim; `value_supported()` rejects values absent from any tool result ("roughly 19 percent" fails). At L5 it gates entry into carried state.
- Refuse, never default. `needs_human` + `next_step` means "not yet"; L6 adds `Verdict.unreachable` for "never" — checked **before** the citation gate, or every give-up is discarded.
- Reviewer's `quoted` must appear in what it was sent.

## (f) Observability & evaluation

Headings: *Ch 13 "Scoring surfaces", "A rate, not an assertion"*; *Ch 14 "The Instrumentation Level", "Building the record"*; *Ch 8 "Counters that are not one counter"*; *Ch 6 "The blame sink"*.

- Cost telemetry cannot represent a decision. Emit an `Event` with bounded dimensions (level, site, outcome, kind) plus payload; derive counters by group-by. L6's question: "how many rounds ran, and which bound stopped them?"
- A Scoring Surface is anywhere a claim can be wrong independently of the answer; L6 has six. Answer-only evals get *less* informative as you climb.
- Report `Rate(passes, n)` with a Wilson interval — 8/8 spans 0.68–1.00; no samples → "not measured," never 0.
- Separate counters: refusals by step, discarded findings, steps-used distribution; run endings = routed / gave up / bounded (which bound) / vendor failure.
- `MeteredCompleter(inner, ledger, stage=...)` bills per stage/role. Blame Sink: record `origin` as well as `reported_by`.

## (g) Reliability, security, failure modes

- **Refusal Premium** (*Ch 9*): failures run longest; 1.23× with a give-up field, 2.12× without — and without it, 3/5 runs ended as "the model asked for no tools," a refusal filed as a bug.
- `Budget(iterations=8, tokens=120_000, seconds=600.0)`; `_bound()` returns a string naming the bound. The deadline protects your backend; set it on the chain, decide in advance what a timeout returns.
- Tool rungs are read amplifiers against already-degraded infrastructure; quota on tokens, not requests.
- One loop has one menu, so write authority is held in every round: "a model behaving well is not a control." Split investigate/act by role menus (L7).
- Drift injection: 18/18 overruled a wrong claim; the structural fix (re-sending the report) did the work, the "claims may be wrong" sentence did nothing.

## (h) Python constructs

- `@dataclass(frozen=True)` for state/specs/budgets/events: `class Budget: iterations: int = 8; tokens: int = 120_000; seconds: float = 600.0`.
- `Protocol` seams: `class Completer(Protocol): def parse(self, *, system, user, schema: type[T], effort="low") -> Completion[T]: ...` plus `invoke(..., tools, execute, schema)`; `class Chain(Protocol): def walk(self, nodes, initial, *, done)`.
- `Node(Generic[State])` with `fn: Callable[[State], State]` and `__call__`; `Done = Callable[[Any], bool]`.
- Pydantic `BaseModel` + `Literal` + `Field(description=...)`; keyword-only args; `dataclasses.replace`; `statistics.NormalDist`; `measured(label, ledger)(fn)` wrapper.

## Best ideas to borrow for a small ingredient-research agent

- `consequence: Literal["read","write"]` on every tool, no default; menu filtered on it; test `blast_radius(menu) == ()`.
- Explicit `unreachable` give-up field, checked before validation gates; log which of rounds/tokens/seconds ended the run.
- Require `evidence_value` verbatim from a tool result and reject findings whose value is not a substring of any result.
- Carry conclusions plus a list of prior calls, never raw results; re-send the original question every round.
- Tool errors list valid options; empty results aren't errors; run the Termination Test — a fixed observe→localize→confirm chain may beat a loop at half the cost.
