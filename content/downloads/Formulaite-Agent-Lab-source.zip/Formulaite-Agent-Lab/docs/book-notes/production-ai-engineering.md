# Notes: Production AI Engineering — agent infrastructure

Source: `/home/claude/lab/books-md/production-ai-engineering.md` (Sterling Norwood). A 38-chapter operations manual with no runnable Python — boxes, arrows, formulas and checklists. Its value for agent work is the *control surfaces* it insists on.

## (a) Agents vs workflows vs other architectures

Headings: *Ch 4 "Choosing the Architecture" → "Managed model API", "Self-hosted inference", "RAG", "Event-driven processing", "Agentic architecture"*; *Ch 3 "AI Orchestration"*; *Ch 35 "Keep Deterministic Logic Outside the Model"*.

- Five patterns chosen by workload. Agentic is `[User] → [Orchestrator] → [Model] ↔ [Tools / Data]` and adds "unbounded loops, unexpected tool calls, high token consumption, long execution time, difficult debugging, side effects, and prompt-injection exposure." Hence agents "require explicit time, tool-call, model-call, and resource budgets."
- Workflows are the *asynchronous* shape (*Ch 10 "Multi-Step AI Workflows", "Durable Workflow State"*): dependent stages with a persisted state machine `CREATED → QUEUED → RUNNING → SUCCEEDED / FAILED → RETRYING → DEAD_LETTERED`, recoverable after worker failure.
- The orchestrator coordinates `[Retriever] / [Model Client] / [Tool Gateway] / [Output Validator]` but must not absorb them.
- "If a rule can be implemented reliably using conventional software, use conventional software." Never ask the model whether a user is authorised.

## (b) Agent loop / orchestration

No loop is shown; its envelope is specified. *Ch 4 "Resource Limits"*: budget = `Max Execution Time + Max Model Calls + Max Tool Calls + Max Token Budget`. *Ch 30 "7. Control agent loops"*: "a bounded operating envelope rather than unlimited autonomy." Long-running work goes behind a queue with a durable job ID, progress state and cancellation (*Ch 10 "Job Progress and State", "Cancellation"*).

## (c) Tool / function-calling design

Headings: *Ch 3 "Tools and External Actions"*; *Ch 12 "Tool Failures"*; *Ch 13 "Timeouts", "Retry Strategies", "Retries and Idempotency", "Circuit Breakers", "A Unified Failure-Handling Policy"*; *Ch 25 "Tool Manipulation"*; *Ch 26 "Human Approval", "Audit Trails", "The Secure Agent Execution Boundary"*.

- Gateway: `[Model] → [Tool Gateway] → [Validation] → [Authorization] → [Rate Limiting] → [Tool]` + audit log. "Capability must be granted explicitly rather than implicitly."
- Layered execution, one question per layer: schema (valid?), allowlist (permitted?), authorization (this caller?), parameters (valid args?), policy (permitted *now*?), risk, human approval. "Valid JSON does not mean valid authorization."
- The dangerous tool failure is `delete_transaction(...)` executing correctly when the user asked to *show* transactions — validate the **operation**, not syntax.
- Hierarchical timeouts from remaining budget: `User 30s → API 28s → Orchestrator 26s → Model 22s → Tool 8s`; `T_remaining = T_deadline − T_elapsed`. Separate connection / first-response / idle-read / overall deadlines.
- Retry policy defines max attempts, max elapsed, retryable classes, backoff `d = min(d_max, d0·2^n)`, full jitter, idempotency, cancellation, fallback. One layer owns retries (avoid `Client×3 → API×3 → SDK×3`). Side effects need an idempotency key.
- Circuit breaker CLOSED → OPEN → HALF-OPEN. Policy table: invalid request → fail; rate limit → backoff+jitter; 502/503 → retry within deadline; timeout → retry only if safe; safety violation → "do not blindly retry."
- Tool class → control: read-only (authz); low-impact write (authz+validation); external comms (confirmation); financial/destructive (approval + isolation). "Tool Authority ≤ Required Authority."
- Human approval binds to an *immutable action fingerprint* (exact tool + params), showing the action not the model's explanation.
- Audit fields: timestamp, request_id, user_id, agent_id, tool_name, action, resource, authorization_result, approval_id, execution_result, policy_version — append-only, trace-correlated.
- "The model proposes. The policy layer decides. The executor acts."

## (d) Memory & context management

Headings: *Ch 6 "Conversation History Is Not Memory", "Types of State and Memory", "Memory Summarization", "Memory Selection and Context Budgets", "Memory Failure Modes", "False Memory and Provenance", "Conflicting Memory"*; *Ch 5 "Context Construction"*; *Ch 22 "Context Growth"*.

- "Memory is a selected, derived representation... rather than an unlimited transcript." Short-term vs long-term vs user state vs application state, each with a named source of truth; the model must not become "an accidental database of record."
- Summaries are lossy: keep `[Raw History] + [Structured State] + [Summary]`. "Critical information should therefore not exist only inside an AI-generated summary."
- "More context ≠ better context." Chunks carry source/section/updated metadata, most relevant first; compression must itself be evaluated.
- Memory records need provenance (`user_explicit / application_state / tool_result / model_inference / imported_data`), confidence, `expires_at`, and an explicit conflict policy — don't hand the model contradictions to resolve.
- Failure table: wrong, missing, stale, conflicting, polluted, unauthorised, excessive, false, undeleted. Track token *distributions* (p50 2,100 can hide p99 17,900).

## (e) Validation / gates / structured output

Headings: *Ch 16 "Testing Structured Outputs", "Testing Tool Calling"*; *Ch 19 "Quality Gates", "Rollbacks"*; *Ch 25 "Jailbreaking and Instruction Conflicts"*.

- Pipeline `Valid JSON → Schema → Allowed values → Required fields → Business Logic`. "Structured output does not make the model deterministic. It makes the system boundary deterministic."
- Tool selection and tool execution are separate test problems; execution safety "must not depend on whether the LLM selected the tool."
- Instruction hierarchy (policy > app logic > model > output validation > authorization) is enforced by architecture. Release gates = deterministic tests + eval thresholds vs a versioned baseline + security checks; rollback targets include model, prompt, index, config.

## (f) Observability, tracing, evaluation

Headings: *Ch 20 "Distributed Tracing", "AI Events", "AI-Specific Telemetry"*; *Ch 18 "Agent Trajectory Testing", "Continuous Agent Evaluation"*; *Ch 21 "Hallucination Monitoring", "Sampling-Based Monitoring"*; *Ch 17 "LLM-as-a-Judge"*.

- Trace the *logical* execution (prompt assembly, context selection, parsing, tool decisions). Events: `request_received → retrieval_completed → model_called → tool_requested → tool_completed → response_validated → response_returned`.
- Per model call: request id, model+version, prompt version, latency, tokens, status, retries, fallback, and the call's role. Agent telemetry adds step count and context size.
- Trajectory tests check tool sequence, allowed tools, valid args, max steps, redundant ops, failure handling, termination, loop prevention — as **Must / May invariants**, not exact paths.
- Inject failures: tool timeout, invalid/empty/contradictory results, auth failure, rate limiting, partial success, outage.
- Metrics: avg/max steps, tool-call success, tool-selection accuracy, unauthorised attempts, loop frequency, completion rate, **cost per completed task** — "95% ... with twelve tool calls per task may be operationally worse than ... 93% with three."
- Hallucination = claims vs evidence (groundedness, unsupported-claim rate, citation validity/coverage); cheap heuristics on all, judge on a sample. Every production failure becomes a test.

## (g) Reliability, security, failure modes

Headings: *Ch 12 "Retry Storms", "Timeout Cascades"*; *Ch 13 "Graceful Degradation", "Retry Budgets"*; *Ch 15 "Token Budgeting Before Execution", "Token Amplification"*; *Ch 25 "Indirect Prompt Injection", "Defense-in-Depth"*; *Ch 26 "High-Risk Actions", "Production Security Checklist"*; *Ch 30 "10. Apply budgets"*.

- "Risk ≈ Influence × Authority × Impact" — injection is as dangerous as the tools behind it; "Retrieved content can be relevant without being trusted."
- Defense in depth: external content and tool outputs are untrusted; separate instructions from data; authorise and filter *before* building context; enforce authorisation outside the model.
- Action composition: `read email → extract link → login → change password` is high-impact though each tool is harmless — authorise sequences.
- Admission control: estimate input + output + expected tool tokens before calling; one request fans out to 6–10 internal ops, so limit those too. Budgets at request/user/tenant/feature/global; near a limit route cheaper, defer, reject or require approval.
- Degradation ladder: full → without private knowledge → cached → deterministic → explicit failure; a degraded system "must not behave as though it still has access."
- Retry storms become cost storms; retry budgets (`retry rate ≤ R_max`) and concurrency limits. Authority must be "explicit, bounded, observable, and revocable."

## (h) Python constructs

None — no Python code, classes, dataclasses, decorators, Protocols, async or Pydantic anywhere. Only prose, ASCII diagrams and formulas (`C_model = T_in/1M × P_in + T_out/1M × P_out`). Translate its gateway/policy/budget boxes into the constructs the other two books provide.

## Best ideas to borrow for a small ingredient-research agent

- One `Budget` (seconds, model calls, tool calls, tokens) with downstream timeouts derived from `T_deadline − T_elapsed`.
- A tiny gateway per tool call: schema → allowlist → parameter validation → risk class → (approval for writes) → execute → audit record with request_id.
- Tag every memory item with `source` and `expires_at`; a model inference never silently becomes a fact.
- Eval cases as Must/May trajectory invariants plus injected failures; track cost-per-completed-task next to accuracy.
- Emit `tool_requested` / `tool_completed` / `response_validated` events carrying prompt version, step count and tokens so a bad run is diagnosable from the record.
