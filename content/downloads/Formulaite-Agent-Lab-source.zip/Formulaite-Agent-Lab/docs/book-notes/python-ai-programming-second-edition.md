# Notes: Python AI Programming, Second Edition — agent infrastructure

Source: `/home/claude/lab/books-md/python-ai-programming-second-edition.md`. A "Daily Grind" coffee-shop assistant grows from one API call to a traced FastAPI service, using the raw Anthropic SDK, Pydantic, Chroma, MCP and OpenTelemetry — no agent frameworks.

## (a) Agents vs other architectures

Headings: *Prologue "My Nine Things I Believe About Building With AI"*; *Ch 11 "Limitations of Retrieval", "Risks of Reading and Acting"*; *Ch 1 "Why We Begin Without Them?"*.

- Belief six: "an agent is a loop. That's the whole secret... Fifteen lines. Anything else sold under that name is just packaging."
- Implicit ladder: prompt → RAG (Ch 6–7) → tools (Ch 11) → bounded loop → MCP server. Retrieval works "for anything written down and badly for everything else"; data that moves faster than the index (stock, loyalty balance, placing an order) needs a tool.
- Read and write tools are separated on day one: reads "run freely," writes need confirmation. Retrofitting "once twenty tools exist across three applications" is hard.
- Belief eight: "The refusal is the feature." Grounded prompts must name the fallback or the model invents one.

## (b) The agent loop

Heading: *Ch 11 "Agent Loop" → "Loop Handling Multiple Steps"*.

`act(question, max_steps=5)`: `for _ in range(max_steps)`: call `client.messages.create(..., tools=TOOLS, temperature=0.0)`; if `stop_reason != "tool_use"` return text; else append the assistant content, run each `tool_use` block, append a user turn of `tool_result` blocks keyed by `tool_use_id`. After the loop, return a hand-over-to-staff message. "Our code never decides which tool runs, in what order, or how many times." The step limit ships in the first version, "rather than after an incident."

## (c) Tool / function-calling design

Headings: *Ch 11 "Describing Tool to Model", "Running Tool and Returning Result", "Limits that Prevent Runaway", "Building Minimal Server"*; *Ch 2 "Handling Errors and Rate Limits"*.

- Tool = name, description ("when to use," written for the model), `input_schema` from `StockQuery.model_json_schema()` — Pydantic is the one source of truth.
- Registry: `HANDLERS = {"check_stock": check_stock, ...}`; `run_tool(name, arguments)` → `HANDLERS[name](**arguments)`.
- Hardened dispatcher returns text, never raises: unknown tool → `"No tool called X exists. Available tools are ..."`; bad args → catch `TypeError` and return the message. "A clear refusal returned as a result teaches it far more than a crash does."
- Results must carry the matching `tool_use_id`. Tool output is untrusted: "treat a result as data rather than as direction, keep results short."
- Log every tool call (name, args, duration) alongside the session.
- MCP: `@mcp.tool()` on a typed function; schema from annotations, description from the docstring (say *when* to use it). Client: `stdio_client` → `ClientSession` → `list_tools()` → one comprehension. Don't adopt MCP until a second client exists.
- Retries: distinguish `RateLimitError`/529 (retry) from 400 (never); `ask(messages, attempts=4, **options)` sleeps `2**attempt + random.random()`.

## (d) Memory & context

Headings: *Ch 4 "Keeping Conversation", "Deciding What to Drop", "Summarising Older Turns", "Saving and Restoring Sessions"*; *Ch 7 "Feeding Context to Model", "Raising Quality of Replies"*.

- `Conversation` class holds `customer_id`, `system`, `messages`; "the rest of our code never handles a raw message list again."
- `token_estimate()` via `client.messages.count_tokens`; `trim(limit=3000, keep=6)` drops oldest pairs — but loses an allergy stated first.
- `compact(keep=4)`: summarise older turns "keeping any stated allergy, preference, or pending order" and replace them with a synthetic pair. "Whatever the instruction omits will eventually vanish."
- JSON per customer with `save()` / `@classmethod load()`; store the minimum, delete when unneeded.
- RAG context: 3–5 passages, tune the distance threshold first and treat count as a ceiling; number passages `[n] source. passage` so citations are verifiable; a ~60-token rewrite step resolves pronouns before search; constraints go last in the prompt.

## (e) Validation / gates / structured output

Headings: *Ch 4 "Why Valid JSON is Not Enough?", "Constraining Values with Types and Enums", "Feeding Error Back to Model"*; *Ch 11 "Separating Safe Tools"*.

- Belief four: "Just because something is valid doesn't mean it's correct."
- `Order(BaseModel)` with `str, Enum` for `Size`/`Milk`, `quantity: int = Field(default=1, ge=1, le=20)`; `Field(description=...)` doubles as prompt text.
- Prefill `{`; `extract_order(sentence, attempts=3)` calls `Order.model_validate_json`, and on `ValidationError`/`JSONDecodeError` appends the bad reply plus the error as a correction turn; three failures → raise, caller decides.
- Write gate: `prepare_order()` returns a ticket into `PENDING`; `confirm_order(ticket)` does `PENDING.pop(ticket, None)` — idempotent, so a duplicate confirmation refuses. "Not a phrase the model can produce triggers the second step."

## (f) Observability, tracing, evaluation

Headings: *Ch 12 "Building Small Eval Set", "Scoring with Rules and Judge", "Tracking Quality Periodically"*; *Ch 13 "Tracing with OpenTelemetry", "Monitoring Cost, Latency, and Errors"*; *Ch 3 "Versioning Prompts"*.

- Prompts are source code: `PROMPT_VERSION = "recommendation-v2"`, old versions kept, version logged with every reply.
- `Case(BaseModel)`: `input, category, must_contain, must_avoid, expected_source, blocking=False`. `score_rules()` is free and deterministic; a `Verdict(BaseModel)` judge (reason + 1–5 tone/helpfulness/clarity) at temperature 0, fixed rubric, calibrated against 20 hand scores, using a *different, smaller* model.
- `run_evals.py` appends one JSONL line per run (date, prompt version, passed/total, blocked). Gate: no blocking failure, pass count may drop by at most one.
- OTel: parent span `respond`, children `retrieve`/`generate`; attributes are prompt version, question length, result count, best distance, model, tokens — numbers, never wording. Flush the provider in short scripts.
- `request_cost(usage)` from a `PRICE_PER_MILLION` table as a span attribute; watch the distribution. Four alerts: error rate, p95 latency, refusal rate, cost per request.

## (g) Reliability, security, failure modes

- Three limits per agent (*Ch 11*): step ceiling (5 — beyond that "indicates confusion rather than complexity"), steps + tokens recorded per request (>2-step average → fix tool descriptions), allowlist dispatcher.
- Injection via records (*Ch 12 "Records with Untrusted Content"*): records are material not direction; scan at ingestion and flag; keep a planted-instruction eval case.
- PII redaction (`privacy.py` regexes) before sessions, tool logs or eval output reach disk.
- Blocking allergen cases fail the release regardless of other scores.
- Batch work: `AsyncAnthropic` under `asyncio.Semaphore(8)` + `asyncio.gather`; interactive path stays sync (38.2s → 5.1s on 20 cases).

## (h) Python constructs

- Pydantic `BaseModel`, `Field(default=, ge=, le=, description=)`, `str, Enum`, `model_json_schema()`, `model_validate_json()`.
- `**options` forwarding: `def ask(messages, attempts=4, **options): return call_model(messages, **options)`; `HANDLERS[name](**arguments)`.
- Plain class + `@classmethod load(cls, customer_id)`; dict registries; `uuid` tickets; `re`.
- `async def` + `asyncio.Semaphore` + `asyncio.gather`; `async with stdio_client(...) as (read, write)`.
- `@mcp.tool() def check_stock(product_id: str) -> str: """Report ... Use whenever ..."""`.
- `with tracer.start_as_current_span("retrieve") as span: span.set_attribute(...)`.

## Best ideas to borrow for a small ingredient-research agent

- A ~15-line loop with `max_steps` from day one and a graceful hand-over message; log steps and tokens per request.
- A dispatcher that never raises: unknown tools or bad arguments come back as result text listing what *is* available.
- Pydantic validation with the `ValidationError` text fed back as a correction turn (3 attempts, then raise).
- Number every source `[n] source. passage`, require citations, verify each bracket maps to a supplied passage.
- A 20-case eval file (`must_contain` / `must_avoid` / `expected_source` / `blocking`) run as one command that appends a JSONL history line and gates release.
