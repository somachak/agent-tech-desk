# Notes: *Modern Loop Engineering for Agentic AI* (Dominic F. Hargrave) — agent infrastructure

Pure prose, no code or product names. Its value is a consistent vocabulary and a control-theory framing: "separation between intelligence and control" — the model proposes, engineered layers decide, verify, escalate. Headings cited are the `###` section headings in the file.

## (a) The agent loop

- **Core Concepts Behind Loop Engineering**: five stages — *observation → reasoning → action → evaluation → improvement*; "reliable intelligence emerges from well-designed feedback cycles." **Loop control** = checkpoints, limits, approval requirements, failure handling, so the agent never continues "indefinitely without assessing progress." Nest a fast operational loop inside a slow improvement loop.
- **Observation, Reasoning, Action, and Evaluation Cycles**: observation quality bounds decision quality; evaluation may be automated tests, external verification, human feedback, or predefined standards.
- **Closed-Loop Versus Open-Loop AI Systems**: open-loop for stable low-consequence tasks; closed-loop wherever the system manages uncertainty or affects important decisions.
- **Task Decomposition and Planning Strategies**: hierarchical, sequential, parallel, dynamic, *adaptive* ("periodic reassessment rather than treating the initial plan as permanently fixed"); attach risk and priority per subtask.
- **Managing Uncertainty and Ambiguous Objectives**: "recognize uncertainty instead of pretending to have complete confidence" — assess confidence, ask for clarification, define measurable outcomes.

## (b) Tools

- **Secure and Reliable Tool Usage** / **Secure Tool Usage and External System Access**: explicit authorization, granular permissions, validate tool inputs *and outputs*, rate limits, fallbacks when a service is down, human approval for financial/infrastructure/external-communication tools.
- **Execution Layers and Action Management**: execution layer = permission controls + validation + error handling + monitoring + recovery ("attempt alternative approaches").

## (c) Memory

- **…Short-Term and Long-Term Memory Architectures**: short-term = task-local (instructions, intermediate results, retrieved docs, unfinished state), discarded on completion; long-term split into *semantic* (facts/policies), *episodic* (past interactions), *procedural* (workflow templates). Load relevant long-term items at task start; promote new observations only if useful beyond the task.
- **Knowledge Retrieval and Context Management**: objective-driven retrieval, semantic over keyword, **context compression** by summarisation, freshness-aware and hierarchical context (hot facts immediate, details on demand).
- **Avoiding Memory Contamination and Knowledge Degradation**: validate before long-term storage, rank sources by confidence, hold uncertain info in *provisional* storage, prune, controlled vocabularies.
- **Managing Knowledge Updates and Information Accuracy**: provenance (origin, date, revision, validation status) on every item.

## (d) Validation / gates / self-reflection

- **Improving Agent Reasoning Accuracy and Decision Quality**: stepwise reasoning; verify before important actions (self-review, rule check, second system or human); compare independent reasoning paths; "knowing when not to act."
- **Error Detection, Recovery, and Self-Correction Mechanisms**: monitor → validate outputs → recover (retry, alternative, ask, hand to human) → self-correct by changing strategy/instructions, never unsupervised self-modification.
- **Establishing Policies, Controls, and Operational Boundaries**: input validation, output validation before external effects, workflow constraints "that cannot be bypassed by autonomous reasoning."
- **Human Feedback Integration and Human-in-the-Loop Systems**: put humans where judgment adds most value; too much oversight kills efficiency, too little kills reliability.

## (e) Observability, tracing, evaluation

- **Building Visibility into Agent Behavior**: observability explains *why*; capture intermediate decisions, retrieved knowledge, alternatives considered, retries; pick granularity deliberately.
- **Logging, Tracing, and Auditing Agent Activities**: logs = structured events (workflow start, retrieval, plan decision, tool invocation…) with timestamp, ids, agent identity; tracing links events into one execution path; auditing = tamper-resistant accountability records; minimise sensitive data; set retention.
- **Measuring Agent Performance and Effectiveness** / **Evaluating Reasoning Quality and Decision Outcomes**: completion rate, latency, accuracy, consistency, resource efficiency; plus objective alignment, logical consistency, evidence use, uncertainty handling, explainability; avoid metrics that reward bad behaviour.
- **Detecting Failures and Anomalous Behavior**: baselines; performance/behavioural/security anomalies; thresholds plus pattern analysis; root-cause analysis.
- **Agent Testing and Validation Methodologies**, **Simulation Environments**, **Testing Complex Agent Behaviors**: functional, behavioural (edge cases, conflicts), performance, safety; diverse simulated scenarios; dependency, boundary, regression tests; keep testing after deploy. Benchmarks must be repeatable and include cost.

## (f) Multi-agent / orchestration

- **Agent Coordination and Communication Patterns**: clear roles; direct comms for few agents, **centralised coordinator** as count grows, decentralised for resilience; standardised messages (objective, task id, priority, deadline, status, validation result); async over sync; conflicts resolved by priority/vote/supervisor; shared validated knowledge; trust-check received info.
- **Managing Dependencies Between Autonomous Agents**: sequential, resource, information, temporal dependencies; recovery paths so one failure doesn't kill the workflow. **Event-Driven Agent Architectures**: idle until events; persist events before processing; authenticate sources.
- **Monitoring and Controlling Long-Running Agent Operations**: progress indicators, health checks, **timeouts** on every operation, **checkpoints**, pause/resume/terminate, alerts, audit trail.
- **Multi-Agent Collaboration at Scale**: specialised roles (planner, retriever, executor, validator, monitor), delegation, shared situational awareness, graceful degradation.

## (g) Security & failure modes

- **Protecting Agents Against Prompt Injection and Manipulation**: separate instructions from data; validate retrieved content; **context isolation** (retrieved info "should not automatically gain authority over broader system behavior"); policy enforcement blocks violating actions "regardless of generated reasoning"; multi-stage validation; source-trust scoring; scan logs for override attempts.
- **Preventing Unauthorized Actions and Data Exposure** / **Managing Agent Permissions and Access Control**: per-action permission checks, data classification and minimisation, output filtering; each agent has an identity (RBAC/ABAC), minimum necessary access, separation of duties, temporary permissions that expire, audit trail linking actions to identity.
- **Preventing Feedback Drift and Uncontrolled Behavior**: drift = optimising rewarded-but-wrong signals; counter with monitoring, boundaries, audits, oversight.

## (h) Token economy / cost

- **Cost Optimization and Resource Governance**: classify workloads by latency/importance; avoid "unnecessary reasoning cycles, duplicate information retrieval"; cache frequent knowledge; quotas, budgets, cost allocation; retire unused agents/knowledge. No token-level arithmetic.

## (i) Python constructs

None; the book contains no code.

## Best ideas to borrow for a small ingredient-research agent

- Make each iteration explicitly five-stage and log the *evaluation* stage as its own event so "why did it stop/continue" is answerable.
- Keep a provisional-vs-validated split in memory: new ingredient claims sit in a staging list with provenance until a verification pass promotes them.
- Give each tool a read/write class and validate tool *outputs* (schema, sanity ranges) before they touch state, not only inputs.
- Put a timeout and a checkpoint on every stage so a crash or approval wait resumes instead of restarting.
- Treat web text as data with no authority: strip imperative instructions, score source trust, never let it alter tool permissions.
