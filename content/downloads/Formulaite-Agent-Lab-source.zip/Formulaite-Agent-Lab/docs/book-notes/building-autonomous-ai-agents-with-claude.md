# Notes: *Building Autonomous AI Agents with Claude AI* (Nolan Stark) — agent infrastructure

Prose-only design-principles book (no Python; one JSON snippet). Each chapter ends with KEY TAKEAWAYS + REVIEW CHECKLIST; Appendix A is a pre-deployment checklist, Appendix D maps task shapes to architectures.

## (a) Agent loop

- **Ch.2 Anatomy of a Single Loop Iteration**: reason → act → observe until a stop condition. Three named failure modes: *reasoning failure* (wrong action, executes fine), *acting failure* (right intent, malformed call), *observation failure* (result returned "truncated, mislabeled, or simply absent"). Debugging = locating which broke.
- **Ch.2 Where Extended Thinking Fits**: spend deep reasoning only on high-stakes × high-ambiguity steps; fix observation quality before adding thinking.
- **Ch.2 Knowing When the Loop Should Stop**: layer three families — goal-based (least reliable alone), resource-based ceiling ("non-negotiable infrastructure"), escalation-based. Check escalation *before* the ceiling fires; size ceilings per task category.
- **Ch.1 Deciding Whether a Task Actually Needs an Agent / App. D**: fixed sequence → workflow; few contingent points → workflow with judgment points; unknown step count → single loop; independent sub-problems → sub-agents.

## (b) Tools

- **Ch.3 A Tool Schema Is a Contract, Not a Suggestion**: the schema "is the entire interface"; vagueness yields "a confident, specific, and wrong" call. Describe outcome, each parameter's valid range and edge behaviour, and when to prefer it over neighbours. Example: `"query": {"type":"string","description":"Plain-text search terms, 2-8 words. Do not include field operators… An empty string returns the 10 most recent items instead of an error."}` Review schemas in code review.
- **Ch.3 Fewer, Clearer Tools Beat More, Overlapping Ones**: "almost right" calls are selection failures — consolidate or make descriptions mutually exclusive; run a pairwise overlap audit.
- **Ch.3 Narrow, Purpose-Built Tools and MCP**: prefer `look_up_order_by_id` over `run_sql`; wrap general tools in scope limits, dry-run, approval gates. MCP is worth it for *reuse*.
- **Ch.3 Testing Tools in Isolation**: call directly with edge inputs and deliberately trigger error paths; re-run periodically.
- **Ch.6 Not All Failures Deserve a Retry**: label every tool error *at definition time* as transient or deterministic so the loop never guesses from text.

## (c) Memory

- **Ch.5 Context Window Versus Memory**: context = curated working memory; memory = external store written deliberately "the moment it learns something durably useful." Split into *facts*, *decisions + rationale*, *open questions* for targeted retrieval.
- **Ch.5 Summarizing and Pruning**: summarize narrative freely; preserve verbatim IDs, numbers, error text in a key-facts table beside the summary. Re-summarize from raw, never summary-of-summary; keep raw history durable.
- **Ch.5 State Drift**: re-verify the specific state a consequential action depends on right before acting.
- **Ch.5 Long-Running Tasks and Resumption**: persist step status (verified / in-flight / not started); on resume re-verify in-flight steps; idempotent actions make this trivial.

## (d) Validation / gates / reflection

- **Ch.4 Breaking a Goal Into Steps the Agent Can Verify**: a step is small enough only when you can state its confirming evidence ("row count and a sample of ten records match"). Record each step's assumption and failure branch.
- **Ch.4 Plan-Then-Execute Versus Interleaved Planning**: hybrid — reviewable plan per phase, replanning within; phase boundaries at verifiable milestones.
- **Ch.4 When to Abandon a Plan Entirely**: escalating departures = premise failure; give the model explicit permission to return "needs re-decomposition" as a first-class outcome.
- **Ch.6 Recognizing Uncertainty and Degrading Gracefully**: ask for a confidence signal, route low confidence to escalation; report partial results as succeeded / failed-with-cause / never reached.

## (e) Observability / evaluation

- **Ch.2 Instrumentation as a First-Class Design Decision**: log reasoning, action, observation as separate artifacts per iteration with timestamp + id; tag by decision category. "Instrument for the failure you haven't seen yet."
- **Ch.8 Why Evaluating an Agent Is Not Like Evaluating an Answer**: outcome eval *and* trajectory eval (step count, tool-call error rate, retries), reported separately.
- **Ch.8 Building an Eval Set**: ≈40% real historical, 25% adversarial, 20% production failures folded back, 15% developer-authored; assign an owner; prune.
- **Ch.8 Regression Testing Without False Confidence**: run boundary cases repeatedly, track pass-rate history; deterministic checks stay single-run. **Human Baselines**: compare against a domain expert; study divergence pattern.
- **Ch.9 Observability**: leading indicators — median steps, retry rate, escalation-gate rate, approval override rate — with alerts; review a *weighted* trace sample. **Handling Model Upgrades**: rerun full suite before switching models.

## (f) Multi-agent

- **Ch.4 Delegation to Sub-Agents**: coordinator decomposes, dispatches, assembles — never solves. Only for independent sub-problems; if the coordinator mostly reconciles contradictions, collapse to one agent. Give sub-agents a scoped minimal view.

## (g) Security / failure modes

- **Ch.6 A Retry Strategy That Doesn't Retry Into a Worse State**: backoff + hard cap; idempotent via operation ids, else verify state before retry. **Cascading Failures and Circuit Breakers**: per-dependency breaker, cooldown sized to recovery time, every trip surfaced.
- **Ch.7 Least Privilege**: scope actions *and* data visibility to the current task; audit creep on scope change. **Placing Approval Gates**: by irreversibility, external impact, thresholds; show reasoning at the gate; watch reviewer fatigue. **Sandboxing / staged promotion**: sandbox → read-only → low-stakes write → gated write → unattended. **Auditing After the Fact**: log reasoning, permission scope, gate status, result.

## (h) Python constructs

None — language-agnostic. Implied structures: a per-iteration trace record (reasoning/action/observation/tag), an error category enum on each tool, a key-facts table beside the summary, and a step-status ledger. Map to dataclasses/enums yourself.

## Best ideas to borrow for a small ingredient-research agent

- Tag each tool error as transient/deterministic at definition; only transient enters backoff-retry, the rest escalates (Ch.6).
- Verbatim "key facts" table (CAS numbers, suppliers, exact errors, URLs) kept apart from the prose summary; never re-summarize a summary (Ch.5).
- Log each iteration as reasoning / action / observation + decision tag so a bad query and a bad parse are distinguishable (Ch.2).
- Three stop conditions together: sub-questions answered, hard search cap per ingredient, low-confidence escalation that fires before the cap (Ch.2, App. C).
- "Premise failed — needs re-decomposition" as a legal outcome; partial results reported in three buckets (Ch.4, Ch.6).
