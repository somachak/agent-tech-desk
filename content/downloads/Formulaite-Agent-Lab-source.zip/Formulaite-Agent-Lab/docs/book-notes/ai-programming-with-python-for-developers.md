# Notes: *AI Programming with Python for Developers* (Henry Bill) — agent infrastructure

Code-first (OpenAI Responses API, Pydantic, MCP Python SDK, Ollama). One thesis on every page: **"the model decides what it would like to do, while your application decides what it is actually allowed to do."** Citations are the `#####`/`######` headings in the file.

## (a) The agent loop

- **5.1 Build the Agent Execution Loop → Implement a Small Loop**: an agent is "a model connected to tools and a loop that gives the model another turn."
  ```python
  def run_agent(task, max_steps=8):
      messages=[{"role":"user","content":task}]
      for _ in range(max_steps):
          r=call_model(messages=messages, tools=TOOLS)
          if r.is_final: return r.text
          for tc in r.tool_calls:
              messages += [tc.as_message(), tc.result_message(execute_tool(tc.name, tc.arguments))]
      raise RuntimeError("Agent exceeded the maximum number of steps.")
  ```
- **Put a Limit on the Loop**: stop on final answer, max steps, tool budget, service down, approval needed, no progress — "application rules, not instructions… left to the model."
- **Detect Repeated Actions** / **8.5 Detect repeated tool calls**: `action_signature = (tool_call.name, tuple(sorted(tool_call.arguments.items())))`; repetition "should usually trigger a decision rather than an unconditional failure."
- **5.3 Build Multi-Step Agent Workflows**: when the path is known, Python owns the stage order (`WORKFLOW = ["research","analyze","verify","write"]`) and enforces dependencies (`can_analyze(state)`); a classifier picks a workflow from a fixed `routes` dict.
- **5.5 Adding controlled autonomy**: `AVAILABLE_ACTIONS = {"search","rewrite_query","ask_user","finish"}`; loop = `State → Model decision → Validate → Execute → Update state → Repeat`.

## (b) Tool / function-calling design

- **3.1 Designing AI Tools**: one job per tool; precise name/description/types ("as precise as an ordinary Python API"); enumerate allowed values in the schema; **Return Data, Not Conversation**; tool sits above a service layer (`Database → Repository → Tool → LLM`).
- **3.2 Define the Tool / Dispatch the Request Safely**: schema dict with `parameters`, `required`, `additionalProperties: False`; registry `TOOLS = {"get_order": get_order}`; `execute_tool` = `TOOLS.get(name)` → `json.loads(arguments)` → `tool(**parsed)`; never `eval`; reply via `function_call_output` + `call_id`; `MAX_TOOL_ROUNDS = 5`.
- **3.3 Handle External Failures Explicitly**: client with `timeout=10`, `raise_for_status()`, re-raise as `RuntimeError(...) from exc`; never "return a fake order… when the service could not provide the real data."
- **5.1 Handle Tool Failures Explicitly**: `execute_tool_safely` returns `{"error": "..."}` for `TimeoutError`/`ValueError`, logs unexpected exceptions, never forwards raw tracebacks to the model.
- **1.3 Configure Timeouts and Retries**: `OpenAI(timeout=30.0, max_retries=2)`; **5.3**: `RETRYABLE_ERRORS = (TimeoutError, ConnectionError)`, `MAX_RETRIES = 3`.
- **6.2 / 6.5 MCP**: `@mcp.tool()` / `@mcp.resource(...)` build schemas from annotations; client checks `result.is_error`, uses `structured_content`; registry `tool_clients = {"search_docs": docs_client}` maps a name to a server.

## (c) Memory

- **5.2 Keep Important State Explicit**: "Conversation history is context. Application state is data."
  ```python
  @dataclass
  class AgentState:
      task: str; summary: str = ""
      recent_messages: list[dict] = field(default_factory=list)
      findings: list[dict] = field(default_factory=list)
      completed_steps: list[str] = field(default_factory=list)
  ```
- **Do Not Keep Every Message Forever** / **2.3 Control Long Inputs**: summary + last N messages; `recent_messages(messages, limit=10)` as a predictable boundary.
- **Persist State When a Task Must Survive**: `runs` + `steps` tables; choose memory by lifetime (tool results temporary, progress until done, records stay in source systems); test: "what information will make the next decision better?" **5.3 Checkpoint Long-Running Work**: `save_state` after stages, `load_state(run_id)` to resume.

## (d) Validation / structured output / gates

- **2.2 Working with Structured Outputs**: Pydantic `SupportTicket(BaseModel)` + `client.responses.parse(text_format=...)`, then app-level `validate_ticket` against `VALID_PRIORITIES` — "instructions are not validation." **8.1**: `Field(ge=0.0, le=1.0)` tested with `pytest.raises`.
- **3.4 Restrict What Each Tool Can Do**: `TOOL_PERMISSIONS = {"get_order":"READ", "delete_order":"DESTRUCTIVE"}` + `authorize_tool()`. **Require Approval for High-Risk Actions**: `user_approved` comes from trusted code, never the model. **Put Limits Around Execution**: `MAX_TOOL_CALLS=8`, `MAX_TOOL_ARGUMENT_SIZE=10_000`, `TOOL_TIMEOUT_SECONDS=10`.
- **5.3 Pause for Human Approval**: `state.status = "waiting_for_approval"; save_state(state); return` — no worker stays alive while waiting.
- **5.5 Verifying important claims**: each finding becomes a retrieval query; "Finding a document containing similar words does not prove that the claim is correct."

## (e) Observability, tracing, evaluation

- **8.3 Trace and Debug**: `request_id = str(uuid.uuid4())` on every event; structured `logger.info("tool_call", extra={...})`; record model, token counts, per-component latency, status; minimal `@dataclass Trace` with `record(self, name, **data)`; redact args; graduate to trace-id/spans later. **5.1 Record What Happened**: step records `{step, action, arguments, result}`.
- **8.1 Test AI Components**: "do not make a real model call when an ordinary software test can answer the question"; `FakeLLM`, `FailingTool`; test agent *paths* (`assert "search_docs" in result.tool_calls`); many unit + few integration + small eval set.
- **8.2 Evaluate AI Quality**: `evals/dataset.json` with `expected_sources` / `expected_tools`; `recall_at_k`; groundedness; citation-source-exists check; tool-argument checks; step counts; `run_evaluation` runner; compare versions with config recorded; include unanswerable cases.

## (f) Multi-agent / orchestration

- **5.4 Build and Coordinate Multiple Agents**: Research / Analysis / Verification / Execution agents with minimal tool sets; **Put a Coordinator in Charge** (`run_research_task` calls each in order); **handoffs** when ownership should move; **Pass Only the Information Each Agent Needs** (`research_result = {"sources":..., "key_findings":...}`); typed `WorkflowState` dataclass instead of `shared_state = {}`; **Evaluate Agents by Their Individual Jobs**; "Keep the System Smaller Than It Looks."

## (g) Security & failure modes

- **3.4 / 8.4 Secure AI Applications**: model is untrusted; least privilege; `ALLOWED_TOOLS` + `check_tool_allowed`; never `eval`/`exec`; `safe_path()` via `Path.resolve()` against `PROJECT_ROOT`; keep system/policy/user/retrieved/tool-result layers separate; **Protect Retrieved Data** — authorisation filter *before* retrieval; secrets via `os.environ`, never in tool args (**6.4 Keep secrets on the server**); MCP `readOnlyHint` etc. are hints, not authorization; adversarial tests. "A successful prompt injection should not automatically become a successful security breach."

## (h) Token economy / cost

- **8.5 Optimize Cost and Performance**: Measure → bottleneck → change one thing → re-run evals; `retrieve(limit=5)`; cache by `hash((model, prompt))` and `chunk hash + embedding model`; fix retrieval before upsizing the model; rule-based **model routing** (classification → small, planning → large); `max_tokens`; `MAX_REQUEST_COST = 0.05`, `MAX_DAILY_COST = 20.00`; a **performance budget** (retrieval <300 ms, ≤8 steps, ≤12K context).

## (i) Python constructs the book leans on

- **dataclasses** — `@dataclass class ResearchState` (5.5); `@dataclass(frozen=True) class ModelConfig` (7.2).
- **Protocol** — `class LLM(Protocol): def generate(self, prompt: str) -> str: ...` (7.2 Keep the provider behind an interface) → swap Ollama/fake/hosted.
- ***args/**kwargs** — `tool(**parsed_arguments)` (3.2); `FailingTool.execute(self, *args, **kwargs)` (8.1); `Trace.record(self, name, **data)` (8.3).
- **decorators** — `@mcp.tool()`, `@mcp.resource(...)`, `@mcp.prompt()` (6.1–6.2); `@pytest.mark.anyio` (6.5).
- **generators** — `def stream(self, prompt) -> Iterator[str]: … yield text` (7.2 Handle streaming at the model boundary).
- **async** — `async with Client(docs_mcp) as client: await client.call_tool(...)` (6.3/6.5); `async with asyncio.timeout(10)` (6.4).
- **exceptions** — `raise RuntimeError(...) from exc` boundary (1.3); `PermissionError` for authorization.

## Best ideas to borrow for a small ingredient-research agent

- Copy the `run_agent` loop shape: `max_steps`, a `TOOLS` dict dispatcher, and `execute_tool_safely` returning `{"error": ...}` instead of tracebacks.
- Hold `ResearchState` (sources, findings, verified_claims, steps_completed, status) as a dataclass and checkpoint after each stage; keep conversation history separate.
- Fix the stage order in Python (`collect → analyze → verify → write`); let the model choose only among `{"search","rewrite_query","ask_user","finish"}`.
- Ship `evals/dataset.json` with `expected_sources` per ingredient question; run `recall_at_k` + citation-exists checks after every prompt/model change.
- Give every run a `request_id` and a `Trace.record()` per retrieval/model/tool call with token counts and ms, plus a `MAX_REQUEST_COST` guard.
