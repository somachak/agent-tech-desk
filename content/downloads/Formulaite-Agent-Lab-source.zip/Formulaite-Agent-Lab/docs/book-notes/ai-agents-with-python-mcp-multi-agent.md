# Notes: *AI Agents with Python* (Williams Moses) — agent infrastructure

Beginner-level; OpenAI Responses API + FastMCP. Almost no classes — plain functions, dicts, lists and ASCII flow diagrams. Value is in the workflow *shapes*, not the code.

## (a) Agent loop

- **1.2 Understanding the Agent Loop**: Goal → analyze → decide → execute → observe → "goal complete?" → repeat; "It does not stop after producing a single response." Sketch: `while not goal_completed: action=...; execute; observe; goal_completed=check()`.
- **6.1 Think → Plan → Act → Observe Cycle** is the canonical loop. **Deciding When the Agent Should Stop**: task done, single-answer request, tool can't complete, max steps. `def reasoning_loop(task, max_steps=5): for step in range(max_steps): ...; return "Maximum reasoning steps reached."`
- **6.1 Integrating Prompts, Tools, and Memory**: per turn — load conversation memory → load long-term memory → build prompt → plan → "does a tool help?" → execute → observe → update memory. **Building a Reusable Reasoning Engine**: keep the engine fixed, vary only tools.

## (b) Tools / function calling

- **4.1 Why the Model Does Not Execute Functions**: model emits a *request*; app decides to execute, reject, confirm, log or error — "one of the most important safety features."
- **4.2 Creating a Tool Schema in Python**: dict with `name`, `description`, `parameters.properties` (type + description each), `required`. **Why Descriptions Matter**: matching is on descriptions, not names. **Keep Each Tool Focused**: no `manage_everything()`. **Designing Better Tool Schemas**: 5-question checklist ("Would another developer understand the schema without reading the source?").
- **4.3 A Consistent Workflow**: receive → validate input → call service → check errors → extract needed fields → return structured result; `requests.get(url, timeout=10); raise_for_status()`.
- **4.4 Why Structured Errors Matter**: uniform envelope `{"success": bool, "data": ..., "message": ""}`. **Retrying Temporary Failures**: `for attempt in range(retries): try ... except RequestException: time.sleep(2)`. **Avoid Endless Retry Loops**: fix max retries, wait, *which* errors retry; never retry bad input or auth failures.
- **7.2 Registering Your First Tool**: `@mcp.tool()\ndef greet(name: str) -> str: """Return a greeting."""` — typed, docstringed function becomes discoverable. **Returning Structured Responses**: return `dict`. **7.3 Discovering Available Tools**: `client.list_tools()`; wrap `call_tool` in `try/except TimeoutError`.

## (c) Memory

- **5.1 Storing Messages**: list of `{"role","content"}`; "the memory belongs to your application—not the model." **Keeping Only What Matters**: drop old turns or replace with a bullet summary + recent messages.
- **5.2 Saving Memory Permanently**: SQLite `user_memory(user_id, key, value)`; inject stored facts into the system prompt. **What Should Not Be Stored?**: transient requests.
- **5.3 Building a Retrieval Pipeline**: chunk → embed → vector store → retrieve → prompt; "Retrieve only the most relevant passages."
- **6.2 Tracking the Current Task**: workflow state `{"task","status","current_step","completed_steps"}` separate from conversation state; **Resuming a Workflow After Failure** — persist completed steps.

## (d) Validation / structured output / reflection

- **3.3 Describing the Expected Format**: "Return only valid JSON. Do not include explanations, comments, or Markdown." `json.loads` + required-field loop.
- **3.4 Self-Reflection and Output Validation**: model self-review (fields, formats, no unsupported claims) *then* app rules — "Never rely entirely on the model to verify its own work." **Adding Type Validation**: `isinstance`.
- **3.5 Step 6: Retry When Necessary**: `for attempt in range(MAX_RETRIES): ... else: raise RuntimeError(...)`.
- **6.3 Detecting Incomplete/Inconsistent Outputs**: length heuristic, contradictions, conflicting tool outputs. **Balancing Accuracy and Execution Cost**: no reflection for trivial, one pass normal, several for high-risk. Reflection isolated in `reflect(request, response)` so a rule can become an LLM judge.
- **5.4 Building a Planning Loop**: plan as list; execute one step, evaluate, revise; retry only the failed step.

## (e) Observability / evaluation

- **6.4 Building a Debug Logger**: `log_event(event, message)` → `[TOOL] ...`; **Tracing Tool Calls**: which tool, why, input, output.
- **8.2 Logging and Tracing Agent Behavior**: prompts, tool I/O, responses, errors, `time.time()` latency, `response.usage.input_tokens`; **Creating Structured Logs** as dicts. "The final response tells you what happened but rarely why."
- **8.1**: task completion rate, tool-selection accuracy, hallucination rate, latency.
- **8.3 Building Automated Evaluation Pipelines**: fixed `evaluation_set`; batch `evaluate(prompts)`; A/B prompts and models on identical inputs; **Regression Testing** vs baseline; **Automatic Scoring** + **Human Review Workflows** for low confidence.
- **8.4 Monitoring Cache Hit Rate**: cache repeated requests.

## (f) Multi-agent

- **7.4 Common Agent Roles**: Planner, Researcher, Analyst, Writer, Reviewer. **Communication Patterns**: sequential, parallel, manager–worker, planner–executor. **Passing Tasks Between Agents**: small structured dicts, not transcripts. **Avoiding Infinite Loops**: `MAX_REVISIONS = 3`.
- **7.5 Step 2**: `run_agent(role, task)` — one function, different `instructions`; pipeline plan → research → analysis → report → review.
- **6.5 Research assistant**: topic → sub-questions → search each → `remove_duplicates` (seen-set) → `review_results` gate (≥3) → report with `source` per finding → save. Conflicts flagged, not ignored. **10.1 Summarizing and Citing Results**: keep `{"source","summary"}` pairs.

## (g) Security / failure modes

- **9.1 Treat Retrieved Content as Untrusted**: separate `instructions` field from content; `validate_document()` phrase blocklist; no secrets in prompts.
- **9.2 Restricting Tool Access**: `permissions = {"support_agent": ["read_customer"]}` + `has_permission(agent, tool)`; **Safe File Operations** from a trusted `Path("reports")` root; **Rate Limiting**.
- **9.3 Pausing Before Sensitive Actions**: `request_approval(action)`; **Escalating Uncertain Responses**: `if confidence < 0.80: escalate`; **Handling Failures Safely**: stop rather than "attempting increasingly risky actions."

## (h) Python constructs

Plain functions + dicts/lists for state, plans, logs. `@mcp.tool()` decorator on annotated functions (7.2). `**kwargs` dispatch: `class MCPClient: def request_tool(self, tool_name, **kwargs)` (7.1) — the only class. `try/except` with structured returns, `for/else` retry, `logging.basicConfig`, `pathlib`, `sqlite3`, `os.getenv`. No dataclasses, Protocols, generators or async.

## Best ideas to borrow for a small ingredient-research agent

- Uniform tool envelope `{"success","data","message"}` plus a retry helper that only retries transient errors (4.4).
- Sub-question fan-out → seen-set dedupe → `review_results` gate that triggers more searches before writing (6.5).
- Every finding paired with its `source`; report generator iterates findings, never free text (10.1).
- Fetched pages are untrusted data: separate instructions field, blocklist scan, least-privilege tool table (9.1, 9.2).
- `log_event(tag, msg)` trace and a fixed 10-prompt eval set rerun after each prompt change (6.4, 8.3).
