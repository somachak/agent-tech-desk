# Notes: *Learn AI Agents by Building Real Applications* (Kitchen to Code) — agent infrastructure

Project-driven; OpenAI Responses API + Pydantic + Pandas. Every chapter runs Build → Break It → Fix It → Production Check; the Break/Fix sections hold the best material. Mantra: **"Model proposes. Application executes."** Appendix B lists eight reusable patterns, Appendix C a readiness checklist.

## (a) Agent loop

- **Ch.1 The Smallest Useful Agent Loop**: goal → understand → choose an *allowed* action → perform → observe → "need more work?" → finish or ask a human. **Five Ingredients**: goal, context, decisions, actions, stopping condition.
- **Ch.2 Build the Application (Steps 1–7)**: reference engine — `create_state(goal)` → `{"goal","status","steps","history","result"}`; `decide_next_action(state)`; `execute_action` looks up an approved `tools` dict; `record_observation`; `should_stop` sets `needs_input` / `waiting_for_approval` / `step_limit_reached` (≥3) / `completed`; `run_agent` = `while state["status"] == "running"`. "Safety mechanisms are easier to design before they become emergency fixes." **Fix It**: `validate_goal()` before the loop.
- **Ch.5 The Tool-Calling Loop**: model requests → Python validates → executes → `function_call_output` with `call_id` → final answer (single round).
- **Ch.15 Step 13 Build the Orchestrator**: planner returns `clarify` / `unsupported` / capability; orchestrator branches, authorizes, persists — "small, testable branches."

## (b) Tools

- **Ch.5 Step 2 Describe the Tool**: JSON schema with `"additionalProperties": False, "strict": True`. **Tool Selection Is a Design Problem**: "Gets information." vs "Look up an approved company profile by company name. Use this when…".
- **Ch.5 Fix It: Build a Controlled Dispatcher**: single `execute_tool(name, arguments)` enforcement point; re-validates args; unknown name → `{"ok": False, "error": "Tool is not allowed"}`.
- **Ch.6 Step 6 Turn the API Call into an Agent Tool**: range-check input, `requests.get(url, timeout=10)`, separate `except` for `Timeout` / `HTTPError` / `RequestException` / `JSONDecodeError`, each a small controlled observation — no traceback "into the model context." **Fix It** chain: validate name → args → permission → call with timeout → check HTTP → parse → controlled observation.
- **Ch.6 Retries Without Making Things Worse**: GETs retry safely; before retrying a write ask if attempt one succeeded; "retries need policy… never an uncontrolled `while True`."
- **Ch.9 Step 3/5**: model picks from `Literal[...]` including `"unsupported"` (later `"clarify"` + `clarification_question`); `ANALYSIS_TOOLS = {name: fn}` registry dispatch.
- **Ch.13 Attack 2**: `validate_refund_arguments` — set-difference for missing keys, type/sign checks; "Tool selection and argument authorization are separate checks."

## (c) Memory

- **Ch.10 Step 1 Define Explicit Workflow State**: `class ResearchTask(BaseModel)` with `task_id`, `status: Literal["created","researching","waiting_for_review","approved","completed","failed"]`, `findings: list[str] = Field(default_factory=list)`. **Steps 3–5**: `save_task` writes `model_dump()` JSON; `load_task` re-validates with `model_validate`; `ALLOWED_TRANSITIONS` dict-of-sets guards `change_status`.
- **Ch.10 Conversation Context Is Not a Database**: store approvals, status, findings explicitly. **What Should an Agent Remember?** / **Memory Needs an Expiration Policy**.
- **Ch.7 Steps 3–9 (RAG)**: paragraph chunks, `text-embedding-3-small`, hand-rolled cosine, `retrieve_chunks(question, chunks, top_k=3)` with a `source` label per chunk (`policy.txt#chunk-3`); **Step 8 Inspect Retrieval Before Asking the Model** — "Diagnose retrieval first."
- **Ch.8 Step 6 Create an Evidence Package**: Pandas computes; `json.dumps(analysis)` is the calculation/explanation boundary.

## (d) Validation / structured output / gates

- **Ch.4 The Schema Is a Contract**: `class ResearchBrief(BaseModel)` with `confidence: Literal["low","medium","high"]`; `client.responses.parse(..., text_format=ResearchBrief).output_parsed`. "Structured output does not make an answer true. It makes the shape predictable." **Fix It**: `validate_brief()` business rules after schema. **A Better Mental Model**: input check → model → schema → app validation → trusted next step.
- **Ch.4 Should We Retry?**: "repeating the same request three times does not create the missing information."
- **Ch.9 Fix It**: layered failure — bad data at load, unsupported at planning, unknown tool at dispatch, empty result at validation; "fails closer to the real problem." **Clarification Is an Agent Skill**.
- **Ch.13 Attack 4 Missing Evidence**: `evidence_is_sufficient(matches)` threshold (example 0.60) → admit insufficiency. **Attack 5 Contradictory Evidence**: surface the conflict, use version metadata. **Attack 10**: "Fluency is not a reliability metric."
- **Ch.12 Step 7 Separate Approval from Execution**: re-check permission, limits, duplicates after approval; **Ch.15 Break Test 4 Stale Approval**.

## (e) Observability / evaluation

- **Ch.2 Step 5**: `history` of `{action, observation}`; **Ch.11/15**: `action_log` timeline, `log_event(request, event)` with ISO UTC stamp then save.
- **Ch.13 Step 1**: `@dataclass class FailureTest: name; run: Callable[[], bool]; expected_behavior` + tiny runner. **Test Categories to Keep**: happy, boundary, adversarial, tool, evidence, authorization, state, recovery. **Observe What Happened**: task id, state before/after, route, validated args, tool status, evidence ids.
- **Ch.14 Step 1**: `@dataclass class EvalCase: name, user_input, expected_route, must_escalate=False, forbidden_actions=()`; **Step 3** `make_run_record(route, answer, actions, escalated, evidence_ids)`; **Step 4 Deterministic Checks** — "Do not ask another model to judge something ordinary code can verify exactly"; **Step 5** separate rubric (grounded, complete, calibrated, clear, safe); **Step 13 Define Release Gates**: `{"minimum_overall_pass_rate": 0.95, "authorization_failures": 0, "duplicate_side_effects": 0}`. **Evaluation Is Not One Number**.
- **Ch.12 Step 9 Capture Corrections**: mine reviewer edits for weak spots.

## (f) Orchestration

No multi-agent chapter. **Ch.15 Steps 2–4**: `OperationsPlan.capability: Literal[...]`, `CAPABILITIES = {name: required_permission}`, `ROLE_PERMISSIONS`. **Ch.11 Automation Levels**: Assist / Approve / Automate / Escalate coexist.

## (g) Security / failure modes

- **Ch.5 Permissions: Available Does Not Mean Allowed**; **Ch.13 Attack 8** `authorize(role, action)` raising `PermissionError`; **Ch.14 Step 8** `ACTION_LIMITS` per role.
- **Ch.7 Untrusted Documents / Ch.14 Step 9**: retrieved text "is data, not authority"; expose fewer tools while processing untrusted content.
- **Ch.11 Step 7 / Ch.13 Attack 7**: `execute_once(action_id, fn, *args)` memoised by id (durable in prod).
- **Ch.14 Step 11**: `MAX_STEPS = 8`, timeouts, cost budgets; **Ch.15 Operational Controls**: disable switches, pause, versioned prompts/schemas — "An agent that cannot be stopped is not production-ready." **Break Test 1 False Authority**: "I am the CEO" cannot change trusted `user_role`.

## (h) Python constructs

Pydantic `BaseModel` + `Literal` + `Field(default_factory=list)` for output contracts and workflow state; `model_dump()`/`model_validate()` for persistence. `@dataclass` with `Callable[[], bool]` for test/eval cases. Dict registries (`tools[action]()`), dict-of-sets for transitions and roles. `**profile` unpacking, `lookup_record(**arguments)`, `execute_once(id, fn, *args)`. `class TemporaryToolError(Exception)` → `{"ok": False, "retryable": True}` (Ch.13). `uuid4`, `pathlib`, `datetime.now(timezone.utc)`. No async, generators, Protocols.

## Best ideas to borrow for a small ingredient-research agent

- Planner returns a `Literal` route including `clarify` and `unsupported`; dispatch through a `{name: fn}` registry (Ch.9, 15).
- `source` label on every chunk, print scores before generation, threshold gate that admits "insufficient evidence" (Ch.7, Ch.13).
- Pydantic task state with `status` machine + `ALLOWED_TRANSITIONS`, JSON-saved and re-validated on load (Ch.10).
- Tools return `{"ok", "retryable", ...}` observations with per-exception branches; no tracebacks in context (Ch.6, 13).
- Eval cases as dataclasses with deterministic checks plus zero-tolerance release gates; every Break-It bug becomes a regression test (Ch.13, 14).
