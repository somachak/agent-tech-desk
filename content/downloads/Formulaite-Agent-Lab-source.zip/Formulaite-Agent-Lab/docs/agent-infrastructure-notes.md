# Agent Infrastructure — compiled notes

Compiled 7 September 2026 from nine books (converted to Markdown in `books-md/`, per-book notes in `docs/book-notes/`) and Anthropic's official documentation. Every idea below is mapped to where it lives in the prototype (`agent_lab/`) or marked *next* if it is deliberately not built yet.

## 1. What an agent is (and is not)

Anthropic's definition is the one every book ends up agreeing with: a **workflow** is a fixed code path that happens to call a model; an **agent** is a loop in which the model decides the next step itself. Anthropic's advice is to start with the simplest thing that works — a single model call, then a workflow, and only then an agent — because every extra loop iteration costs tokens and adds a place to fail. *The 7 GenAI Architectures* turns this into a "Termination Test": if you can write down in advance the fixed sequence of steps that will finish the job, you do not need an agent; a chain will do the same work at roughly half the cost.

Our ingredient-research task sits right on that boundary. The happy path *is* a fixed chain (look up → read page → fill drawer), but the interesting cases — an unknown ingredient, a banned one, a gate rejection — need a decision at run time. So the prototype is a small agent with a hard step budget, which is the shape *Python AI Programming 2e* calls "a fifteen-line loop with `max_steps` from day one".

**In the prototype:** `agent.py` — `Agent.run()` is the loop, `max_steps=8` is the budget, and the `for … else` clause is the honest "I ran out of budget" exit.

## 2. The loop: observe → think → act → evaluate

All nine books describe the same cycle with different names (ReAct, OODA, plan-execute, *Modern Loop Engineering*'s five-stage loop). The two things they insist on:

The **model proposes, code decides**. *Production AI Engineering* states it as "the model proposes, the policy layer decides, the executor acts"; *Modern Loop Engineering* calls it "separation between intelligence and control"; Henry Bill's book says the model decides what it *wants* and Python decides what is *allowed*. In practice that means the model can only ask for tools from a fixed menu, and a piece of plain code (the gate) has the final say on whether the output is acceptable.

The **evaluation stage is its own event**. *Modern Loop Engineering* argues that "why did it stop or continue" must be answerable from the record, so the gate verdict is logged separately from the model reply.

**In the prototype:** the model never touches the catalogue directly — it can only call `catalogue_lookup`, `read_supplier_page` and `fill_drawer` (`formulaite_tools.py`). The gate in `gates.py` is pure Python, and every verdict is a `gate` event in the Glass Box.

## 3. Tools: the hands

The Anthropic Messages API contract is simple and the books all build on it: you send a `tools` list where each tool has a `name`, a `description` and a JSON-Schema `input_schema`; the model replies with a `tool_use` block that carries an `id`; you run the function and send back a `tool_result` block that echoes that `id` (in a *user* turn). The Python SDK also ships `client.beta.messages.tool_runner()` and a `@beta_tool` decorator that run this loop for you — the prototype keeps the loop by hand so that you can see it, but the decorator idea is borrowed directly.

What the books add on top of the API:

Tool errors must come back as **data, not tracebacks**. Williams Moses proposes a uniform envelope (`success / data / message`); *Python AI Programming 2e* and *Learn AI Agents by Building* both have the dispatcher *return* an error string that lists the tools or arguments that are valid, so the model can self-correct instead of the program dying.

Retries are only for **transient** failures (network, rate limits), never for bad input or auth errors (Moses ch. 4.4; *Building Autonomous AI Agents with Claude* ch. 6 tags each error transient/deterministic at definition).

Every tool carries a **consequence class**. *The 7 GenAI Architectures* gives each `ToolSpec` a `consequence: Literal["read","write"]`, filters the menu on it and tests that a research agent's blast radius is empty; *Production AI Engineering* wraps every call in a small gateway (schema → allow-list → risk class → approval for writes → execute → audit record).

**In the prototype:** `tools.py` — `Tool` (callable class, `to_api()` produces the exact API dict), `ToolRegistry` (the menu; `@registry.tool` decorator; `call(name, **input)` raises `ToolError`, which `agent.py` converts into an `is_error` tool_result). All three tools are read-only. *Next:* a `consequence` field and a per-tool retry policy.

## 4. Memory: what the model sees

A model has no memory; "memory" is the message list you send every time (working memory) plus whatever you store elsewhere and re-inject (long-term memory). The books' rules of thumb:

Keep **conversation history and task state separate** (Bill's `ResearchState` dataclass, checkpointed per stage; *Learn AI Agents*' Pydantic task state with an allowed-transitions table). Keep **exact facts verbatim** — IDs, numbers, URLs, error text — in a key-facts table next to the prose, and never summarise a summary (*Building Autonomous AI Agents with Claude* ch. 5). Tag every stored item with a **source** and, for long-term memory, an **expiry**, so a model inference never quietly becomes a fact (*Production AI Engineering*; *Modern Loop Engineering*'s provisional-vs-validated split). Watch the **token budget**: ~4 characters per token is a fine first estimate, and the *AI Agents Playbook* shows that putting static rules first in the prompt makes them cacheable.

**In the prototype:** `memory.py` — `Conversation` keeps the API-shaped message list and a token estimate; `drawer.py` is the task state, with `sources` as a required section. *Next:* a persistent per-ingredient store with source and expiry.

## 5. Validation and gates: the part that does not guess

This is where the books are most unanimous, and it is exactly the piece Formulaite's earlier "glass box" attempts lacked. Structured output should be enforced by schema, not hoped for: Anthropic offers `client.messages.parse(output_format=PydanticModel)` and `output_config={"format": {"type": "json_schema", …}}`, and the older "tool-use as structured output" pattern (define one tool whose input is your schema). Validation failures are **fed back as a correction turn** with a small cap — three attempts in *Python AI Programming 2e*, Anthropic's evaluator-optimizer pattern in general. Gates should test **evidence**, not vibes: *The 7 GenAI Architectures* requires every finding's `evidence_value` to be a verbatim substring of some tool result; *Learn AI Agents* admits "insufficient evidence" as a legitimate outcome; *Building Autonomous AI Agents with Claude* makes "premise failed — needs re-decomposition" a legal result. And give the agent an explicit **give-up field**, checked before the gates: *The 7 GenAI Architectures* measured that this cut the cost of failed runs from 2.12× to 1.23×.

**In the prototype:** `fill_drawer` is the structured-output tool (its `input_schema` is `IngredientDrawer.as_tool_schema()`); `gates.py` runs six deterministic checks (all sections filled, INCI matches the catalogue, not banned, use level inside the catalogue range, at least one source, no forbidden claim words); a rejection goes back as an `is_error` tool_result listing the reasons; the scripted model's `--fail-first` flag exercises the retry path. Unknown and banned ingredients are honest stops, not errors. *Next:* the verbatim-evidence check (each drawer value must appear in a tool result).

## 6. Observability: the Glass Box

Every book has a version of this. Log each iteration as reasoning / action / observation with a decision tag so "a bad query" and "a bad parse" are distinguishable (*Building Autonomous AI Agents with Claude* ch. 2). Emit `tool_requested` / `tool_completed` / `response_validated` events carrying step count and tokens (*Production AI Engineering*). Give every run a request id and record per-call timing and token counts (Bill). Evaluate on the **trajectory**, not only the final answer: assert on which tools were called and in what order (Bill; *Production AI Engineering*'s Must/May invariants). Keep a fixed eval set and rerun it after every prompt or model change (Moses ch. 8.3; *Python AI Programming 2e*'s 20-case file).

**In the prototype:** `glassbox.py` — `GlassBox.log(kind, *tags, **meta)` records `request`, `model_reply`, `tool_call`, `gate`, `final_text`, `budget_exhausted`, `run_end` events; `replay()` is a generator; `save()`/`load()` round-trip JSON in `traces/`. The tests in `tests/test_agent_lab.py` assert on the event sequence, which is trajectory evaluation in miniature. *Next:* token and latency fields on `model_reply` events, and an `evals/` folder.

## 7. Cost and token economy

The *AI Agents Playbook* is the specialist here. Cost is an architecture property: a cheap "gatekeeper" model should handle the routine 80% (extract snippets, classify), and the expensive model should synthesise only from those excerpts; sub-agents should hand work over through files on disk rather than by replaying transcripts; long waits should use scheduled wake-ups, not polling loops (the book's example: 252 polling turns cost $45 versus $0.35). *Production AI Engineering* adds one `Budget` object (seconds, model calls, tool calls, tokens) with downstream timeouts derived from the remaining deadline.

**In the prototype:** the default model is `claude-haiku-4-5` (overridable with `FORMULAITE_MODEL`), the offline `ScriptedModel` costs nothing, and `max_steps` is the only budget. *Next:* a `Budget` dataclass and a two-tier model choice.

## 8. Security and failure modes

Fetched pages are **data, not instructions**. Every book that discusses web reading says the same: wrap it, strip imperative text, score source trust, and never let page content change tool permissions (*Modern Loop Engineering*; Moses ch. 9; the Playbook's `<DATA_PAYLOAD>` tags). Runaway loops are stopped by budgets, not hope. Writes need idempotency and confirmation (*Python AI Programming 2e*'s prepare → ticket → confirm).

**In the prototype:** supplier pages are local stubs, the tool menu is read-only, and the system prompt says "do not invent facts; use only the two sources". *Next:* when the real page reader is wired in, wrap page text in a data tag and add a trust score.

## 9. Multi-agent and orchestration

Anthropic's five workflow patterns (prompt chaining, routing, parallelisation, orchestrator-workers, evaluator-optimizer) cover everything the books describe. Moses' research assistant is a fan-out of sub-questions with a review gate; the Playbook hands off between stages via disk artifacts; *The 7 GenAI Architectures* warns against carrying raw tool results between rounds — carry conclusions plus a list of prior calls, and re-send the original question every round.

**In the prototype:** a single agent using the evaluator-optimizer pattern (gate as evaluator). *Next:* a router that sends an INCI name to either this agent or a cheaper "already in catalogue, just render it" path — Anthropic's routing pattern — which is also the natural seam for Formulaite's planned graph orchestrator.

## 10. The Python that makes all of this readable

The books that show code converge on a small toolkit, which is why the prototype uses each construct in exactly one obvious place: a **dataclass** for records (`Event`, `IngredientDrawer`, `GateVerdict`, message blocks); a **class with `__call__`** for a tool; a **decorator** to register tools (Anthropic's `@beta_tool`, the books' `@tool`); `*args/**kwargs` for pass-through wrappers and open-ended loggers (`log(kind, *tags, **meta)` — you can never predict every field a trace event needs); a **generator** for replaying a trace or streaming; a **Protocol** to define the model interface without inheritance; **comprehensions** to filter blocks and collect gate reasons; a **lambda** only as a sort key; and **keyword-only parameters** (`*,`) to stop argument-order bugs in functions like `run_gates(drawer, *, catalogue_entry=…)`.

## Sources

Books (Markdown copies in `books-md/`, notes in `docs/book-notes/`): *AI Agents with Python* (Williams Moses); *Building Autonomous AI Agents with Claude AI*; *Learn AI Agents by Building Real Applications*; *AI Agents Playbook: Stop Burning Tokens* (Peter J. Kober); *Modern Loop Engineering for Agentic AI* (Dominic F. Hargrave); *AI Programming with Python for Developers* (Henry Bill); *Production AI Engineering*; *The 7 GenAI Architectures*; *Python AI Programming, Second Edition*.

Anthropic documentation (fetched 7 Sept 2026): [Tool use overview](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview) · [Tool Runner](https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-runner) · [Structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs.md) · [Building effective agents](https://www.anthropic.com/engineering/building-effective-agents) · [Choosing a model](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model.md) · [Claude Code / Agent SDK docs](https://code.claude.com/docs/en/claude_code_docs_map.md)
