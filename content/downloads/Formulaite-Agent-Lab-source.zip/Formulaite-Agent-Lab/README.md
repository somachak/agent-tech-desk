# Formulaite Agent Lab

A plain-Python, teachable **agent architecture** for the Formulaite / Cosmetic AI Assistant ingredient-research agent. It runs fully offline with a scripted "brain", and switches to real Claude (official `anthropic` SDK) with one flag.

Built 7 September 2026 for Soma, from nine agent-engineering books (converted to Markdown in `books-md/`) and Anthropic's official docs. The compiled reading is in `docs/agent-infrastructure-notes.md`; the interactive lesson is `docs/visual-guide.html`.

## Run it (2 minutes)

```bash
cd ~/Downloads/Formulaite-Agent-Lab
python3 -m agent_lab Glycerin                  # offline demo: watch the whole loop
python3 -m agent_lab Glycerin --fail-first     # watch the gate reject a bad drawer, then recover
python3 -m agent_lab Methylisothiazolinone     # banned ingredient → the agent refuses
python3 -m agent_lab Unobtainium               # unknown ingredient → honest failure
python3 -m agent_lab Glycerin --save traces/glycerin.json
python3 -m unittest discover -s tests -v       # 18 tests, no network
```

Real Claude (costs tokens; uses `claude-haiku-4-5` unless `FORMULAITE_MODEL` is set):

```bash
pip3 install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...
python3 -m agent_lab Glycerin --brain claude --save traces/glycerin-claude.json
```

Nothing else changes — same tools, same gate, same Glass Box.

## The request flow

```
 "Research the ingredient: Glycerin"
        │
        ▼
 ┌─────────────┐   tools menu    ┌──────────────────┐
 │  Agent.run  │ ──────────────▶ │  Model (brain)   │  ScriptedModel  or  ClaudeModel
 │  (the loop) │ ◀────────────── │  thinks, replies │
 └──────┬──────┘  text / tool_use└──────────────────┘
        │
        │ tool_use: catalogue_lookup / read_supplier_page      ┌──────────────┐
        ├────────────────────────────────────────────────────▶ │ ToolRegistry │ → tool_result (echoes id)
        │                                                      └──────────────┘
        │ tool_use: fill_drawer (structured output)            ┌──────────────┐
        ├────────────────────────────────────────────────────▶ │ Gate (code)  │ → PASS  → done
        │                                                      │  6 checks    │ → FAIL  → reasons back to model, loop again
        │                                                      └──────────────┘
        ▼
   Glass Box records every step  →  traces/*.json  →  replay()
```

Budget: `max_steps=8`. Unknown or banned ingredients stop honestly with a sentence, not a crash.

## Read the code in this order

| # | File | Python constructs introduced |
|---|------|------------------------------|
| 1 | `agent_lab/glassbox.py` | `@dataclass`, `*tags`/`**meta`, generator (`yield`), `@property`, `__len__`/`__iter__`, `@classmethod` |
| 2 | `agent_lab/tools.py` | class with `__call__`, decorator factory, `*args`/`**kwargs` pass-through, `lambda` sort key, dict-like dunders |
| 3 | `agent_lab/drawer.py` | dataclass as schema, `field(default_factory=…)`, comprehensions, `@classmethod` from `**kwargs` |
| 4 | `agent_lab/gates.py` | functions as values, `frozen=True` dataclass, keyword-only `*`, walrus `:=` |
| 5 | `agent_lab/formulaite_tools.py` | `@registry.tool`, `@lru_cache`, closures |
| 6 | `agent_lab/memory.py` | a small wrapper class |
| 7 | `agent_lab/models.py` | `Protocol` (interfaces), two implementations of one contract |
| 8 | `agent_lab/agent.py` | composition, `for … else`, the loop |
| 9 | `agent_lab/__main__.py` | `argparse`, consuming a generator |

Every file starts with a docstring that explains *why it exists* and *which constructs you will meet*. A real bug found while building (an empty Glass Box is "falsy" because it defines `__len__`) is kept and explained in `agent.py`.

## Layout

```
Formulaite-Agent-Lab/
  agent_lab/            the package (see table above) + data/ fixtures
  tests/                unittest suite (stdlib only)
  scripts/              gate-check scripts referenced by GATES.md
  docs/
    visual-guide.html   interactive lesson: request flow, constructs, cheat sheets
    agent-infrastructure-notes.md   compiled from the 9 books + Anthropic docs
    book-notes/         one notes file per book, with chapter citations
  books-md/             the 9 books converted to Markdown (pymupdf4llm)
  traces/               saved Glass Box runs
  GATES.md              unlazy acceptance ledger for this build
  .claude/skills/unlazy the unlazy skill (Leonxlnx/unlazy), usable from Claude Code in this repo
```

## Established open-source pieces used (nothing invented where a standard exists)

- `anthropic` — the official Python SDK (Messages API tool use). The manual loop is kept on purpose; the SDK's `client.beta.messages.tool_runner()` / `@beta_tool` do the same job automatically once you understand it.
- `pymupdf4llm` (PyMuPDF) — PDF → Markdown conversion of the books.
- `unlazy` (github.com/Leonxlnx/unlazy) — completion discipline: gates written before code, checked after.
- Python standard library for everything else: `dataclasses`, `typing.Protocol`, `functools.lru_cache`, `argparse`, `unittest`, `json`, `pathlib`.

## Wiring into Formulaite later

The seams are deliberate: replace `read_supplier_page` with the real sensor layer (keep the page text as *data*), replace `data/catalogue.json` with the app's catalogue, swap `IngredientDrawer` fields for the real drawer sections, and feed `traces/*.json` to the app's glass-box replay view. The graph-orchestrator plan (ADK / LangGraph) slots in above `Agent.run()` as a router — see §9 of the notes.

## Fixtures disclaimer

The catalogue percentages and supplier pages are teaching fixtures, not regulatory advice.
