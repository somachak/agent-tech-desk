# Brief for a book-content agent

You are turning ONE book into the content file for an interactive learning guide + cheat sheet.

Inputs (read in this order):
1. `bookguides/SCHEMA.md` — the exact JSON shape, counts and writing rules. Follow it precisely.
2. `docs/book-notes/<slug>.md` — notes already extracted from this book (chapter citations + "ideas to borrow"). Reuse, do not contradict.
3. `books-md/<slug>.md` — the full book as Markdown. Use `grep -n "^#"` to list headings, then Read the chapters section by section (offset/limit). Cover EVERY chapter, not just the first half. Skip installation/marketing/preface pages.
4. `agent_lab/*.py` docstrings (top of each file) — so `formulaite` lines and `lab_files` name real files: glassbox.py, tools.py, drawer.py, gates.py, formulaite_tools.py, memory.py, models.py, agent.py.

Output: write `bookguides/content/<slug>.json`, then run
    python3 scripts/check_book_guides.py content <slug>
and fix every FAILED line until it prints "book content verification passed". Do not stop before it passes. Do not edit the checker.

Hard rules:
- `heading` for each chapter must be the real heading text from the Markdown (copy it, minus #/*/<u> marks). The checker normalises punctuation and case but the words must match.
- `quotes[].text` must be copied verbatim from the Markdown (≤25 words, ≥ 4 words). Use grep to confirm each quote exists before writing it.
- 25–35 concepts, ≥6 per level, spread across the whole book. One idea per card. `explain` = 2–4 short plain sentences (≥ 60 characters). `analogy` concrete. `code` ≤ 12 lines, only where the book shows code or the idea is naturally code; otherwise "".
- `formulaite` = one sentence naming the Agent Lab file or the Formulaite feature where the idea lives or would live.
- Build ladder: 3 rungs phrased as Formulaite features (ingredient research, drawer, gate, glass box, catalogue, supplier pages, routing, memory, evals, cost). Steps are single actions.
- `mechanism_diagram`: valid Mermaid `flowchart LR` or `flowchart TD`, ≤ 14 nodes, node labels in square brackets, no special characters inside labels except spaces, commas and hyphens (no parentheses, quotes, colons or pipes inside labels; put edge labels with `-->|label|`).
- British spelling is fine. No jargon before it is explained. Sentences short.
- Write valid JSON (escape newlines in code as \n). Keep the file under 120 KB.

Report back in ≤ 120 words: the validator's final line, the concept count per level, and the one concept you found hardest to explain simply.
