# Book guide content schema

One JSON file per book at `bookguides/content/<slug>.json`. A generator turns it into the guide page and the cheat sheet, so **follow the shape exactly**. `scripts/check_book_guides.py content` validates it.

Audience: Soma — a creative entrepreneur who reads Python but does not hand-write it, is building the Formulaite cosmetic-formulation app (an ingredient-research agent that fills an "Ingredient Drawer", passes a deterministic gate, and records a "Glass Box" trace), learns with pictures, and has ADHD (short sentences, one idea per card, concrete steps).

Running example: **Formulaite / the Agent Lab** (`agent_lab/`: glassbox.py, tools.py, drawer.py, gates.py, formulaite_tools.py, memory.py, models.py, agent.py). Every build-ladder rung and every concept's `formulaite` line is phrased as a Formulaite feature.

Writing rules (from the learn-by-building + ADHD skills): direct sentence first; sentences under ~15 words; no jargon before it is explained; every abstract claim gets a concrete example; British English spelling is fine.

```json
{
  "slug": "ai-agents-with-python-mcp-multi-agent",
  "title": "AI Agents with Python",
  "author": "Williams Moses",
  "pages": 377,
  "one_line": "What this book is for, in one sentence.",
  "read_when": "When to open this book (one sentence).",
  "core_idea": "The single sentence that makes the whole book click.",
  "destination": "By the end you can build … (one sentence, phrased as a Formulaite capability).",
  "mechanism_diagram": "flowchart LR\n  A[Request] --> B[Model]\n  B -->|tool_use| C[Tools]\n  C --> B\n  B --> D[Answer]",
  "build_ladder": [
    {"rung": "simple", "name": "…", "you_build": "one sentence", "steps": ["≤5 steps, one action each"], "chapters": [1, 2], "lab_files": ["agent.py"], "time": "~1 hour"},
    {"rung": "intermediate", "name": "…", "you_build": "…", "steps": ["…"], "chapters": [4, 5], "lab_files": ["…"], "time": "~half a day"},
    {"rung": "advanced", "name": "…", "you_build": "…", "steps": ["…"], "chapters": [8, 9], "lab_files": ["…"], "time": "~2 days"}
  ],
  "chapters": [
    {"n": 1, "title": "Chapter title as the book names it", "heading": "the exact heading text as it appears in the Markdown file (without #, *, <u> marks)", "level": "foundation", "adds": "one sentence: what this chapter adds to the machine", "sections": ["section heading", "…"]}
  ],
  "concepts": [
    {
      "name": "Concept name",
      "level": "foundation | intermediate | advanced",
      "chapter": 1,
      "explain": "2–4 short sentences in plain words. What it is, what problem it solves.",
      "analogy": "1–2 sentences. A concrete picture from everyday life or from cosmetic formulation.",
      "code": "≤ 12 lines of Python, or an empty string if the book has none. Real, runnable-looking code, not prose.",
      "code_note": "one line: what to look at in the code",
      "trap": "one sentence: the mistake people make",
      "formulaite": "one sentence: where this lives, or would live, in Formulaite / the Agent Lab (name the file)"
    }
  ],
  "cheat_sheet": {
    "vocabulary": [{"term": "…", "means": "one line"}],
    "pattern": ["the book's core pattern in ≤ 7 lines (steps or pseudocode)"],
    "rules": [{"do": "…", "dont": "…"}],
    "skeletons": [{"name": "…", "code": "≤ 12 lines"}],
    "decisions": [{"when": "…", "use": "…", "not": "…"}],
    "checklist": ["before you ship, check …"]
  },
  "quotes": [{"text": "verbatim ≤ 25 words copied exactly from the Markdown", "chapter": 1}],
  "left_out": [{"topic": "what the guide deliberately skips", "chapter": "which chapter covers it"}],
  "done_when": ["three things the reader can DO, not recite"],
  "python_constructs": [{"construct": "…", "where": "chapter/section", "one_line": "…"}]
}
```

Required counts: chapters ≥ 8 (or every chapter if the book has fewer); concepts 25–35 with at least 6 per level; vocabulary 12–20; rules 6–10; skeletons 2–4; decisions 4–8; checklist 5–8; quotes 3–5; left_out 2–5; done_when exactly 3; python_constructs 4–10.

Levels: **foundation** = you need this to build the simple rung; **intermediate** = needed for the intermediate rung; **advanced** = production, scale, multi-agent, evaluation, security.
