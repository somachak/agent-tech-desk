"""G3: the Glass Box replays every step in order and round-trips through JSON."""
import tempfile, pathlib
from _common import ok, fail
from agent_lab import Agent, GlassBox, ScriptedModel, build_registry

box = GlassBox("g3")
result = Agent(ScriptedModel(fail_first=True), build_registry(), glassbox=box).run("Glycerin")
steps = [e.step for e in box.replay()]
if steps != list(range(1, len(box) + 1)):
    fail(f"steps not contiguous: {steps}")
gates = [e.meta["passed"] for e in box.of_kind("gate")]
if gates != [False, True]:
    fail(f"expected a rejection then a pass, got {gates}")
with tempfile.TemporaryDirectory() as d:
    path = box.save(pathlib.Path(d) / "t.json")
    loaded = GlassBox.load(path)
if [e.as_line() for e in loaded] != [e.as_line() for e in box]:
    fail("loaded trace differs from original")
print(f"{len(box)} events replayed in order; JSON round-trip identical; gate sequence {gates}")
ok("glassbox verification passed")
