#!/usr/bin/env python3
"""Build the book guides from bookguides/content/*.json.

Outputs (per book):
  docs/book-guides/<slug>.html            local page (full document, mermaid from cdnjs)
  docs/book-guides/<slug>-cheatsheet.md   printable cheat sheet
  bookguides/publish/<slug>.html          artifact body (no <html>/<head>/<body>, native mermaid)
Plus docs/book-guides/index.html and bookguides/publish/index.html.

  python3 scripts/build_book_guides.py                 # local pages + publish bodies (index links local files)
  python3 scripts/build_book_guides.py --urls urls.json  # publish index links the artifact URLs
"""
from __future__ import annotations

import html
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTENT = ROOT / "bookguides" / "content"
OUT = ROOT / "docs" / "book-guides"
PUB = ROOT / "bookguides" / "publish"
MERMAID_CDN = "https://cdnjs.cloudflare.com/ajax/libs/mermaid/11.12.0/mermaid.min.js"

# Suggested reading order across the nine books, with a two-word role each.
ORDER = [
    ("python-ai-programming-second-edition", "Python first", "Foundations"),
    ("ai-agents-with-python-mcp-multi-agent", "The agent loop", "Foundations"),
    ("learn-ai-agents-by-building-real-applications", "Build by doing", "Foundations"),
    ("ai-programming-with-python-for-developers", "Real-world apps", "Building"),
    ("building-autonomous-ai-agents-with-claude", "Claude-shaped design", "Building"),
    ("claude-certified-architect-foundations-playbook", "Claude exam prep", "Building"),
    ("agentic-design-patterns", "Pattern catalogue", "Building"),
    ("ai-agents-in-practice-task-decomposition", "Decompose and delegate", "Building"),
    ("30-agents-every-developer-should-build", "Thirty builds", "Building"),
    ("modern-loop-engineering-for-agentic-ai", "Feedback loops", "Building"),
    ("the-7-genai-architectures", "Choosing the architecture", "Scaling"),
    ("ai-agents-playbook-stop-burning-tokens", "Token economy", "Scaling"),
    ("production-ai-engineering", "Production", "Scaling"),
    ("designing-data-intensive-applications", "Data foundations", "Scaling"),
]
LEVELS = [("foundation", "Foundation"), ("intermediate", "Intermediate"), ("advanced", "Advanced")]
E = html.escape


def esc(s: str) -> str:
    return E(str(s), quote=True)


# ----------------------------------------------------------------------------- CSS
CSS = """
:root{color-scheme:light;
 --surface:#faf9f5;--surface-2:#f2f0e9;--surface-3:#e8e6dc;--surface-ink:#141413;--line:#d9d7cc;--line-soft:#e8e6dc;
 --ink:#141413;--ink-2:#5c5b57;--ink-3:#6b6a65;--on-ink:#faf9f5;
 --accent:#d97757;--accent-2:#6a9bcc;--accent-3:#788c5d;
 --font-head:"Poppins",Arial,sans-serif;--font-body:"Lora",Georgia,serif;--font-mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace}
*{box-sizing:border-box}
html,body{margin:0;background:var(--surface);color:var(--ink-2);font-family:var(--font-body);font-size:17px;line-height:1.7}
main{max-width:980px;margin:0 auto;padding:36px 22px 90px}
h1,h2,h3,h4{font-family:var(--font-head);color:var(--ink);line-height:1.2;margin:0 0 10px;text-wrap:balance}
h1{font-size:38px;letter-spacing:-.02em;font-weight:600}
h2{font-size:25px;font-weight:600}
h3{font-size:18px;font-weight:600}
h4{font-size:15px;font-weight:600;margin-bottom:6px}
p{margin:0 0 12px;max-width:70ch}
strong{color:var(--ink)}
a{color:var(--ink);text-decoration-color:var(--accent);text-underline-offset:3px}
code,.mono{font-family:var(--font-mono);font-variant-numeric:tabular-nums}
code{font-size:.86em;background:var(--surface-3);padding:1px 5px;border-radius:5px;color:var(--ink)}
pre{background:var(--surface-3);border:1px solid var(--line);border-radius:12px;padding:12px 14px;font-family:var(--font-mono);font-size:12.5px;line-height:1.6;color:var(--ink);overflow-x:auto;margin:8px 0 6px;white-space:pre}
pre code{background:none;padding:0;font-size:inherit}
section{margin-top:52px}
.num{font-family:var(--font-mono);color:var(--ink-3);font-size:12.5px;letter-spacing:.08em;text-transform:uppercase;display:block;margin-bottom:6px}
.eyebrow{font-family:var(--font-mono);color:var(--ink-3);font-size:12.5px;letter-spacing:.08em;text-transform:uppercase}
.byline{font-family:var(--font-head);font-size:14px;color:var(--ink-3);margin:-4px 0 12px}
.strip{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0 10px}
.strip div{background:var(--surface-2);border:1px solid var(--line);border-radius:12px;padding:13px 15px;font-size:15px}
.strip b{display:block;font-family:var(--font-head);font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-3);margin-bottom:4px}
.callout{border-left:3px solid var(--accent);background:var(--surface-2);border-radius:0 12px 12px 0;padding:12px 16px;margin:14px 0;font-size:15.5px}
.callout.blue{border-color:var(--accent-2)}.callout.green{border-color:var(--accent-3)}
.callout ol,.callout ul{margin:6px 0 0 18px;padding:0}.callout li{margin:4px 0}
.callout p:last-child{margin-bottom:0}
.chip{display:inline-block;font-family:var(--font-head);font-size:11px;font-weight:600;letter-spacing:.04em;border-radius:6px;padding:2px 8px;color:#141413;vertical-align:middle}
.chip.foundation{background:var(--accent-3)}.chip.intermediate{background:var(--accent-2)}.chip.advanced{background:var(--accent)}
.chip.ch{background:var(--surface-3);color:var(--ink-2);font-family:var(--font-mono);font-weight:500}
.diagram{background:var(--surface-2);border:1px solid var(--line);border-radius:14px;padding:14px;margin:14px 0;overflow-x:auto}
.diagram pre.mermaid{background:none;border:none;padding:0;margin:0;white-space:pre;overflow:visible;text-align:center}
.diagram svg{max-width:100%;height:auto}
/* ladder */
.ladder{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:14px 0}
.rung{background:var(--surface-2);border:1px solid var(--line);border-radius:14px;padding:16px 18px;cursor:pointer}
.rung:hover{border-color:var(--accent)}
.rung.on{border-color:var(--accent);box-shadow:0 0 0 2px var(--accent) inset}
.rung .lvl{font-family:var(--font-head);font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-3)}
.rung h3{margin:4px 0 6px}
.rung p{font-size:14.5px;margin:0}
.rung .time{font-family:var(--font-mono);font-size:12px;color:var(--ink-3);margin-top:8px}
.rungbody{display:none;background:var(--surface-2);border:1px solid var(--line);border-radius:14px;padding:18px 20px;margin-top:-2px}
.rungbody.on{display:block}
.rungbody ol{margin:6px 0 10px 20px;padding:0}.rungbody li{margin:5px 0}
.meta{font-family:var(--font-mono);font-size:12.5px;color:var(--ink-3)}
/* chapter map */
.chmap{border-top:1px solid var(--line);margin-top:10px}
.chrow{display:grid;grid-template-columns:44px 1fr auto;gap:12px;align-items:start;padding:10px 6px;border-bottom:1px solid var(--line-soft);cursor:pointer}
.chrow:hover{background:var(--surface-2)}
.chrow .n{font-family:var(--font-mono);color:var(--ink-3);font-size:13px;padding-top:4px}
.chrow b{font-family:var(--font-head);font-size:15px;color:var(--ink);display:block}
.chrow span.adds{font-size:14.5px;color:var(--ink-2)}
.chrow .secs{display:none;font-size:13.5px;color:var(--ink-3);margin-top:6px;font-family:var(--font-mono)}
.chrow.on .secs{display:block}
/* concepts */
.tabs{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0 6px}
.tabs button{font-family:var(--font-head);font-weight:600;font-size:13.5px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);border-radius:10px;padding:9px 14px;cursor:pointer}
.tabs button:hover{border-color:var(--accent)}
.tabs button.on{background:var(--accent);border-color:var(--accent);color:#141413}
.tabs button .cnt{font-family:var(--font-mono);font-weight:500;font-size:12px;margin-left:6px;color:var(--ink-3)}
.tabs button.on .cnt{color:#141413}
.prog{display:flex;align-items:center;gap:10px;margin:8px 0 14px;font-family:var(--font-mono);font-size:12.5px;color:var(--ink-3)}
.prog .bar{flex:1;height:9px;background:var(--surface-3);border-radius:0 4px 4px 0;overflow:hidden}
.prog .bar i{display:block;height:100%;width:0;background:var(--accent-3);transition:width .25s}
.panel{display:none}.panel.on{display:block}
.concept{background:var(--surface-2);border:1px solid var(--line);border-radius:14px;margin:10px 0;overflow:hidden}
.concept.done{border-color:var(--accent-3)}
.chead{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:center;padding:12px 16px;cursor:pointer}
.chead:hover{background:var(--surface-3)}
.chead b{font-family:var(--font-head);font-size:15.5px;color:var(--ink)}
.chead .idx{font-family:var(--font-mono);color:var(--ink-3);font-size:12px;margin-right:8px}
.chead label{font-family:var(--font-head);font-size:12.5px;color:var(--ink-2);display:flex;align-items:center;gap:6px;cursor:pointer;white-space:nowrap}
.chead input{width:16px;height:16px;accent-color:#788c5d}
.cbody{display:none;padding:4px 16px 16px;border-top:1px solid var(--line-soft)}
.concept.open .cbody{display:block}
.cbody p{font-size:15.5px}
.cbody .callout{margin:10px 0;font-size:14.5px}
.cbody .note{font-family:var(--font-mono);font-size:12.5px;color:var(--ink-3);margin:0 0 8px}
.showall{margin:8px 0 0;font-family:var(--font-head);font-size:13px;color:var(--ink-3)}
/* tables */
table{width:100%;border-collapse:collapse;font-size:14.5px;margin:8px 0 14px}
th{font-family:var(--font-head);font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--ink-3);text-align:left;padding:6px 8px;border-bottom:1px solid var(--line)}
td{padding:7px 8px;border-bottom:1px solid var(--line-soft);vertical-align:top}
td.t{font-family:var(--font-mono);font-size:13px;color:var(--ink);white-space:nowrap}
.tablewrap{overflow-x:auto}
.check{list-style:none;padding:0;margin:6px 0}
.check li{display:flex;gap:10px;align-items:flex-start;padding:5px 0;font-size:15px}
.check input{margin-top:5px;accent-color:#788c5d}
.btn{font-family:var(--font-head);font-weight:600;font-size:13.5px;border:1px solid var(--line);background:var(--surface-2);color:var(--ink);border-radius:10px;padding:8px 14px;cursor:pointer}
.btn:hover{border-color:var(--accent)}
.btn.go{background:var(--accent);border-color:var(--accent);color:#141413}
.cs-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:800px){.cs-grid,.strip,.ladder{grid-template-columns:1fr}.chrow{grid-template-columns:36px 1fr}.chrow .chip{grid-column:2}}
details{background:var(--surface-2);border:1px solid var(--line);border-radius:12px;padding:12px 18px;margin-top:14px}
summary{font-family:var(--font-head);font-weight:600;color:var(--ink);cursor:pointer}
.quote{border-left:3px solid var(--accent-2);padding:4px 14px;margin:10px 0;font-style:italic;font-size:15.5px}
.quote .who{display:block;font-style:normal;font-family:var(--font-mono);font-size:12px;color:var(--ink-3);margin-top:2px}
.small{font-size:14px;color:var(--ink-3)}
.toplinks{display:flex;flex-wrap:wrap;gap:8px 16px;font-family:var(--font-head);font-size:13.5px;margin:10px 0 0}
.toplinks a{color:var(--ink-2)}
@media print{
 body{font-size:12px} main{padding:0;max-width:none}
 body.printing main>*:not(#cheat){display:none} .btn,.toplinks{display:none}
 pre{white-space:pre-wrap;font-size:10.5px} .cs-grid{grid-template-columns:1fr 1fr} section{margin-top:16px}
}
@media(prefers-reduced-motion:reduce){*{transition:none!important}}
button:focus-visible,a:focus-visible,input:focus-visible{outline:2px solid var(--accent-2);outline-offset:2px}
"""

FONTS = """<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Lora:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">"""


# ----------------------------------------------------------------------------- pieces
def code_block(code: str) -> str:
    return f"<pre><code>{esc(code)}</code></pre>" if code.strip() else ""


def ladder_html(d: dict) -> str:
    tiles, bodies = [], []
    names = {"simple": "Simple", "intermediate": "Intermediate", "advanced": "Advanced"}
    for i, r in enumerate(d["build_ladder"]):
        tiles.append(
            f'<div class="rung{" on" if i == 0 else ""}" data-rung="{i}" role="button" tabindex="0">'
            f'<div class="lvl">Rung {i + 1} · {names[r["rung"]]}</div><h3>{esc(r["name"])}</h3>'
            f'<p>{esc(r["you_build"])}</p><div class="time">{esc(r["time"])}</div></div>')
        steps = "".join(f"<li>{esc(s)}</li>" for s in r["steps"])
        chs = ", ".join(str(c) for c in r["chapters"])
        files = " · ".join(f"<code>{esc(f)}</code>" for f in r["lab_files"])
        bodies.append(
            f'<div class="rungbody{" on" if i == 0 else ""}" data-rung="{i}"><h4>Steps for rung {i + 1}: {esc(r["name"])}</h4>'
            f'<ol>{steps}</ol><div class="meta">Chapters {esc(chs)} · Agent Lab files: {files} · {esc(r["time"])}</div></div>')
    return f'<div class="ladder">{"".join(tiles)}</div>{"".join(bodies)}'


def chapters_html(d: dict) -> str:
    rows = []
    for ch in d["chapters"]:
        secs = " · ".join(esc(s) for s in ch.get("sections", []))
        rows.append(
            f'<div class="chrow" role="button" tabindex="0"><div class="n">{esc(ch["n"])}</div>'
            f'<div><b>{esc(ch["title"])}</b><span class="adds">{esc(ch["adds"])}</span>'
            f'<div class="secs">{secs or "—"}</div></div>'
            f'<span class="chip {ch["level"]}">{ch["level"]}</span></div>')
    return f'<div class="chmap">{"".join(rows)}</div>'


def concept_html(c: dict, idx: int) -> str:
    code = code_block(c.get("code", ""))
    note = f'<div class="note">{esc(c["code_note"])}</div>' if code and c.get("code_note") else ""
    return (
        f'<div class="concept" data-key="{esc(c["name"])}"><div class="chead" role="button" tabindex="0">'
        f'<div><span class="idx">{idx:02d}</span><b>{esc(c["name"])}</b> <span class="chip ch">ch {esc(c["chapter"])}</span></div>'
        f'<label><input type="checkbox" class="got"> Got it</label></div>'
        f'<div class="cbody"><p>{esc(c["explain"])}</p>'
        f'<div class="callout blue"><strong>Picture it:</strong> {esc(c["analogy"])}</div>'
        f'{code}{note}'
        f'<div class="callout"><strong>The trap:</strong> {esc(c["trap"])}</div>'
        f'<div class="callout green"><strong>In Formulaite:</strong> {esc(c["formulaite"])}</div>'
        f'</div></div>')


def concepts_html(d: dict) -> tuple[str, dict[str, int]]:
    counts = {lvl: sum(1 for c in d["concepts"] if c["level"] == lvl) for lvl, _ in LEVELS}
    tabs = "".join(
        f'<button data-level="{lvl}" class="{"on" if i == 0 else ""}">{label}<span class="cnt">{counts[lvl]} cards · ~{counts[lvl] * 2} min</span></button>'
        for i, (lvl, label) in enumerate(LEVELS))
    panels = []
    for i, (lvl, label) in enumerate(LEVELS):
        cards = [concept_html(c, j + 1) for j, c in enumerate([c for c in d["concepts"] if c["level"] == lvl])]
        panels.append(
            f'<div class="panel{" on" if i == 0 else ""}" data-level="{lvl}">'
            f'<div class="prog"><span class="lbl">{label}</span><div class="bar"><i></i></div><span class="txt">0 / {counts[lvl]} got it</span></div>'
            f'{"".join(cards)}</div>')
    return f'<div class="tabs" id="ctabs">{tabs}</div>{"".join(panels)}', counts


def cheat_html(d: dict) -> str:
    cs = d["cheat_sheet"]
    vocab = "".join(f'<tr><td class="t">{esc(v["term"])}</td><td>{esc(v["means"])}</td></tr>' for v in cs["vocabulary"])
    pattern = "".join(f"<li>{esc(p)}</li>" for p in cs["pattern"])
    rules = "".join(f'<tr><td>{esc(r["do"])}</td><td>{esc(r["dont"])}</td></tr>' for r in cs["rules"])
    skel = "".join(f'<h4>{esc(s["name"])}</h4>{code_block(s["code"])}' for s in cs["skeletons"])
    dec = "".join(f'<tr><td>{esc(x["when"])}</td><td>{esc(x["use"])}</td><td>{esc(x["not"])}</td></tr>' for x in cs["decisions"])
    chk = "".join(f'<li><input type="checkbox" class="ship"><span>{esc(c)}</span></li>' for c in cs["checklist"])
    return f"""
<div class="cs-grid">
 <div><h3>Vocabulary</h3><div class="tablewrap"><table><thead><tr><th>Term</th><th>Means</th></tr></thead><tbody>{vocab}</tbody></table></div></div>
 <div><h3>The pattern</h3><ol>{pattern}</ol>
  <h3>Decisions</h3><div class="tablewrap"><table><thead><tr><th>When</th><th>Use</th><th>Not</th></tr></thead><tbody>{dec}</tbody></table></div></div>
</div>
<h3>Rules of thumb</h3><div class="tablewrap"><table><thead><tr><th>Do</th><th>Don't</th></tr></thead><tbody>{rules}</tbody></table></div>
<h3>Skeletons</h3>{skel}
<h3>Before you ship</h3><ul class="check">{chk}</ul>
"""


def sources_html(d: dict) -> str:
    quotes = "".join(f'<div class="quote">“{esc(q["text"])}”<span class="who">chapter {esc(q["chapter"])}</span></div>' for q in d["quotes"])
    left = "".join(f"<li><strong>{esc(x['topic'])}</strong> — {esc(x['chapter'])}</li>" for x in d["left_out"])
    cons = "".join(f'<tr><td class="t">{esc(p["construct"])}</td><td>{esc(p["one_line"])}</td><td class="small">{esc(p["where"])}</td></tr>' for p in d["python_constructs"])
    chs = ", ".join(f'{ch["n"]} {esc(ch["title"])}' for ch in d["chapters"])
    return f"""
<p><strong>Book:</strong> <em>{esc(d["title"])}</em>, {esc(d["author"])}, {esc(d["pages"])} pages. Markdown copy: <code>books-md/{esc(d["slug"])}.md</code>. Notes with chapter citations: <code>docs/book-notes/{esc(d["slug"])}.md</code>.</p>
<p><strong>Chapters covered:</strong> {chs}.</p>
<h3>In the author's words</h3>{quotes}
<h3>Python constructs this book leans on</h3><div class="tablewrap"><table><thead><tr><th>Construct</th><th>What it does here</th><th>Where</th></tr></thead><tbody>{cons}</tbody></table></div>
<h3>Deliberately left out of this guide</h3><ul>{left}</ul>
"""


JS = r"""
(function(){
 const KEY='bookguide.__SLUG__';
 let state={got:{},ship:{},tab:'foundation'};
 try{const s=localStorage.getItem(KEY); if(s) state=Object.assign(state,JSON.parse(s));}catch(e){}
 function save(){try{localStorage.setItem(KEY,JSON.stringify(state));}catch(e){}}
 // ladder
 document.querySelectorAll('.rung').forEach(r=>{const go=()=>{document.querySelectorAll('.rung,.rungbody').forEach(x=>x.classList.toggle('on',x.dataset.rung===r.dataset.rung));}; r.onclick=go; r.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};});
 // chapter rows
 document.querySelectorAll('.chrow').forEach(r=>{const go=()=>r.classList.toggle('on'); r.onclick=go; r.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go();}};});
 // tabs
 const tabs=document.querySelectorAll('#ctabs button');
 function showTab(lvl){tabs.forEach(b=>b.classList.toggle('on',b.dataset.level===lvl)); document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('on',p.dataset.level===lvl)); state.tab=lvl; save();}
 tabs.forEach(b=>b.onclick=()=>showTab(b.dataset.level));
 // concepts
 function progress(){document.querySelectorAll('.panel').forEach(p=>{const all=p.querySelectorAll('.got'), n=[...all].filter(c=>c.checked).length; p.querySelector('.bar i').style.width=(all.length?100*n/all.length:0)+'%'; p.querySelector('.txt').textContent=n+' / '+all.length+' got it';});}
 document.querySelectorAll('.concept').forEach(c=>{
  const head=c.querySelector('.chead'), box=c.querySelector('.got'), key=c.dataset.key;
  box.checked=!!state.got[key]; c.classList.toggle('done',box.checked);
  head.onclick=e=>{if(e.target.closest('label')) return; c.classList.toggle('open');};
  head.onkeydown=e=>{if(e.key==='Enter'){c.classList.toggle('open');}};
  box.onchange=()=>{state.got[key]=box.checked; c.classList.toggle('done',box.checked); save(); progress();};
 });
 document.querySelectorAll('.ship').forEach((b,i)=>{b.checked=!!state.ship[i]; b.onchange=()=>{state.ship[i]=b.checked; save();};});
 showTab(state.tab||'foundation'); progress();
 const pb=document.getElementById('printBtn'); if(pb){pb.onclick=()=>{document.body.classList.add('printing'); window.print();}; window.onafterprint=()=>document.body.classList.remove('printing');}
 const ob=document.getElementById('openFirst'); if(ob){ob.onclick=()=>{showTab('foundation'); const first=document.querySelector('.panel[data-level=foundation] .concept'); if(first){first.classList.add('open'); first.scrollIntoView({behavior:'smooth',block:'start'});}};}
})();
"""


def guide_body(d: dict, order_n: int, role: str, local: bool) -> str:
    concepts, counts = concepts_html(d)
    total = len(d["concepts"])
    minutes = total * 2 + 12
    diagram = f'<div class="diagram"><pre class="mermaid">{esc(d["mechanism_diagram"])}</pre></div>'
    sheet_link = f'<a href="{esc(d["slug"])}-cheatsheet.md">Cheat sheet as Markdown</a> · <a href="index.html">All nine guides</a>' if local else ""
    return f"""<title>{esc(d["title"])}</title>
<style>{CSS}</style>
<main>
<header>
 <span class="eyebrow">Formulaite bookshelf · book {order_n} of {len(ORDER)} · {esc(role)}</span>
 <h1>{esc(d["title"])}</h1>
 <div class="byline">{esc(d["author"])} · {esc(d["pages"])} pages · {total} concept cards</div>
 <p>{esc(d["one_line"])}</p>
 {('<div class="callout blue"><strong>Read this first.</strong> ' + esc(d["notice"]) + '</div>') if d.get("notice") else ""}
 <div class="strip">
  <div><b>Goal</b>{esc(d["destination"])}</div>
  <div><b>Output</b>A build ladder (3 rungs), {len(d["chapters"])} chapters mapped, {total} concept cards you tick off, and a printable cheat sheet.</div>
  <div><b>Time</b>Foundation ~{counts["foundation"] * 2} min · Intermediate ~{counts["intermediate"] * 2} min · Advanced ~{counts["advanced"] * 2} min. Whole guide ~{minutes} min over several sittings.</div>
 </div>
 <div class="callout"><strong>How to drive this page.</strong>
  <ol>
   <li>Press <button class="btn go" id="openFirst" type="button">Open the first card</button> — it jumps to the Foundation cards and opens card 01.</li>
   <li>Read one card, tick <strong>Got it</strong>, open the next. The bar shows your progress and remembers it on this browser.</li>
   <li>When Foundation is done, do <strong>Rung 1</strong> of the build ladder before reading Intermediate. Print the cheat sheet from section 05.</li>
  </ol>
  <div class="toplinks">{sheet_link}</div>
 </div>
</header>

<section id="s01">
 <span class="num">01 · Where this is going</span>
 <h2>{esc(d["core_idea"])}</h2>
 <p><strong>Read this book when:</strong> {esc(d["read_when"])}</p>
 <p>The one picture that holds the whole book. Every chapter adds a box or an arrow to it; nothing later replaces it.</p>
 {diagram}
</section>

<section id="s02">
 <span class="num">02 · Build ladder</span>
 <h2>Three things to build, in order</h2>
 <p>Each rung is a Formulaite feature. Click a rung for its steps. Do rung 1 after the Foundation cards, rung 2 after Intermediate, rung 3 after Advanced.</p>
 {ladder_html(d)}
</section>

<section id="s03">
 <span class="num">03 · Chapter map</span>
 <h2>What each chapter adds to the machine</h2>
 <p>Colour = the level it belongs to. Click a chapter to see its sections.</p>
 {chapters_html(d)}
</section>

<section id="s04">
 <span class="num">04 · Concept cards</span>
 <h2>Foundation → Intermediate → Advanced</h2>
 <p>One idea per card: what it is, a picture for it, the code if there is any, the trap, and where it lives in Formulaite. Tick a card when you could explain it to someone else.</p>
 {concepts}
</section>

<section id="cheat">
 <span class="num">05 · Cheat sheet</span>
 <h2>{esc(d["title"])} — cheat sheet</h2>
 <p class="small">Everything on one sheet. <button class="btn" id="printBtn" type="button">Print this cheat sheet</button></p>
 {cheat_html(d)}
</section>

<section id="s06">
 <span class="num">06 · You're done when…</span>
 <div class="callout green"><ol>{"".join(f"<li>{esc(x)}</li>" for x in d["done_when"])}</ol></div>
</section>

<section id="s07">
 <span class="num">07 · Where this comes from</span>
 {sources_html(d)}
 <details><summary>How you'd have built this guide yourself</summary>
  <p>List the chapter headings first, then read the book in chapter order and write one card per idea that changes what you would build. Sort the cards into three piles: needed for the simplest working thing, needed for the version you would show someone, needed for the version that runs unattended. Those piles are the levels; the simplest thing in each pile is the build ladder. Copy quotes exactly and keep the chapter number next to every card, so you can go back to the source when a card stops making sense.</p>
 </details>
</section>
</main>
<script>{JS.replace("__SLUG__", d["slug"])}</script>
"""


def local_doc(body: str) -> str:
    return (f'<!DOCTYPE html>\n<html lang="en-GB">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n{FONTS}\n'
            f'</head>\n<body>\n{body}\n<script src="{MERMAID_CDN}"></script>\n<script>mermaid.initialize({{startOnLoad:true,theme:"neutral",securityLevel:"loose"}});</script>\n</body>\n</html>\n')


def publish_doc(body: str) -> str:
    return FONTS + "\n" + body


# ----------------------------------------------------------------------------- cheat sheet markdown
def cheat_md(d: dict, order_n: int) -> str:
    total = len(ORDER)
    cs = d["cheat_sheet"]
    lines = [f"# {d['title']} — cheat sheet", "", f"*{d['author']} · {d['pages']} pages · Formulaite bookshelf book {order_n} of {total}*", "",
             f"**Core idea:** {d['core_idea']}", "", f"**Read when:** {d['read_when']}", "",
             "## Vocabulary", "", "| Term | Means |", "|---|---|"]
    lines += [f"| {v['term']} | {v['means']} |" for v in cs["vocabulary"]]
    lines += ["", "## The pattern", ""] + [f"{i + 1}. {p}" for i, p in enumerate(cs["pattern"])]
    lines += ["", "## Rules of thumb", "", "| Do | Don't |", "|---|---|"] + [f"| {r['do']} | {r['dont']} |" for r in cs["rules"]]
    lines += ["", "## Skeletons", ""]
    for s in cs["skeletons"]:
        lines += [f"### {s['name']}", "", "```python", s["code"], "```", ""]
    lines += ["## Decisions", "", "| When | Use | Not |", "|---|---|---|"] + [f"| {x['when']} | {x['use']} | {x['not']} |" for x in cs["decisions"]]
    lines += ["", "## Before you ship", ""] + [f"- [ ] {c}" for c in cs["checklist"]]
    lines += ["", "## Build ladder", ""]
    for i, r in enumerate(d["build_ladder"]):
        lines += [f"**Rung {i + 1} · {r['name']}** ({r['time']}) — {r['you_build']}"] + [f"  {j + 1}. {s}" for j, s in enumerate(r["steps"])] + [""]
    lines += ["## You're done when", ""] + [f"- {x}" for x in d["done_when"]]
    lines += ["", f"*Source: `books-md/{d['slug']}.md` · chapters: " + ", ".join(f"{c['n']} {c['title']}" for c in d["chapters"]) + "*", ""]
    return "\n".join(lines)


# ----------------------------------------------------------------------------- index
INDEX_CSS = CSS + """
.shelf{display:grid;grid-template-columns:1fr;gap:12px;margin:14px 0}
.book{display:grid;grid-template-columns:54px 1fr;gap:14px;background:var(--surface-2);border:1px solid var(--line);border-radius:14px;padding:16px 18px}
.book .n{font-family:var(--font-head);font-size:28px;font-weight:600;color:var(--ink-3);line-height:1}
.book h3{margin:0 0 2px}
.book .role{font-family:var(--font-mono);font-size:12px;color:var(--ink-3);letter-spacing:.06em;text-transform:uppercase}
.book p{font-size:15px;margin:6px 0}
.book .links{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
.book .links a{font-family:var(--font-head);font-size:13px;border:1px solid var(--line);border-radius:8px;padding:5px 10px;text-decoration:none;background:var(--surface)}
.book .links a:hover{border-color:var(--accent)}
.book .links a.go{background:var(--accent);border-color:var(--accent);color:#141413}
.lv{display:flex;gap:6px;align-items:center;font-family:var(--font-mono);font-size:11.5px;color:var(--ink-3);margin-top:6px}
.lv i{display:inline-block;height:8px;border-radius:0 3px 3px 0}
.phase{margin-top:26px}
"""


def index_body(books: list[dict], urls: dict[str, str] | None, local: bool) -> str:
    phases: dict[str, list[str]] = {}
    for n, (slug, role, phase) in enumerate(ORDER, 1):
        d = next(b for b in books if b["slug"] == slug)
        counts = {lvl: sum(1 for c in d["concepts"] if c["level"] == lvl) for lvl, _ in LEVELS}
        href = (urls or {}).get(slug, f"{slug}.html") if not local else f"{slug}.html"
        links = f'<a class="go" href="{esc(href)}">Open the guide</a>'
        if local:
            links += f' <a href="{esc(slug)}-cheatsheet.md">Cheat sheet (Markdown)</a> <a href="../../books-md/{esc(slug)}.md">The book (Markdown)</a>'
        bars = (f'<i style="width:{counts["foundation"] * 6}px;background:var(--accent-3)"></i>{counts["foundation"]} foundation'
                f'<i style="width:{counts["intermediate"] * 6}px;background:var(--accent-2)"></i>{counts["intermediate"]} intermediate'
                f'<i style="width:{counts["advanced"] * 6}px;background:var(--accent)"></i>{counts["advanced"]} advanced')
        phases.setdefault(phase, []).append(
            f'<div class="book"><div class="n">{n}</div><div><span class="role">{esc(role)}</span><h3>{esc(d["title"])}</h3>'
            f'<p class="small">{esc(d["author"])} · {esc(d["pages"])} pages · {len(d["concepts"])} cards</p><p>{esc(d["one_line"])}</p>'
            f'<p class="small"><strong>Read when:</strong> {esc(d["read_when"])}</p><div class="lv">{bars}</div><div class="links">{links}</div></div></div>')
    phase_blurb = {
        "Foundations": "Python first, then the loop, then a whole build. Do these three before anything else.",
        "Building": "Real applications, Claude-shaped design, and the feedback-loop mindset. Rung 2 territory.",
        "Scaling": "Which architecture, what it costs, and what production demands. Rung 3 territory.",
    }
    sections = "".join(
        f'<section class="phase"><span class="num">{esc(name)}</span><h2>{esc(phase_blurb[name])}</h2><div class="shelf">{"".join(items)}</div></section>'
        for name, items in phases.items())
    total_cards = sum(len(b["concepts"]) for b in books)
    return f"""<title>Formulaite Agent Bookshelf</title>
<style>{INDEX_CSS}</style>
<main>
<header>
 <span class="eyebrow">Formulaite Agent Lab · bookshelf</span>
 <h1>{len(books)} books, one build path</h1>
 <p>Each guide turns one book into a build ladder, a chapter map, concept cards you tick off, and a printable cheat sheet — all phrased as Formulaite features. {total_cards} cards in total.</p>
 <div class="callout"><strong>Start here.</strong><ol><li>Open book 1 (Python first) and read its Foundation cards — about {2 * sum(1 for c in books[0]["concepts"] if c["level"] == "foundation") if books else 20} minutes.</li><li>Build its rung 1 in the Agent Lab folder.</li><li>Come back here and open book 2.</li></ol></div>
</header>
{sections}
<section>
 <span class="num">How the shelf was made</span>
 <p class="small">Books converted from PDF with pymupdf4llm; each guide's content extracted by a reading agent under a checked schema (every quote verified verbatim against the book, every chapter heading real, 25–35 cards per book with at least six per level); pages generated by <code>scripts/build_book_guides.py</code>; acceptance gates in <code>GATES-book-guides.md</code>.</p>
</section>
</main>
"""


# ----------------------------------------------------------------------------- main
def main(argv: list[str]) -> None:
    urls = None
    if "--urls" in argv:
        urls = json.loads(Path(argv[argv.index("--urls") + 1]).read_text())
    OUT.mkdir(parents=True, exist_ok=True)
    PUB.mkdir(parents=True, exist_ok=True)
    books = []
    have = {p.stem for p in CONTENT.glob("*.json")}
    missing = have - {o[0] for o in ORDER}
    if missing:
        raise SystemExit(f"content files not in ORDER: {sorted(missing)}")
    order = [o for o in ORDER if o[0] in have]
    for n, (slug, role, phase) in enumerate(order, 1):
        d = json.loads((CONTENT / f"{slug}.json").read_text())
        books.append(d)
        (OUT / f"{slug}.html").write_text(local_doc(guide_body(d, n, role, local=True)))
        (PUB / f"{slug}.html").write_text(publish_doc(guide_body(d, n, role, local=False)))
        (OUT / f"{slug}-cheatsheet.md").write_text(cheat_md(d, n))
        print(f"built {slug}: {len(d['concepts'])} cards")
    (OUT / "index.html").write_text(local_doc(index_body(books, None, local=True)))
    (PUB / "index.html").write_text(publish_doc(index_body(books, urls, local=False)))
    print("built index" + (" (with artifact URLs)" if urls else ""))


if __name__ == "__main__":
    main(sys.argv[1:])
