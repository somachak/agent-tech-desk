#!/usr/bin/env python3
"""Build docs/visual-guide.html from the real recorded traces in traces/.

The page is one self-contained file: the four Glass Box traces are embedded as
JSON, so every number and every line on the page comes from a real run.
Re-run this after changing the agent:  python3 scripts/build_visual_guide.py
"""
from __future__ import annotations

import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
TRACES = {
    "glycerin": ("Glycerin — happy path", "traces/glycerin.json"),
    "fail_first": ("Glycerin — gate rejects, model repairs", "traces/glycerin-fail-first.json"),
    "banned": ("Methylisothiazolinone — banned, agent refuses", "traces/mit-banned.json"),
    "unknown": ("Unobtainium — not in catalogue, honest stop", "traces/unobtainium-unknown.json"),
}

runs = {}
for key, (label, rel) in TRACES.items():
    data = json.loads((ROOT / rel).read_text())
    runs[key] = {"label": label, "run_id": data["run_id"], "events": data["events"]}

# Real facts used in the prose (measured from the traces, never typed by hand).
ff = runs["fail_first"]["events"]
gate_events = [e for e in ff if e["kind"] == "gate"]
facts = {
    "happy_events": len(runs["glycerin"]["events"]),
    "ff_events": len(ff),
    "ff_model_calls": sum(1 for e in ff if e["kind"] == "model_reply"),
    "ff_reject_step": gate_events[0]["step"],
    "ff_reject_reason": gate_events[0]["meta"]["reasons"][0],
    "ff_pass_step": gate_events[1]["step"],
    "banned_events": len(runs["banned"]["events"]),
    "unknown_events": len(runs["unknown"]["events"]),
    "sections": len(gate_events[1]["meta"]["drawer"]),
}

template = (ROOT / "scripts" / "visual_guide_template.html").read_text()
html = template.replace("__RUNS_JSON__", json.dumps(runs, ensure_ascii=False))
for k, v in facts.items():
    html = html.replace("{{" + k + "}}", str(v))
out = ROOT / "docs" / "visual-guide.html"
out.write_text(html)
print(f"wrote {out} ({len(html)//1000}k chars) with facts {facts}")
