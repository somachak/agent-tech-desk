"""G6: all 9 books exist as Markdown with page counts recorded."""
import json
from _common import ok, fail, ROOT
folder = ROOT / "books-md"
report = json.loads((folder / "_conversion_report.json").read_text())
expected = 9
if len(report) != expected:
    fail(f"report lists {len(report)} books, expected {expected}")
for slug, info in report.items():
    md = folder / f"{slug}.md"
    if not md.exists() or md.stat().st_size < 50_000:
        fail(f"{md} missing or too small")
    if info["pages"] < 50:
        fail(f"{slug} page count suspicious: {info}")
pages = sum(v["pages"] for v in report.values())
print(f"{len(report)} books, {pages} pages, {sum(v['chars'] for v in report.values())//1000}k characters of Markdown")
ok("books verification passed")
