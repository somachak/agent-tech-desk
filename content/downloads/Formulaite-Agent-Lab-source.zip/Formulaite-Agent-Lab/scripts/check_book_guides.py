#!/usr/bin/env python3
"""Gate checks for the book guides.  Usage: check_book_guides.py content|pages|sheets [slug]

content : every bookguides/content/<slug>.json follows SCHEMA.md, headings exist in the
          book Markdown, quotes are verbatim substrings of the book.
pages   : every docs/book-guides/<slug>.html exists, has the required sections, only the
          allowed external resources, and passes the lesson page checker.
sheets  : every docs/book-guides/<slug>-cheatsheet.md has the six headings; index links resolve.
"""
from __future__ import annotations

import html as html_mod
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOOKS = ROOT / "books-md"
CONTENT = ROOT / "bookguides" / "content"
OUT = ROOT / "docs" / "book-guides"
SLUGS = sorted(p.stem for p in BOOKS.glob("*.md") if not p.name.startswith("_"))
LEVELS = ("foundation", "intermediate", "advanced")
CHECK_PAGE = Path("/root/.claude/skills/synced/78f45956-ef9f-4bc6-a87b-4397f087a349_2a244b05-48ce-4148-98f6-2fe542f128c5/learn-by-building/scripts/check_page.py")

problems: list[str] = []


def bad(msg: str) -> None:
    problems.append(msg)


def norm(s: str) -> str:
    """Normalise text for matching: drop markdown marks, HTML tags, collapse whitespace, lowercase."""
    # strip only tag-shaped runs (<u>, </u>, <br>, <!-- … -->) so a stray "<" in code cannot swallow whole pages
    s = re.sub(r"<!--.*?-->", " ", s, flags=re.S)
    s = re.sub(r"</?[A-Za-z][A-Za-z0-9-]*(?:\s[^<>\n]*)?/?>", " ", s)
    s = re.sub(r"[#*_`>|\\]", " ", s)
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    s = s.replace("—", "-").replace("–", "-").replace(" ", " ")
    return re.sub(r"\s+", " ", s).strip().lower()


def count_between(name: str, n: int, lo: int, hi: int, slug: str) -> None:
    if not (lo <= n <= hi):
        bad(f"{slug}: {name} count {n} not in {lo}..{hi}")


# ----------------------------------------------------------------- content
def check_content(slugs: list[str]) -> None:
    for slug in slugs:
        path = CONTENT / f"{slug}.json"
        if not path.exists():
            bad(f"{slug}: content file missing")
            continue
        try:
            d = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            bad(f"{slug}: invalid JSON: {exc}")
            continue
        book = norm((BOOKS / f"{slug}.md").read_text())

        for key in ("slug", "title", "author", "pages", "one_line", "read_when", "core_idea", "destination",
                    "mechanism_diagram", "build_ladder", "chapters", "concepts", "cheat_sheet", "quotes",
                    "left_out", "done_when", "python_constructs"):
            if key not in d:
                bad(f"{slug}: missing key {key}")
        if problems and any(p.startswith(slug) for p in problems):
            continue
        if d["slug"] != slug:
            bad(f"{slug}: slug field is {d['slug']!r}")
        if not str(d["mechanism_diagram"]).strip().startswith(("flowchart", "graph", "sequenceDiagram", "stateDiagram")):
            bad(f"{slug}: mechanism_diagram is not mermaid")

        ladder = d["build_ladder"]
        if [r.get("rung") for r in ladder] != ["simple", "intermediate", "advanced"]:
            bad(f"{slug}: build_ladder rungs must be simple/intermediate/advanced")
        for r in ladder:
            if not (1 <= len(r.get("steps", [])) <= 6):
                bad(f"{slug}: rung {r.get('rung')} needs 1–6 steps")
            for k in ("name", "you_build", "chapters", "lab_files", "time"):
                if not r.get(k):
                    bad(f"{slug}: rung {r.get('rung')} missing {k}")

        chapters = d["chapters"]
        if len(chapters) < 8:
            bad(f"{slug}: only {len(chapters)} chapters mapped (need ≥ 8)")
        for ch in chapters:
            if ch.get("level") not in LEVELS:
                bad(f"{slug}: chapter {ch.get('n')} bad level {ch.get('level')!r}")
            h = norm(ch.get("heading", ""))
            if len(h) < 6 or h not in book:
                bad(f"{slug}: chapter {ch.get('n')} heading not found in book: {ch.get('heading')!r}")
            if not ch.get("adds"):
                bad(f"{slug}: chapter {ch.get('n')} missing 'adds'")

        concepts = d["concepts"]
        count_between("concepts", len(concepts), 25, 35, slug)
        for lvl in LEVELS:
            n = sum(1 for c in concepts if c.get("level") == lvl)
            if n < 6:
                bad(f"{slug}: only {n} {lvl} concepts (need ≥ 6)")
        names = set()
        for c in concepts:
            for k in ("name", "level", "chapter", "explain", "analogy", "trap", "formulaite"):
                if not c.get(k) and c.get(k) != 0:
                    bad(f"{slug}: concept {c.get('name')!r} missing {k}")
            if c.get("level") not in LEVELS:
                bad(f"{slug}: concept {c.get('name')!r} bad level")
            if c.get("name") in names:
                bad(f"{slug}: duplicate concept {c.get('name')!r}")
            names.add(c.get("name"))
            code = c.get("code") or ""
            if code and len(code.splitlines()) > 14:
                bad(f"{slug}: concept {c.get('name')!r} code longer than 14 lines")
            if len(c.get("explain", "")) < 60:
                bad(f"{slug}: concept {c.get('name')!r} explain too short")

        cs = d["cheat_sheet"]
        count_between("vocabulary", len(cs.get("vocabulary", [])), 12, 22, slug)
        count_between("pattern lines", len(cs.get("pattern", [])), 3, 8, slug)
        count_between("rules", len(cs.get("rules", [])), 6, 12, slug)
        count_between("skeletons", len(cs.get("skeletons", [])), 2, 5, slug)
        count_between("decisions", len(cs.get("decisions", [])), 4, 10, slug)
        count_between("checklist", len(cs.get("checklist", [])), 5, 10, slug)
        for sk in cs.get("skeletons", []):
            if len(sk.get("code", "").splitlines()) > 14:
                bad(f"{slug}: skeleton {sk.get('name')!r} longer than 14 lines")

        quotes = d["quotes"]
        count_between("quotes", len(quotes), 3, 6, slug)
        for q in quotes:
            t = norm(q.get("text", ""))
            if len(q.get("text", "").split()) > 30:
                bad(f"{slug}: quote longer than 30 words: {q.get('text')[:50]!r}")
            if len(t) < 15 or t not in book:
                bad(f"{slug}: quote not verbatim in book: {q.get('text')[:70]!r}")

        count_between("left_out", len(d["left_out"]), 2, 6, slug)
        if len(d["done_when"]) != 3:
            bad(f"{slug}: done_when must have exactly 3 items")
        count_between("python_constructs", len(d["python_constructs"]), 4, 12, slug)
        print(f"  {slug}: {len(chapters)} chapters, {len(concepts)} concepts, {len(quotes)} quotes verified")


# ----------------------------------------------------------------- pages
REQUIRED_MARKERS = ["How to drive this page", "Build ladder", "Chapter map", "Foundation", "Intermediate", "Advanced",
                    "Cheat sheet", "done when", "Where this comes from", 'class="mermaid"', "Formulaite"]
ALLOWED_HOSTS = ("https://fonts.googleapis.com", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com/ajax/libs/mermaid/")


def check_pages(slugs: list[str]) -> None:
    for slug in slugs:
        path = OUT / f"{slug}.html"
        if not path.exists():
            bad(f"{slug}: page missing")
            continue
        html = path.read_text()
        for m in REQUIRED_MARKERS:
            if m.lower() not in html.lower():
                bad(f"{slug}: page lacks {m!r}")
        for m in re.finditer(r'<(script|link)[^>]+(src|href)=["\'](https?://[^"\']+)', html):
            if not m.group(3).startswith(ALLOWED_HOSTS):
                bad(f"{slug}: disallowed external resource {m.group(3)}")
        if CHECK_PAGE.exists():
            r = subprocess.run([sys.executable, str(CHECK_PAGE), str(path)], capture_output=True, text=True)
            if r.returncode != 0:
                bad(f"{slug}: check_page failed: {r.stdout.strip()[:300]}")
        d = json.loads((CONTENT / f"{slug}.json").read_text())
        for c in d["concepts"]:
            if c["name"] not in html and html_mod.escape(c["name"], quote=True) not in html:
                bad(f"{slug}: concept {c['name']!r} missing from page")
        print(f"  {slug}: page ok ({len(html)//1000}k chars)")


# ----------------------------------------------------------------- sheets + index
SHEET_HEADINGS = ["## Vocabulary", "## The pattern", "## Rules of thumb", "## Skeletons", "## Decisions", "## Before you ship"]


def check_sheets(slugs: list[str]) -> None:
    for slug in slugs:
        path = OUT / f"{slug}-cheatsheet.md"
        if not path.exists():
            bad(f"{slug}: cheat sheet missing")
            continue
        md = path.read_text()
        for h in SHEET_HEADINGS:
            if h not in md:
                bad(f"{slug}: cheat sheet lacks {h!r}")
    index = OUT / "index.html"
    if not index.exists():
        bad("index.html missing")
    else:
        html = index.read_text()
        for slug in slugs:
            for target in (f"{slug}.html", f"{slug}-cheatsheet.md"):
                if target not in html:
                    bad(f"index does not link {target}")
                if not (OUT / target).exists():
                    bad(f"index target missing on disk: {target}")
    print(f"  {len(slugs)} cheat sheets + index checked")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "content"
    slugs = [sys.argv[2]] if len(sys.argv) > 2 else SLUGS
    if len(SLUGS) < 9:
        bad(f"expected at least 9 books, found {len(SLUGS)}")
    {"content": check_content, "pages": check_pages, "sheets": check_sheets}[mode](slugs)
    if problems:
        print("\n".join("FAILED: " + p for p in problems))
        sys.exit(1)
    print({"content": "book content verification passed", "pages": "book pages verification passed",
           "sheets": "cheat sheets verification passed"}[mode])
