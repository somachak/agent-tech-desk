"""G5: the real-Claude path follows the anthropic SDK tool-use contract, verified with a fake client (no network)."""
import sys, pathlib
from _common import ok, fail, ROOT
sys.path.insert(0, str(ROOT / "tests"))
from test_agent_lab import FakeAnthropicClient
from agent_lab import Agent, ClaudeModel, GlassBox, build_registry

fake = FakeAnthropicClient()
result = Agent(ClaudeModel(client=fake, model="claude-test"), build_registry(), glassbox=GlassBox("g5")).run("Glycerin")
if not result.ok:
    fail("run via fake client not ok")
req = fake.requests
if len(req) != 3:
    fail(f"expected 3 API calls, got {len(req)}")
for t in req[0]["tools"]:
    if set(t) != {"name", "description", "input_schema"}:
        fail(f"tool shape wrong: {t}")
msgs = req[2]["messages"]
roles = [m["role"] for m in msgs]
if roles != ["user", "assistant", "user", "assistant", "user"]:
    fail(f"roles wrong: {roles}")
ids_sent = [b["id"] for m in msgs if m["role"] == "assistant" for b in m["content"] if b["type"] == "tool_use"]
ids_echoed = [b["tool_use_id"] for m in msgs if m["role"] == "user" and not isinstance(m["content"], str) for b in m["content"]]
if ids_sent != ids_echoed:
    fail(f"tool_use ids {ids_sent} not echoed as tool_result ids {ids_echoed}")
# the real SDK must be importable too
import anthropic
print(f"anthropic SDK {anthropic.__version__} importable; 3 calls; tool_use ids echoed: {ids_echoed}")
ok("claude contract verification passed")
