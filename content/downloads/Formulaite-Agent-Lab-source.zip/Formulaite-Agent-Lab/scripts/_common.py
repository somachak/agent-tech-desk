"""Shared helpers for gate-check scripts. Each script prints a success token only when every assertion passed."""
import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def ok(token):
    print(token)
    sys.exit(0)

def fail(msg):
    print("FAILED:", msg)
    sys.exit(1)
