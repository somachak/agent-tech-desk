"""G7: the visual guide is self-contained and covers the flow + every construct."""
import re
from _common import ok, fail, ROOT
html = (ROOT / "docs" / "visual-guide.html").read_text()
# Only Google Fonts may be referenced (they have Arial/Georgia fallbacks); everything else must be inline.
for m in re.finditer(r'<(script|link)[^>]+(src|href)=["\'](https?://[^"\']+)', html):
    if not m.group(3).startswith(("https://fonts.googleapis.com", "https://fonts.gstatic.com")):
        fail(f"external resource found — guide must be self-contained: {m.group(3)}")
needed = ["request", "tool_use", "tool_result", "gate", "Glass Box",
          "*args", "**kwargs", "class", "dataclass", "generator", "yield", "decorator", "lambda", "comprehension", "Protocol"]
missing = [n for n in needed if n.lower() not in html.lower()]
if missing:
    fail(f"guide missing topics: {missing}")
if "cheat" not in html.lower():
    fail("no cheat sheet section")
print(f"{len(html)//1000}k chars, {len(needed)} topics present, no external resources")
ok("visual guide verification passed")
