"""G1: the offline demo runs end to end and fills every required drawer section."""
import sys
from _common import ok, fail
from agent_lab import Agent, GlassBox, ScriptedModel, build_registry

inci = sys.argv[1] if len(sys.argv) > 1 else "Glycerin"
result = Agent(ScriptedModel(), build_registry(), glassbox=GlassBox("g1")).run(inci)
if not result.ok:
    fail(f"run not ok: {result.final_text}")
missing = result.drawer.missing()
if missing:
    fail(f"drawer missing sections: {missing}")
kinds = [e.kind for e in result.glassbox]
for needed in ("request", "model_reply", "tool_call", "gate", "run_end"):
    if needed not in kinds:
        fail(f"trace lacks {needed} event: {kinds}")
print(f"{inci}: {len(result.drawer.REQUIRED_SECTIONS)} sections filled, {len(kinds)} trace events, gate PASS")
ok("offline run verification passed")
