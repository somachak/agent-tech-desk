"""G2: the gate fails on a bad drawer (positive control) and passes on a good one."""
from _common import ok, fail
from agent_lab import IngredientDrawer, catalogue_entry, run_gates

entry = catalogue_entry("Glycerin")
good = IngredientDrawer.from_model_input(
    inci_name="Glycerin", function="humectant", typical_use_level="2-5%", use_level_pct=3,
    phase_and_solubility="A; water-soluble", ph_range="3-9", compatibility="broad",
    safety_notes="low irritation", sources=["catalogue_lookup"])
if not run_gates(good, catalogue_entry=entry).passed:
    fail("good drawer was rejected")

controls = {
    "outside catalogue range": IngredientDrawer.from_model_input(**{**good.to_dict(), "use_level_pct": 50}),
    "missing sections": IngredientDrawer.from_model_input(**{**good.to_dict(), "ph_range": ""}),
    "no sources": IngredientDrawer.from_model_input(**{**good.to_dict(), "sources": []}),
    "forbidden claim": IngredientDrawer.from_model_input(**{**good.to_dict(), "safety_notes": "guaranteed safe"}),
}
for expected, drawer in controls.items():
    v = run_gates(drawer, catalogue_entry=entry)
    if v.passed or not any(expected in r for r in v.reasons):
        fail(f"positive control '{expected}' did not fail correctly: {v}")
banned = run_gates(IngredientDrawer.from_model_input(**{**good.to_dict(), "inci_name": "Methylisothiazolinone", "use_level_pct": 0}),
                   catalogue_entry=catalogue_entry("Methylisothiazolinone"))
if banned.passed or not any("banned" in r for r in banned.reasons):
    fail("banned control did not fail")
print(f"1 good drawer passed; {len(controls)+1} positive controls failed for the right reason")
ok("gate control verification passed")
