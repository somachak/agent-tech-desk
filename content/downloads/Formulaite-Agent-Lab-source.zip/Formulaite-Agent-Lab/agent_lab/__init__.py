"""
Formulaite Agent Lab — a plain-Python, teachable agent architecture.

Read the files in this order (each one's docstring explains the Python
constructs it introduces):

    1. glassbox.py          @dataclass, *tags/**meta, generators, @property
    2. tools.py             classes with __call__, decorators, *args/**kwargs pass-through, lambda
    3. drawer.py            dataclass as a schema, @classmethod, comprehensions
    4. gates.py             functions as values, frozen dataclass, keyword-only params, walrus
    5. formulaite_tools.py  @registry.tool, @lru_cache
    6. memory.py            a small wrapper class
    7. models.py            Protocol (interfaces), the two brains
    8. agent.py             composition and the loop itself
    9. __main__.py          the command-line runner

Public API (what the app would import):
"""

from .agent import Agent, RunResult, SYSTEM_PROMPT
from .drawer import IngredientDrawer
from .formulaite_tools import build_registry, catalogue_entry, load_catalogue
from .gates import GateVerdict, run_gates
from .glassbox import Event, GlassBox
from .memory import Conversation
from .models import ClaudeModel, ModelReply, ScriptedModel, TextBlock, ToolUseBlock
from .tools import Tool, ToolError, ToolRegistry

__all__ = [
    "Agent", "RunResult", "SYSTEM_PROMPT",
    "IngredientDrawer",
    "build_registry", "catalogue_entry", "load_catalogue",
    "GateVerdict", "run_gates",
    "Event", "GlassBox",
    "Conversation",
    "ClaudeModel", "ModelReply", "ScriptedModel", "TextBlock", "ToolUseBlock",
    "Tool", "ToolError", "ToolRegistry",
]
