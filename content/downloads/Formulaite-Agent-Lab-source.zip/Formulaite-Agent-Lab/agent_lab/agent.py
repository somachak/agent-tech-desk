"""
agent.py — the agent loop itself. This is the heart of the lab.

The loop in one breath
----------------------
    user request
      → model thinks and either ANSWERS or asks for TOOLS
      → we run the tools, record them, feed the results back
      → repeat …
      → when the model calls `fill_drawer`, the deterministic GATE decides:
            PASS → done, return the drawer
            FAIL → send the reasons back as a tool_result and loop again
      → stop after max_steps no matter what (a budget, so it can never run away)

Everything the loop does is written to the Glass Box.

Python constructs you will meet in this file
--------------------------------------------
* a class that *composes* other objects (model, tools, glassbox, gate) — the
  agent owns no clever logic of its own, it coordinates.
* keyword-only constructor arguments after `*`.
* a dataclass for the result (RunResult).
* a `for … else` loop (the else runs only if the loop was NOT broken out of).
* dict/list comprehensions turning our blocks into API-shaped dicts.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from .drawer import IngredientDrawer
from .formulaite_tools import ANSWER_TOOL, catalogue_entry
from .gates import GateVerdict, run_gates
from .glassbox import GlassBox
from .memory import Conversation
from .models import ModelClient, ModelReply, TextBlock, ToolUseBlock
from .tools import ToolError, ToolRegistry, as_text

SYSTEM_PROMPT = """You are Formulaite's ingredient-research agent.
Your job: fill the Ingredient Drawer for ONE ingredient using the tools.
Rules:
1. Always call catalogue_lookup first. If the ingredient is unknown or banned, say so and stop.
2. Then call read_supplier_page with the supplier_url from the catalogue.
3. Then call fill_drawer with every section filled from those two sources only.
   Do not invent facts. Keep use_level_pct inside the catalogue range.
   List your sources (tool names / page URL) in `sources`.
4. If fill_drawer is rejected, read the reasons, fix exactly those, and call it again.
Keep text replies to one short sentence."""


@dataclass
class RunResult:
    """What a run hands back to the caller (the app, the CLI, a test)."""

    request: str
    drawer: IngredientDrawer | None
    verdict: GateVerdict | None
    steps: int
    final_text: str = ""
    glassbox: GlassBox = field(default_factory=lambda: GlassBox("unset"))

    @property
    def ok(self) -> bool:
        return self.drawer is not None and self.verdict is not None and self.verdict.passed


class Agent:
    """Coordinates model ↔ tools ↔ gate and records everything.

    Construct: composition. The Agent is built FROM a model, a registry, a
    glassbox and a gate function. Each can be swapped independently — that is
    how the same Agent runs offline (ScriptedModel) and online (ClaudeModel).
    """

    def __init__(
        self,
        model: ModelClient,
        tools: ToolRegistry,
        *,
        glassbox: GlassBox | None = None,
        gate: Callable[..., GateVerdict] = run_gates,
        system_prompt: str = SYSTEM_PROMPT,
        max_steps: int = 8,
    ) -> None:
        self.model = model
        self.tools = tools
        # GOTCHA (found while building this lab): GlassBox defines __len__, so an
        # EMPTY box is "falsy" — `glassbox or GlassBox(...)` would silently throw
        # away the box you passed in and record nothing. Always test `is None`
        # for "was an argument given", never truthiness.
        self.glassbox = glassbox if glassbox is not None else GlassBox(run_id="run")
        self.gate = gate
        self.system_prompt = system_prompt
        self.max_steps = max_steps

    # ------------------------------------------------------------------ public
    def run(self, inci: str) -> RunResult:
        request = f"Research the ingredient: {inci}"
        convo = Conversation()
        convo.add_user(request)
        box = self.glassbox
        box.log("request", inci, text=request, tools=self.tools.names)

        drawer: IngredientDrawer | None = None
        verdict: GateVerdict | None = None
        final_text = ""

        for step in range(1, self.max_steps + 1):
            # 1) THINK — ask the model what to do next
            reply = self.model.complete(system=self.system_prompt, messages=convo.as_api(), tools=self.tools.to_api())
            box.log("model_reply", inci, step=step, stop_reason=reply.stop_reason,
                    text=reply.text, tool_calls=[t.name for t in reply.tool_uses])

            # 2) DONE? — no tool requests means the model is answering in prose
            if not reply.tool_uses:
                final_text = reply.text
                box.log("final_text", inci, text=final_text)
                break

            convo.add_assistant(_blocks_to_api(reply))

            # 3) ACT — run every requested tool, collect results
            results: list[dict[str, Any]] = []
            for call in reply.tool_uses:
                if call.name == ANSWER_TOOL:
                    drawer, verdict, result = self._handle_answer(call, inci)
                else:
                    result = self._handle_tool(call, inci)
                results.append(result)

            convo.add_tool_results(results)

            # 4) GATE PASSED? — then the run is complete
            if verdict is not None and verdict.passed:
                final_text = f"Drawer for {drawer.inci_name} accepted."
                break
        else:
            # Construct: for/else — runs only when the loop finished WITHOUT break,
            # i.e. we hit the step budget.
            box.log("budget_exhausted", inci, max_steps=self.max_steps)
            final_text = f"Stopped after {self.max_steps} steps without an accepted drawer."

        box.log("run_end", inci, ok=bool(verdict and verdict.passed), model_calls=step)
        return RunResult(request=request, drawer=drawer, verdict=verdict, steps=box.steps,
                         final_text=final_text, glassbox=box)

    # ------------------------------------------------------------------ helpers
    def _handle_tool(self, call: ToolUseBlock, inci: str) -> dict[str, Any]:
        """Run an ordinary tool; turn errors into an error tool_result (never crash)."""
        try:
            output = self.tools.call(call.name, **call.input)     # ** unpacks the model's JSON
            text, is_error = as_text(output), False
        except ToolError as exc:
            text, is_error = f"ERROR: {exc}", True
        self.glassbox.log("tool_call", inci, tool=call.name, input=call.input,
                          ok=not is_error, output=text[:200])
        return _tool_result(call.id, text, is_error)

    def _handle_answer(self, call: ToolUseBlock, inci: str) -> tuple[IngredientDrawer, GateVerdict, dict[str, Any]]:
        """The model submitted a drawer → build it, run the deterministic gate."""
        drawer = IngredientDrawer.from_model_input(**call.input)
        verdict = self.gate(drawer, catalogue_entry=catalogue_entry(inci))
        self.glassbox.log("gate", inci, passed=verdict.passed, reasons=list(verdict.reasons),
                          drawer=drawer.to_dict())
        if verdict.passed:
            return drawer, verdict, _tool_result(call.id, "ACCEPTED: drawer passed all gates.")
        feedback = "REJECTED by gate:\n- " + "\n- ".join(verdict.reasons)
        return drawer, verdict, _tool_result(call.id, feedback, is_error=True)


# ---------------------------------------------------------------- API shaping
def _blocks_to_api(reply: ModelReply) -> list[dict[str, Any]]:
    """Our dataclasses → the dict shape the Messages API accepts for an assistant turn."""
    out: list[dict[str, Any]] = []
    for b in reply.content:
        if isinstance(b, TextBlock) and b.text:
            out.append({"type": "text", "text": b.text})
        elif isinstance(b, ToolUseBlock):
            out.append({"type": "tool_use", "id": b.id, "name": b.name, "input": b.input})
    return out


def _tool_result(tool_use_id: str, content: str, is_error: bool = False) -> dict[str, Any]:
    """The exact `tool_result` block shape: it MUST echo the tool_use id."""
    block: dict[str, Any] = {"type": "tool_result", "tool_use_id": tool_use_id, "content": content}
    if is_error:
        block["is_error"] = True
    return block
