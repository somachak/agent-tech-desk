"""
models.py — the "brain" socket: one small interface, two implementations.

  ScriptedModel  — offline. Follows a fixed plan (look up → read page → fill
                   drawer) but builds its answers from the REAL tool results it
                   receives, so the whole loop is exercised honestly. Perfect
                   for tracing every step without an API key.
  ClaudeModel    — online. Calls Claude through the official `anthropic` SDK
                   (Messages API with tool use). Same interface, same agent.

Why this exists
---------------
The agent loop should not care *which* model it talks to. By agreeing on one
tiny contract (`complete(system, messages, tools) -> ModelReply`) we can swap
the brain with a single flag and keep every other file unchanged. This is the
"dependency inversion" idea from the books: depend on an interface, not a vendor.

Python constructs you will meet in this file
--------------------------------------------
* typing.Protocol .......... an interface described by *shape* (duck typing with
                             a name): anything with a matching `complete` method
                             counts as a ModelClient.
* dataclasses for the message blocks (TextBlock, ToolUseBlock, ModelReply).
* isinstance filtering in list comprehensions.
* uuid for ids, json for tool results, environment variables for config.
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, field
from typing import Any, Protocol

# --------------------------------------------------------------------------
# The message vocabulary (a tiny, vendor-neutral copy of the API shapes)
# --------------------------------------------------------------------------


@dataclass
class TextBlock:
    text: str
    type: str = "text"


@dataclass
class ToolUseBlock:
    """The model asking us to run a tool. Mirrors Anthropic's `tool_use` block:
    it carries an `id` that we must echo back in the `tool_result`."""

    name: str
    input: dict[str, Any]
    id: str = field(default_factory=lambda: f"toolu_{uuid.uuid4().hex[:12]}")
    type: str = "tool_use"


@dataclass
class ModelReply:
    """What comes back from one model call."""

    content: list[TextBlock | ToolUseBlock]
    stop_reason: str            # "tool_use" when the model wants tools run, else "end_turn"

    @property
    def tool_uses(self) -> list[ToolUseBlock]:
        # Construct: list comprehension with isinstance filter.
        return [b for b in self.content if isinstance(b, ToolUseBlock)]

    @property
    def text(self) -> str:
        return "\n".join(b.text for b in self.content if isinstance(b, TextBlock))


class ModelClient(Protocol):
    """Construct: Protocol. Any object with this method signature *is* a
    ModelClient — no inheritance needed. The agent depends only on this."""

    def complete(
        self,
        *,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
    ) -> ModelReply: ...


# --------------------------------------------------------------------------
# Offline: the scripted model
# --------------------------------------------------------------------------


class ScriptedModel:
    """A stand-in brain with a fixed plan but honest inputs.

    Plan: 1) catalogue_lookup(inci)  2) read_supplier_page(url from step 1)
          3) fill_drawer(...) built from the two tool results.
    If the gate rejects the drawer, the next call reads the rejection reasons
    and repairs the specific field (so the retry path is exercised too).

    `fail_first` makes the first drawer deliberately wrong (use level out of
    range) so you can watch the gate reject it and the model recover.
    """

    def __init__(self, *, fail_first: bool = False) -> None:
        self.fail_first = fail_first
        self.calls = 0

    def complete(self, *, system: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> ModelReply:
        self.calls += 1
        results = _tool_results_by_name(messages)     # what have we learned so far?
        request = _first_user_text(messages)
        inci = _extract_inci(request)

        if "catalogue_lookup" not in results:
            return ModelReply(
                content=[TextBlock(f"I'll start by looking up {inci} in the catalogue."),
                         ToolUseBlock(name="catalogue_lookup", input={"inci": inci})],
                stop_reason="tool_use",
            )

        entry = _as_json(results["catalogue_lookup"])
        if isinstance(entry, str) and entry.startswith("ERROR"):
            return ModelReply(
                content=[TextBlock(f"The catalogue does not know {inci!r}. I cannot fill the drawer: {entry}")],
                stop_reason="end_turn",
            )
        if entry.get("banned"):
            return ModelReply(
                content=[TextBlock(f"{entry['inci']} is banned in Formulaite; I will not fill a drawer for it.")],
                stop_reason="end_turn",
            )

        if "read_supplier_page" not in results:
            return ModelReply(
                content=[TextBlock("Now I'll read the supplier page for details."),
                         ToolUseBlock(name="read_supplier_page", input={"url": entry["supplier_url"]})],
                stop_reason="tool_use",
            )

        page = results["read_supplier_page"]
        drawer = _drawer_from_sources(entry, page)

        rejection = results.get("fill_drawer")   # present only if the gate said no
        if rejection is None and self.fail_first:
            drawer["use_level_pct"] = entry["use_level_max"] * 5   # deliberately wrong
            note = "Submitting the drawer."
        elif rejection is not None:
            note = f"The gate rejected my drawer ({rejection.strip()[:60]}…). Repairing and resubmitting."
        else:
            note = "Submitting the drawer."

        return ModelReply(
            content=[TextBlock(note), ToolUseBlock(name="fill_drawer", input=drawer)],
            stop_reason="tool_use",
        )


def _drawer_from_sources(entry: dict[str, Any], page: str) -> dict[str, Any]:
    """Assemble drawer sections from the catalogue entry + page text.

    A real model reads the page and writes prose; our scripted model does the
    minimal honest version: pull the labelled lines out of the stub page.
    """
    lines = {k.strip().lower(): v.strip() for k, v in
             (ln.split(":", 1) for ln in page.splitlines() if ":" in ln)}
    lo, hi = entry["use_level_min"], entry["use_level_max"]
    return {
        "inci_name": entry["inci"],
        "function": lines.get("function", entry["function"]),
        "typical_use_level": lines.get("typical use level", f"{lo}-{hi}%"),
        "use_level_pct": round((lo + hi) / 2, 2),
        "phase_and_solubility": lines.get("phase", f"{entry['phase']}; {entry['solubility']}"),
        "ph_range": lines.get("ph range", entry["ph_range"]),
        "compatibility": lines.get("compatibility", "n/a"),
        "safety_notes": lines.get("safety notes", "n/a"),
        "sources": ["catalogue_lookup", f"read_supplier_page:{entry['supplier_url']}"],
    }


# ---- small helpers that read the conversation the way a model would --------

def _first_user_text(messages: list[dict[str, Any]]) -> str:
    for m in messages:
        if m["role"] == "user" and isinstance(m["content"], str):
            return m["content"]
    return ""


def _extract_inci(request: str) -> str:
    # The agent phrases the request as "Research the ingredient: <INCI>".
    return request.split(":", 1)[-1].strip() if ":" in request else request.strip()


def _tool_results_by_name(messages: list[dict[str, Any]]) -> dict[str, str]:
    """Pair each tool_result with the name of the tool_use it answers.

    Walk the conversation: remember tool_use ids -> names from assistant
    turns, then map user tool_result blocks back through those ids. Later
    results overwrite earlier ones, which is what we want for retries.
    """
    id_to_name: dict[str, str] = {}
    results: dict[str, str] = {}
    for m in messages:
        content = m["content"]
        if isinstance(content, str):
            continue
        for block in content:
            b = block if isinstance(block, dict) else vars(block)
            if b.get("type") == "tool_use":
                id_to_name[b["id"]] = b["name"]
            elif b.get("type") == "tool_result":
                results[id_to_name.get(b["tool_use_id"], "?")] = str(b.get("content", ""))
    return results


def _as_json(text: str) -> Any:
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text


# --------------------------------------------------------------------------
# Online: Claude through the official SDK
# --------------------------------------------------------------------------

DEFAULT_MODEL = os.environ.get("FORMULAITE_MODEL", "claude-haiku-4-5")


class ClaudeModel:
    """Real Claude via the official `anthropic` Python SDK.

    The loop lives in agent.py (so you can *see* it); this class only does one
    request/response and translates the SDK's blocks into our dataclasses.
    Requires ANTHROPIC_API_KEY in the environment.

    Note: the SDK also offers `client.beta.messages.tool_runner(...)`, which
    runs the whole loop for you. We keep the manual loop on purpose — the
    point of this lab is to learn what the runner hides.
    """

    def __init__(self, model: str = DEFAULT_MODEL, *, max_tokens: int = 1024, client: Any | None = None) -> None:
        if client is None:
            import anthropic   # imported here so the offline lab never needs the package at import time
            client = anthropic.Anthropic()
        self.client = client
        self.model = model
        self.max_tokens = max_tokens

    def complete(self, *, system: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> ModelReply:
        response = self.client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            system=system,
            tools=tools,
            messages=messages,
        )
        content: list[TextBlock | ToolUseBlock] = []
        for block in response.content:
            if block.type == "text":
                content.append(TextBlock(block.text))
            elif block.type == "tool_use":
                content.append(ToolUseBlock(name=block.name, input=dict(block.input), id=block.id))
        return ModelReply(content=content, stop_reason=response.stop_reason)
