"""
__main__.py — run the lab from the command line.

    python -m agent_lab Glycerin                     # offline, scripted brain
    python -m agent_lab Glycerin --fail-first        # watch the gate reject, then recover
    python -m agent_lab Glycerin --brain claude      # real Claude (needs ANTHROPIC_API_KEY)
    python -m agent_lab Methylisothiazolinone        # banned ingredient → agent refuses
    python -m agent_lab Unobtainium                  # unknown ingredient → honest failure
    python -m agent_lab Glycerin --save traces/glycerin.json

Python constructs you will meet in this file
--------------------------------------------
* argparse for command-line flags.
* a generator consumed by a for-loop (box.replay()).
* f-strings with formatting.
"""

from __future__ import annotations

import argparse
import sys

from .agent import Agent
from .formulaite_tools import build_registry
from .glassbox import GlassBox
from .models import ClaudeModel, ScriptedModel


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="agent_lab", description="Formulaite ingredient-research agent lab")
    parser.add_argument("inci", help="INCI name to research, e.g. Glycerin")
    parser.add_argument("--brain", choices=["scripted", "claude"], default="scripted",
                        help="scripted = offline demo (default); claude = real model via the anthropic SDK")
    parser.add_argument("--fail-first", action="store_true",
                        help="(scripted only) make the first drawer wrong so you can watch the gate reject it")
    parser.add_argument("--save", metavar="PATH", help="write the Glass Box trace to this JSON file")
    parser.add_argument("--quiet", action="store_true", help="print only the drawer")
    args = parser.parse_args(argv)

    if args.brain == "claude":
        import os
        if not os.environ.get("ANTHROPIC_API_KEY"):
            print("ANTHROPIC_API_KEY is not set. Run:  export ANTHROPIC_API_KEY=sk-ant-...   (or use --brain scripted)")
            return 2
        model = ClaudeModel()
    else:
        model = ScriptedModel(fail_first=args.fail_first)

    box = GlassBox(run_id=f"{args.inci.lower()}-{args.brain}")
    agent = Agent(model, build_registry(), glassbox=box)
    result = agent.run(args.inci)

    if not args.quiet:
        print(f"\n=== GLASS BOX — {box.run_id} ({box.steps} events) ===")
        for event in box.replay():           # generator: one event at a time
            print(event.as_line())

    print("\n=== RESULT ===")
    print(result.final_text)
    if result.drawer is not None:
        print("\n=== INGREDIENT DRAWER ===")
        for name, value in result.drawer.to_dict().items():
            print(f"{name:<22} {value}")
    if result.verdict is not None:
        status = "PASS" if result.verdict.passed else "FAIL"
        print(f"\nGATE: {status}" + ("" if result.verdict.passed else " — " + "; ".join(result.verdict.reasons)))

    if args.save:
        path = box.save(args.save)
        print(f"\ntrace saved → {path}")

    return 0 if result.ok or result.drawer is None else 1


if __name__ == "__main__":
    sys.exit(main())
