"""
tools.py — the agent's "hands": a Tool class, a ToolRegistry, and a @registry.tool
decorator that turns an ordinary Python function into something a model can call.

Why this exists
---------------
A language model can only *talk*. To look something up or read a page it must
ask us to run a function on its behalf. The official Anthropic Messages API does
this with a "tools" list: each tool has a name, a description and an
input_schema (JSON Schema). The model replies with a `tool_use` block, we run
the matching Python function, and send back a `tool_result`.

This file keeps our tools in one tidy place and produces that API shape.

Python constructs you will meet in this file
--------------------------------------------
* class with __call__ ..... an object you can call like a function: tool(inci="Glycerin").
* *args / **kwargs ........ pass-through: ToolRegistry.call(name, *args, **kwargs)
                            forwards whatever it receives to the real function.
* decorator ............... @registry.tool(...) wraps a function at definition time.
                            (This is the same idea as Anthropic's `@beta_tool`.)
* __getitem__ / __contains__ / __iter__ ... make the registry behave like a dict.
* lambda .................. a tiny inline function used as a sort key.
"""

from __future__ import annotations

import inspect
import json
import typing
from typing import Any, Callable, Iterator


class ToolError(Exception):
    """Raised when a tool is missing or its inputs are wrong.

    The agent catches this and hands the *message* back to the model as an
    error tool_result, so the model can recover instead of the program crashing.
    """


class Tool:
    """One callable capability with a model-facing description.

    Construct: a class. `__init__` stores the pieces; `__call__` makes an
    instance callable, so `lookup(inci="Glycerin")` runs the wrapped function.
    """

    def __init__(
        self,
        fn: Callable[..., Any],
        *,                                   # everything after * must be passed by keyword
        name: str | None = None,
        description: str | None = None,
        input_schema: dict[str, Any] | None = None,
    ) -> None:
        self.fn = fn
        self.name = name or fn.__name__
        self.description = (description or fn.__doc__ or "").strip()
        self.input_schema = input_schema or _schema_from_signature(fn)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Construct: *args/**kwargs pass-through.

        We do not know (or care) what parameters the wrapped function takes;
        we forward exactly what we were given. This is the single most common
        real-world use of *args/**kwargs: wrapping another function.
        """
        return self.fn(*args, **kwargs)

    def to_api(self) -> dict[str, Any]:
        """The exact dict the Anthropic Messages API expects in `tools=[...]`."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
        }

    def __repr__(self) -> str:
        return f"Tool({self.name!r})"


def _schema_from_signature(fn: Callable[..., Any]) -> dict[str, Any]:
    """Build a minimal JSON Schema from a function's type hints.

    Only handles str / float / int / bool — enough for teaching. For anything
    richer, pass `input_schema=` explicitly (or use Pydantic in a real app).
    """
    type_map = {str: "string", float: "number", int: "integer", bool: "boolean"}
    # get_type_hints resolves "postponed" annotations (files that start with
    # `from __future__ import annotations` store hints as strings like "int").
    try:
        hints = typing.get_type_hints(fn)
    except Exception:          # unresolvable forward reference → fall back to strings
        hints = {}
    props: dict[str, Any] = {}
    required: list[str] = []
    for pname, param in inspect.signature(fn).parameters.items():
        if pname == "self":
            continue
        json_type = type_map.get(hints.get(pname, param.annotation), "string")
        props[pname] = {"type": json_type}
        if param.default is inspect.Parameter.empty:
            required.append(pname)
    return {"type": "object", "properties": props, "required": required}


class ToolRegistry:
    """A named collection of Tools that the agent can call.

    Construct: dunder methods make the registry feel like a dict —
    `"catalogue_lookup" in registry`, `registry["catalogue_lookup"]`,
    `for tool in registry` — while still being our own class with extra
    behaviour (to_api, call, the @tool decorator).
    """

    def __init__(self, *tools: Tool) -> None:
        """Construct: *tools — accept zero or many Tool objects positionally:
        ToolRegistry() or ToolRegistry(t1, t2, t3)."""
        self._tools: dict[str, Tool] = {}
        for tool in tools:
            self.register(tool)

    # ---------------------------------------------------------------- building
    def register(self, tool: Tool) -> Tool:
        if tool.name in self._tools:
            raise ToolError(f"tool {tool.name!r} is already registered")
        self._tools[tool.name] = tool
        return tool

    def tool(self, **tool_kwargs: Any) -> Callable[[Callable[..., Any]], Tool]:
        """Decorator factory.

        Construct: a decorator. Writing::

            @registry.tool(description="Look up an ingredient")
            def catalogue_lookup(inci: str) -> str: ...

        is the same as writing::

            def catalogue_lookup(inci: str) -> str: ...
            catalogue_lookup = registry.tool(description=…)(catalogue_lookup)

        `registry.tool(...)` returns `decorate`; Python then calls
        `decorate(catalogue_lookup)`, which wraps the function in a Tool,
        registers it, and returns the Tool. The **tool_kwargs are forwarded to
        Tool(...) untouched — pass-through again.
        """

        def decorate(fn: Callable[..., Any]) -> Tool:
            return self.register(Tool(fn, **tool_kwargs))

        return decorate

    # ---------------------------------------------------------------- using
    def call(self, name: str, *args: Any, **kwargs: Any) -> Any:
        """Run a tool by name, forwarding any arguments.

        The model sends `{"name": "catalogue_lookup", "input": {"inci": "Glycerin"}}`.
        The agent turns that into `registry.call("catalogue_lookup", **input)`
        — the dict is unpacked into keyword arguments by the ** operator.
        """
        if name not in self._tools:
            known = ", ".join(sorted(self._tools)) or "none"
            raise ToolError(f"unknown tool {name!r}; known tools: {known}")
        try:
            return self._tools[name](*args, **kwargs)
        except TypeError as exc:           # wrong/missing argument names
            raise ToolError(f"bad arguments for {name!r}: {exc}") from exc

    def to_api(self) -> list[dict[str, Any]]:
        """Every tool in API shape, sorted by name for stable prompts.

        Construct: lambda — `key=lambda t: t.name` is a throwaway function
        that tells sorted() which value to compare. Read it as
        "for each tool t, sort by t.name".
        """
        return [t.to_api() for t in sorted(self._tools.values(), key=lambda t: t.name)]

    # ---------------------------------------------------------------- dict-like feel
    def __getitem__(self, name: str) -> Tool:
        return self._tools[name]

    def __contains__(self, name: object) -> bool:
        return name in self._tools

    def __iter__(self) -> Iterator[Tool]:
        return iter(self._tools.values())

    def __len__(self) -> int:
        return len(self._tools)

    @property
    def names(self) -> list[str]:
        return sorted(self._tools)


def as_text(value: Any) -> str:
    """Tool results travel back to the model as text. Dicts/lists become JSON."""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, indent=2)
