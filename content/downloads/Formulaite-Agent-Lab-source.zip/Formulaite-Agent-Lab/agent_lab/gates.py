"""
gates.py — deterministic gates: plain Python checks that decide whether the
drawer the model produced is acceptable. No model involved.

Why this exists
---------------
A model can be confidently wrong. The gate is the part of the system that does
NOT guess: it compares the drawer against the catalogue and against fixed
rules, and returns PASS/FAIL with reasons. When it fails, the agent sends the
reasons back to the model and asks for a corrected drawer — Anthropic calls
this the evaluator-optimizer pattern.

Python constructs you will meet in this file
--------------------------------------------
* functions as values ..... each check is a function stored in a list; we loop
                            over the list and call each one.
* a list comprehension that collects failure reasons.
* a frozen dataclass ...... an immutable verdict object.
* keyword-only parameters . `def run_gates(drawer, *, catalogue_entry)`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable

from .drawer import IngredientDrawer

# Words that would turn a formulation note into an unsupported claim.
FORBIDDEN_CLAIMS = ("cures", "guaranteed", "clinically proven", "100% safe", "miracle")

# A check receives the drawer + catalogue entry and returns a reason string
# when it fails, or None when it passes.  Construct: a type alias for a callable.
Check = Callable[[IngredientDrawer, dict[str, Any]], str | None]


@dataclass(frozen=True)
class GateVerdict:
    """Construct: frozen=True makes instances immutable — a verdict is a record,
    not something later code should quietly edit."""

    passed: bool
    reasons: tuple[str, ...] = ()

    def __bool__(self) -> bool:      # lets you write `if verdict:`
        return self.passed


# ----------------------------------------------------------------- the checks
def check_all_sections_filled(drawer: IngredientDrawer, entry: dict[str, Any]) -> str | None:
    missing = drawer.missing()
    return f"missing sections: {', '.join(missing)}" if missing else None


def check_inci_matches(drawer: IngredientDrawer, entry: dict[str, Any]) -> str | None:
    if entry and drawer.inci_name.strip().lower() != entry["inci"].lower():
        return f"inci_name {drawer.inci_name!r} does not match catalogue {entry['inci']!r}"
    return None


def check_use_level_in_range(drawer: IngredientDrawer, entry: dict[str, Any]) -> str | None:
    if not entry or drawer.use_level_pct is None:
        return None
    lo, hi = entry["use_level_min"], entry["use_level_max"]
    if not (lo <= drawer.use_level_pct <= hi):
        return f"use_level_pct {drawer.use_level_pct}% is outside catalogue range {lo}-{hi}%"
    return None


def check_not_banned(drawer: IngredientDrawer, entry: dict[str, Any]) -> str | None:
    if entry and entry.get("banned"):
        return f"{entry['inci']} is on the Formulaite banned list — drawer must not be filled"
    return None


def check_has_sources(drawer: IngredientDrawer, entry: dict[str, Any]) -> str | None:
    return None if drawer.sources else "no sources listed — every drawer needs at least one"


def check_no_forbidden_claims(drawer: IngredientDrawer, entry: dict[str, Any]) -> str | None:
    text = " ".join(
        str(getattr(drawer, name)) for name in drawer.REQUIRED_SECTIONS if name != "sources"
    ).lower()
    hits = [w for w in FORBIDDEN_CLAIMS if re.search(r"\b" + re.escape(w) + r"\b", text)]
    return f"forbidden claim words: {', '.join(hits)}" if hits else None


# The order matters only for readability of the reasons list.
DEFAULT_CHECKS: tuple[Check, ...] = (
    check_all_sections_filled,
    check_inci_matches,
    check_not_banned,
    check_use_level_in_range,
    check_has_sources,
    check_no_forbidden_claims,
)


def run_gates(
    drawer: IngredientDrawer,
    *,
    catalogue_entry: dict[str, Any] | None = None,
    checks: tuple[Check, ...] = DEFAULT_CHECKS,
) -> GateVerdict:
    """Run every check; PASS only if none of them returns a reason.

    Construct: keyword-only parameters after `*` — you must write
    run_gates(drawer, catalogue_entry=entry). This prevents the classic bug
    of passing arguments in the wrong order.

    Construct: list comprehension + the "walrus" operator `:=` (Python 3.8+).
    `(reason := check(drawer, entry))` calls the check AND stores its result
    in `reason` in one go, so we can test it in the `if` and keep it in the
    list without calling the check twice. Read it as:
    "for each check, run it; if it returned a reason, keep that reason".
    """
    entry = catalogue_entry or {}
    reasons = [reason for check in checks if (reason := check(drawer, entry)) is not None]
    return GateVerdict(passed=not reasons, reasons=tuple(reasons))
