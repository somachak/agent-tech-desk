"""
drawer.py — the Ingredient Drawer: the fixed set of sections the agent must fill.

Why this exists
---------------
The agent's *job* is not "chat about glycerin"; it is "fill these exact
sections". Making the target a dataclass gives us three things at once:
a schema for the model (via `as_tool_schema`), a validation surface for the
gate (`missing()`), and a plain object the app can render.

Python constructs you will meet in this file
--------------------------------------------
* @dataclass with defaults and `field(default_factory=list)`.
* class-level constants (REQUIRED_SECTIONS) shared by every instance.
* a @classmethod that builds the object from **kwargs sent by the model.
* list comprehensions that filter fields.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields, asdict
from typing import Any


@dataclass
class IngredientDrawer:
    """The fixed sections of one ingredient card in Formulaite.

    Every section is a short human-readable string except `sources`, which
    lists the tools/pages the facts came from (the gate checks this — no
    source, no pass).
    """

    inci_name: str = ""
    function: str = ""
    typical_use_level: str = ""      # e.g. "2-5% (leave-on), up to 10% (rinse-off)"
    use_level_pct: float | None = None  # ONE representative number, used by the gate
    phase_and_solubility: str = ""
    ph_range: str = ""
    compatibility: str = ""
    safety_notes: str = ""
    sources: list[str] = field(default_factory=list)

    # Sections that must be non-empty before the drawer is accepted.
    REQUIRED_SECTIONS = (
        "inci_name",
        "function",
        "typical_use_level",
        "use_level_pct",
        "phase_and_solubility",
        "ph_range",
        "compatibility",
        "safety_notes",
        "sources",
    )

    # ---------------------------------------------------------------- building
    @classmethod
    def from_model_input(cls, **sections: Any) -> "IngredientDrawer":
        """Build a drawer from whatever the model sent in its tool_use input.

        Construct: **sections. The model's JSON becomes keyword arguments.
        We keep only names the dataclass knows (a dict comprehension with a
        filter) so an unexpected extra key cannot crash the run.
        """
        known = {f.name for f in fields(cls)}          # set comprehension
        clean = {k: v for k, v in sections.items() if k in known}
        if "use_level_pct" in clean and clean["use_level_pct"] is not None:
            clean["use_level_pct"] = float(clean["use_level_pct"])
        return cls(**clean)

    # ---------------------------------------------------------------- inspecting
    def missing(self) -> list[str]:
        """Names of required sections that are still empty."""
        return [name for name in self.REQUIRED_SECTIONS if _is_empty(getattr(self, name))]

    def is_complete(self) -> bool:
        return not self.missing()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    # ---------------------------------------------------------------- schema for the model
    @classmethod
    def as_tool_schema(cls) -> dict[str, Any]:
        """JSON Schema for the `fill_drawer` tool.

        This is Anthropic's recommended 'tool-use as structured output'
        pattern: instead of hoping the model writes valid JSON in prose, we
        define a tool whose input IS the drawer, so the API validates it.
        """
        text = {"type": "string"}
        return {
            "type": "object",
            "properties": {
                "inci_name": text,
                "function": text,
                "typical_use_level": text,
                "use_level_pct": {"type": "number", "description": "One representative % within the typical range"},
                "phase_and_solubility": text,
                "ph_range": text,
                "compatibility": text,
                "safety_notes": text,
                "sources": {"type": "array", "items": text, "description": "Tools/pages the facts came from"},
            },
            "required": list(cls.REQUIRED_SECTIONS),
        }


def _is_empty(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    if isinstance(value, (list, tuple, dict)):
        return len(value) == 0
    return False
