"""
formulaite_tools.py — the concrete tools for the ingredient-research agent.

Three tools, mirroring the real Formulaite agent's needs:

  catalogue_lookup(inci)      -> what we already know about an ingredient
  read_supplier_page(url)     -> the "sensor" layer: read a supplier page (stubbed
                                 here with local text files so the lab is offline)
  fill_drawer(**sections)     -> the *answer* tool: structured output. The model
                                 calls it when it believes the drawer is complete.

Python constructs you will meet in this file
--------------------------------------------
* @registry.tool(...) decorator (defined in tools.py).
* module-level "singleton" data loaded once (the catalogue) with a small
  cache function.
* dict.get with defaults, str methods, pathlib.
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from .drawer import IngredientDrawer
from .tools import ToolRegistry

DATA_DIR = Path(__file__).with_name("data")
PAGES_DIR = DATA_DIR / "pages"

# Map a supplier URL to the stub page on disk. In the real app this is where
# an HTTP fetch + HTML-to-text step would live (the "sensor" layer).
_PAGE_FOR_URL = {
    "https://supplier.example/glycerin": "glycerin.txt",
    "https://supplier.example/coco-glucoside": "coco-glucoside.txt",
    "https://supplier.example/xanthan-gum": "xanthan-gum.txt",
    "https://supplier.example/phenoxyethanol": "phenoxyethanol.txt",
    "https://supplier.example/mit": "mit.txt",
}


@lru_cache(maxsize=1)
def load_catalogue() -> dict[str, dict[str, Any]]:
    """Read data/catalogue.json once and cache it.

    Construct: @lru_cache — a decorator from the standard library that
    remembers the result of a function call. maxsize=1 because there is only
    one catalogue; the second call returns instantly without touching disk.
    """
    data = json.loads((DATA_DIR / "catalogue.json").read_text())
    return data["ingredients"]


def catalogue_entry(inci: str) -> dict[str, Any] | None:
    """Case-insensitive lookup; returns None when unknown."""
    return load_catalogue().get(inci.strip().lower())


def build_registry() -> ToolRegistry:
    """Create the registry with all three tools attached.

    We build it inside a function (not at import time) so tests can create
    a fresh registry each time and nothing global leaks between runs.
    """
    registry = ToolRegistry()

    @registry.tool(
        description=(
            "Look up an ingredient by INCI name in the Formulaite catalogue. "
            "Returns function, typical use-level range, phase, solubility, pH range, "
            "supplier page URL and whether it is banned. Returns an error string if unknown."
        )
    )
    def catalogue_lookup(inci: str) -> dict[str, Any] | str:
        entry = catalogue_entry(inci)
        if entry is None:
            return f"ERROR: {inci!r} is not in the catalogue. Known: {', '.join(sorted(load_catalogue()))}"
        return entry

    @registry.tool(
        description=(
            "Read a supplier product page and return its plain text. "
            "Use the supplier_url returned by catalogue_lookup."
        )
    )
    def read_supplier_page(url: str) -> str:
        page = _PAGE_FOR_URL.get(url.strip())
        if page is None:
            return f"ERROR: page not found for {url!r}"
        return (PAGES_DIR / page).read_text()

    @registry.tool(
        description=(
            "Submit the completed Ingredient Drawer. Call this ONLY when every section "
            "is filled from the catalogue and the supplier page. If the gate rejects it, "
            "you will receive the reasons and may call it again."
        ),
        input_schema=IngredientDrawer.as_tool_schema(),
    )
    def fill_drawer(**sections: Any) -> IngredientDrawer:
        # The agent intercepts this tool (see agent.py) so it can run the gate;
        # the function itself just shapes the data.
        return IngredientDrawer.from_model_input(**sections)

    return registry


# The name the agent treats specially — the "I'm done" signal.
ANSWER_TOOL = "fill_drawer"
