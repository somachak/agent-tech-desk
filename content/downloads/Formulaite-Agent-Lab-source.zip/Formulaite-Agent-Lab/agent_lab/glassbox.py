"""
glassbox.py — the Glass Box: a recorder that captures every step of an agent run
so you can replay it afterwards and see exactly what happened and why.

Why this exists
---------------
An agent is a loop that keeps making decisions (call a tool? answer? retry?).
If you can't see those decisions, you can't debug or trust the agent.
The Glass Box is the "flight recorder": every model reply, every tool call,
every gate verdict lands here as one Event.

Python constructs you will meet in this file
--------------------------------------------
* @dataclass ............ a class that is mostly "a bag of fields"; Python writes
                          __init__, __repr__ and __eq__ for you.
* *tags / **meta ........ a function that accepts ANY number of extra positional
                          values (tags) and ANY number of extra key=value pairs (meta).
* a generator (yield) ... a function that hands back one item at a time instead of
                          building a whole list — perfect for "replay the run".
* @property ............. a method you read like an attribute (box.steps, not box.steps()).
* __len__ / __iter__ .... "dunder" methods that let len(box) and `for e in box` work.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator


@dataclass
class Event:
    """One recorded moment in a run.

    Construct: @dataclass. We declare the fields with type hints and Python
    generates the boilerplate (__init__ etc.). `field(default_factory=dict)`
    is how you give a dataclass a *fresh* empty dict per instance — never write
    `meta: dict = {}` (that one dict would be shared by every Event!).
    """

    step: int
    kind: str                      # e.g. "model_reply", "tool_call", "gate"
    tags: tuple[str, ...] = ()     # free-form labels, e.g. ("glycerin", "uk")
    meta: dict[str, Any] = field(default_factory=dict)
    at: str = ""                   # ISO timestamp, filled in by GlassBox.log

    def as_line(self) -> str:
        """A compact one-line view used by the CLI printer."""
        tag_txt = " ".join(f"#{t}" for t in self.tags)
        meta_txt = ", ".join(f"{k}={_short(v)}" for k, v in self.meta.items())
        return f"[{self.step:02d}] {self.kind:<12} {tag_txt} {meta_txt}".rstrip()


def _short(value: Any, limit: int = 70) -> str:
    """Trim long values so a trace line stays readable."""
    text = json.dumps(value, ensure_ascii=False) if not isinstance(value, str) else value
    text = " ".join(text.split())          # collapse newlines/extra spaces into one line
    return text if len(text) <= limit else text[: limit - 1] + "…"


class GlassBox:
    """Flight recorder for one agent run.

    Usage::

        box = GlassBox(run_id="glycerin-001")
        box.log("tool_call", "glycerin", tool="catalogue_lookup", ok=True)
        for event in box.replay():      # generator: one event at a time
            print(event.as_line())
    """

    def __init__(self, run_id: str) -> None:
        self.run_id = run_id
        self._events: list[Event] = []      # leading underscore = "internal, please use the methods"

    # ------------------------------------------------------------------ recording
    def log(self, kind: str, *tags: str, **meta: Any) -> Event:
        """Record one event.

        Construct: *tags collects extra positional arguments into a tuple;
        **meta collects extra keyword arguments into a dict.  So this call::

            box.log("gate", "glycerin", "retry", passed=False, reasons=["…"])

        arrives as  kind="gate", tags=("glycerin", "retry"),
                    meta={"passed": False, "reasons": ["…"]}.
        The caller never has to know the exact fields in advance — that is
        exactly what a trace recorder needs, because every step is different.
        """
        event = Event(
            step=len(self._events) + 1,
            kind=kind,
            tags=tags,
            meta=meta,
            at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )
        self._events.append(event)
        return event

    # ------------------------------------------------------------------ reading
    def replay(self) -> Iterator[Event]:
        """Yield events one by one, in order.

        Construct: a generator. The `yield` keyword pauses the function and
        hands one Event to the caller; the caller's for-loop asks for the next
        one when it is ready. Nothing is copied, and a consumer can stop early
        (e.g. "show me events until the first gate failure").
        """
        for event in self._events:
            yield event

    def of_kind(self, kind: str) -> list[Event]:
        """All events of one kind — a list comprehension with a filter."""
        return [e for e in self._events if e.kind == kind]

    @property
    def steps(self) -> int:
        """Construct: @property — read it as `box.steps` with no parentheses."""
        return len(self._events)

    def __len__(self) -> int:          # lets you write len(box)
        return len(self._events)

    def __iter__(self) -> Iterator[Event]:   # lets you write `for e in box:`
        return self.replay()

    # ------------------------------------------------------------------ persistence
    def to_dict(self) -> dict[str, Any]:
        return {"run_id": self.run_id, "events": [asdict(e) for e in self._events]}

    def save(self, path: str | Path) -> Path:
        """Write the trace as JSON so the run can be replayed later (or in the app)."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2, ensure_ascii=False))
        return path

    @classmethod
    def load(cls, path: str | Path) -> "GlassBox":
        """Rebuild a GlassBox from a saved JSON file.

        Construct: @classmethod — receives the class (cls) instead of an
        instance, so it can build and return a new GlassBox. This is the
        standard pattern for 'alternative constructors'.
        """
        data = json.loads(Path(path).read_text())
        box = cls(run_id=data["run_id"])
        # **e unpacks a dict into keyword arguments: Event(step=1, kind="…", …).
        # JSON has no tuples, so tags come back as a list — we restore the tuple.
        box._events = [Event(**{**e, "tags": tuple(e["tags"])}) for e in data["events"]]
        return box
