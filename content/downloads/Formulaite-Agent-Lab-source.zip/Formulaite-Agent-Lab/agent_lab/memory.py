"""
memory.py — working memory: the conversation the model sees on every call.

Why this exists
---------------
A model has no memory between calls. "Memory" in an agent loop is simply the
list of messages we send back each time — the request, the model's replies,
and the tool results. This class keeps that list well-formed (roles alternate
user/assistant, tool results always go in a user turn) so agent.py stays clean.

Python constructs you will meet in this file
--------------------------------------------
* a class wrapping a list, exposing only the operations that make sense.
* __len__ and __iter__ so it feels like a list where that helps.
* a rough token estimate (len(text) // 4) — the cheapest useful budget signal.
"""

from __future__ import annotations

import json
from typing import Any, Iterator


class Conversation:
    """The ordered messages for one run, in Messages-API shape."""

    def __init__(self) -> None:
        self._messages: list[dict[str, Any]] = []

    def add_user(self, text: str) -> None:
        self._messages.append({"role": "user", "content": text})

    def add_assistant(self, blocks: list[dict[str, Any]]) -> None:
        self._messages.append({"role": "assistant", "content": blocks})

    def add_tool_results(self, results: list[dict[str, Any]]) -> None:
        """Tool results are sent back in a *user* turn — that is the API rule."""
        self._messages.append({"role": "user", "content": results})

    def as_api(self) -> list[dict[str, Any]]:
        return list(self._messages)          # a copy, so callers cannot mutate our history

    def token_estimate(self) -> int:
        """~4 characters per token is a fair rule of thumb for English text."""
        return len(json.dumps(self._messages)) // 4

    def __len__(self) -> int:
        return len(self._messages)

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return iter(self._messages)
