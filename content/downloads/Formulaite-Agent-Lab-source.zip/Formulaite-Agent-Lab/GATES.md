# Gates: Formulaite Agent Lab — ingredient-research agent prototype

OWNS: agent_lab/**, tests/**, scripts/**, docs/**, README.md, requirements.txt

Scope: a plain-Python, teachable agent architecture (classes, *args/**kwargs, generators, decorators) that researches one INCI ingredient with tools, passes a deterministic gate, fills the Ingredient-drawer sections, records a Glass Box trace, runs fully offline with a scripted model, and switches to real Claude via the official anthropic SDK with one flag.

- [x] G1: the offline demo runs end to end and fills every required drawer section for Glycerin
  CHECK: python3 scripts/check_offline_run.py Glycerin
  EXPECT: offline run verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=c19b8a1f00175eaa3dcdbef708f7bf9020d9ffde1b150f6805e8907390615eea; exit=0; EXPECT=matched; output-sha256=7dd2c270e4df6148fe4a3f14179cdbdb1789fc1647b087a3757964c176fe7dbb; output-bytes=87; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=99d50009cf29/20 entries

- [x] G2: the deterministic gate fails honestly on a bad drawer (positive control) and passes on a good one
  CHECK: python3 scripts/check_gate_control.py
  EXPECT: gate control verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=680a216d8052c1b880b096b23fe8e55f6d1cdbe5d5fa52e261f0fc20e2ca1fdc; exit=0; EXPECT=matched; output-sha256=7b1d03fafc3470de85e6be1863998634c786e9559c174721bee37b52411d8f0d; output-bytes=103; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=99d50009cf29/20 entries

- [x] G3: the Glass Box trace replays every step in order and is saved as JSON
  CHECK: python3 scripts/check_glassbox.py
  EXPECT: glassbox verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=a64b7f4e43cf17550e0aaf6f3ad3ac61f8ef0e6ac7f07e40ed82936f69d2c39d; exit=0; EXPECT=matched; output-sha256=d5e07c73edfb2ff42c9b2042e2e4b30ce2cced89a6d1ac729de9605ebbed8a52; output-bytes=113; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=99d50009cf29/20 entries

- [x] G4: the unit-test suite is green (stdlib unittest, no network)
  CHECK: python3 -m unittest discover -s tests -v
  EXPECT: /OK\b/
  EVIDENCE: automatic-evidence=v1; definition-sha256=4ed309905a921d311c9138de932b38f4df357346b6382895ed6eb3fa972374c1; exit=0; EXPECT=matched; output-sha256=11bc152fcd403f0697fdd00a96eca1a1a53f90ca05470685bb5a2d4ba423b234; output-bytes=2021; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=99d50009cf29/20 entries

- [x] G5: the real-Claude path uses the official anthropic SDK tool-use contract (tools -> tool_use -> tool_result with tool_use_id) without a live call
  CHECK: python3 scripts/check_claude_contract.py
  EXPECT: claude contract verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=112f801201129d06b6bd603190c2a8519067aa3240dc0a64077864211e5b8d0e; exit=0; EXPECT=matched; output-sha256=928b43d98230faacaf9284b1011c367ab2ae394560252226bb8f09bcb93ddd8f; output-bytes=121; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=99d50009cf29/20 entries

- [x] G6: every one of the 9 attached books exists as Markdown with page count and size recorded
  CHECK: python3 scripts/check_books.py
  EXPECT: books verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=8af24c4137ef55426ce9ac05cc3b129ff01523e4399e7ecfaa2944ba8780cc9b; exit=0; EXPECT=matched; output-sha256=43155dc5dda86fcaeffa127aa61c476845b80584e36034f5535f9bb0d0da2f4d; output-bytes=76; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=99d50009cf29/20 entries

- [x] G7: the visual guide (docs/visual-guide.html) is self-contained, covers the request flow and each Python construct, and opens without external resources
  CHECK: python3 scripts/check_visual_guide.py
  EXPECT: visual guide verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=b5d6d818682ac0c270c66470fdf9e9a291651a998229edaf1e40d3fb1b5206fd; exit=0; EXPECT=matched; output-sha256=bbe57e9a0f3027364e0741d0eed6c4c30da1d58851ecb73f7b02e72fbe4f78f7; output-bytes=85; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=99d50009cf29/20 entries

- [x] G8: the project is saved under ~/Downloads/Formulaite-Agent-Lab on Soma's Mac and the offline demo runs there
  EVIDENCE: 2026-09-07 committed Formulaite-Agent-Lab.tar.gz to /Users/somapym/Downloads; in the desktop VM `python3 -m agent_lab Glycerin --quiet` printed GATE: PASS and `python3 -m unittest discover -s tests` printed OK (Python 3.10.12)
