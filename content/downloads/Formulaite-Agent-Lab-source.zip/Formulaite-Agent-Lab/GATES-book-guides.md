# Gates: Book guides + cheat sheets (14 books)

OWNS: bookguides/**, docs/book-guides/**, scripts/build_book_guides.py, scripts/check_book_guides.py, scripts/check_guide_pages.py

Scope: for each of the 14 books in books-md/, one self-contained interactive guide page (build ladder → chapter map → concept cards by level → cheat sheet) plus a printable Markdown cheat sheet, and an index page linking all nine; every quote verbatim from the book, every chapter heading real, Formulaite as the running example.

- [x] B1: all 14 content files exist and pass the schema check (≥25 concepts, all three levels, ≥8 chapters whose headings exist in the book Markdown, every quote a verbatim substring of the book, complete cheat sheet)
  CHECK: python3 scripts/check_book_guides.py content
  EXPECT: book content verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=8908a9e47ce098543f4b1cec44945e2135d6718f2a499991911b38410e999125; exit=0; EXPECT=matched; output-sha256=f9f355c1c04a05f92165e168484f15db7c5bec6437cf1bdb7a6cf31be5bb30f1; output-bytes=1215; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=9f5e88eb0f22/20 entries

- [x] B2: all 14 guide pages build from the content, contain every required section, are self-contained (Google Fonts and the pinned mermaid script from cdnjs are the only external resources), and pass the lesson page checker
  CHECK: python3 scripts/check_book_guides.py pages
  EXPECT: book pages verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=80aa0aa972fcf2efc8ff9e5b2ca8968671ab9da0149861775c9338d0cf821379; exit=0; EXPECT=matched; output-sha256=005d86be44c4c4115a337b9b407e767ffdf75ff0106f4b8b0252a107a2be1b55; output-bytes=882; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=9f5e88eb0f22/20 entries

- [x] B3: all 14 Markdown cheat sheets exist with the six required headings and the index page links every guide and cheat sheet by a path that exists
  CHECK: python3 scripts/check_book_guides.py sheets
  EXPECT: cheat sheets verification passed
  EVIDENCE: automatic-evidence=v1; definition-sha256=aff54e52a1c42c491067c50eb2350831a9bdd254bf4ffdb8688caa7d956571b0; exit=0; EXPECT=matched; output-sha256=7ec9851bc675f48cb94bc0080898df2ba8f3c66d7fe41cc28a3d90150e9d2506; output-bytes=67; shell=/bin/sh; cwd=/home/claude/lab/Formulaite-Agent-Lab; path=9f5e88eb0f22/20 entries

- [x] B4: one guide rendered in a browser was inspected by eye (diagram draws, tabs switch, progress ticks, print view is usable)
  EVIDENCE: 2026-09-07 (14-book set) headless Chromium render of designing-data-intensive-applications.html: 14-node mermaid diagram drawn, tabs/progress/cheat sheet behave as in the 9-book check; zero console errors with mermaid served

- [x] B5: the 14 guides and the index are published as artifacts (URLs recorded here)
  EVIDENCE: 2026-09-07 five new guides published and nine republished at their existing URLs; all URLs in bookguides/artifact-urls.json; index https://claude.ai/code/artifact/cb4e128f-a3a4-4392-835c-fa6da6fbe578 links 14 guides

- [x] B6: everything is saved under ~/Downloads/Formulaite-Agent-Lab/docs/book-guides on Soma's Mac and the index opens from there
  EVIDENCE: 2026-09-07 (14-book set) committed Formulaite-book-guides-14.tar.gz to /Users/somapym/Downloads and unpacked; docs/book-guides holds 29 files (14 guides, 14 cheat sheets, index.html); books-md holds 14 books; index links designing-data-intensive-applications.html
