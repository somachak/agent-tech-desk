"""
Unit tests for the Formulaite Agent Lab. Standard-library unittest only; no network.

Run:  python3 -m unittest discover -s tests -v
"""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from agent_lab import (
    Agent, ClaudeModel, Conversation, GlassBox, IngredientDrawer, ScriptedModel,
    Tool, ToolError, ToolRegistry, build_registry, catalogue_entry, run_gates,
)


# ----------------------------------------------------------------- glassbox
class GlassBoxTests(unittest.TestCase):
    def test_log_collects_tags_and_meta(self):
        box = GlassBox("t")
        e = box.log("gate", "glycerin", "retry", passed=False, reasons=["x"])
        self.assertEqual(e.kind, "gate")
        self.assertEqual(e.tags, ("glycerin", "retry"))          # *tags -> tuple
        self.assertEqual(e.meta, {"passed": False, "reasons": ["x"]})  # **meta -> dict
        self.assertEqual(e.step, 1)

    def test_replay_is_a_generator_in_order(self):
        box = GlassBox("t")
        for k in ("a", "b", "c"):
            box.log(k)
        gen = box.replay()
        self.assertTrue(hasattr(gen, "__next__"))               # it is an iterator, not a list
        self.assertEqual([e.kind for e in gen], ["a", "b", "c"])
        self.assertEqual(len(box), 3)

    def test_save_and_load_round_trip(self):
        box = GlassBox("rt")
        box.log("x", "tag", n=1)
        with tempfile.TemporaryDirectory() as d:
            path = box.save(Path(d) / "trace.json")
            loaded = GlassBox.load(path)
        self.assertEqual(loaded.run_id, "rt")
        self.assertEqual(loaded.of_kind("x")[0].tags, ("tag",))   # tuple restored from JSON list

    def test_empty_box_is_falsy_but_must_still_be_used(self):
        # Documents the gotcha fixed in agent.py: an empty box has len 0.
        box = GlassBox("empty")
        self.assertFalse(bool(box))
        agent = Agent(ScriptedModel(), build_registry(), glassbox=box)
        self.assertIs(agent.glassbox, box)


# ----------------------------------------------------------------- tools
class ToolTests(unittest.TestCase):
    def test_decorator_registers_and_builds_schema(self):
        reg = ToolRegistry()

        @reg.tool(description="add two numbers")
        def add(a: int, b: int = 1) -> int:
            return a + b

        self.assertIn("add", reg)
        api = reg.to_api()[0]
        self.assertEqual(api["name"], "add")
        self.assertEqual(api["input_schema"]["required"], ["a"])
        self.assertEqual(api["input_schema"]["properties"]["b"], {"type": "integer"})
        self.assertEqual(reg.call("add", a=2, b=3), 5)              # **kwargs pass-through
        self.assertEqual(reg["add"](4), 5)                          # *args pass-through via __call__

    def test_unknown_tool_and_bad_args_raise_toolerror(self):
        reg = build_registry()
        with self.assertRaises(ToolError):
            reg.call("nope")
        with self.assertRaises(ToolError):
            reg.call("catalogue_lookup", wrong="x")

    def test_registry_rejects_duplicate_names(self):
        reg = ToolRegistry(Tool(lambda: 1, name="one"))
        with self.assertRaises(ToolError):
            reg.register(Tool(lambda: 2, name="one"))

    def test_formulaite_tools(self):
        reg = build_registry()
        entry = reg.call("catalogue_lookup", inci="glycerin")
        self.assertEqual(entry["inci"], "Glycerin")
        page = reg.call("read_supplier_page", url=entry["supplier_url"])
        self.assertIn("Glycerin", page)
        self.assertTrue(reg.call("catalogue_lookup", inci="Unobtainium").startswith("ERROR"))
        self.assertTrue(reg.call("read_supplier_page", url="https://nowhere").startswith("ERROR"))


# ----------------------------------------------------------------- drawer + gates
def good_drawer(**overrides):
    base = dict(
        inci_name="Glycerin", function="humectant", typical_use_level="2-5%", use_level_pct=3.0,
        phase_and_solubility="A; water-soluble", ph_range="3-9", compatibility="broad",
        safety_notes="low irritation", sources=["catalogue_lookup"],
    )
    base.update(overrides)
    return IngredientDrawer.from_model_input(**base)


class GateTests(unittest.TestCase):
    def test_good_drawer_passes(self):
        v = run_gates(good_drawer(), catalogue_entry=catalogue_entry("Glycerin"))
        self.assertTrue(v.passed)
        self.assertTrue(v)                                          # __bool__

    def test_positive_controls_fail_for_the_right_reason(self):
        entry = catalogue_entry("Glycerin")
        cases = {
            "missing sections": good_drawer(safety_notes=""),
            "outside catalogue range": good_drawer(use_level_pct=50),
            "no sources": good_drawer(sources=[]),
            "forbidden claim": good_drawer(safety_notes="cures eczema"),
            "does not match": good_drawer(inci_name="Xanthan Gum"),
        }
        for expected, drawer in cases.items():
            with self.subTest(expected):
                v = run_gates(drawer, catalogue_entry=entry)
                self.assertFalse(v.passed)
                self.assertTrue(any(expected in r for r in v.reasons), v.reasons)

    def test_banned_ingredient_fails(self):
        v = run_gates(good_drawer(inci_name="Methylisothiazolinone", use_level_pct=0),
                      catalogue_entry=catalogue_entry("Methylisothiazolinone"))
        self.assertIn("banned", " ".join(v.reasons))

    def test_from_model_input_ignores_unknown_keys(self):
        d = IngredientDrawer.from_model_input(inci_name="Glycerin", surprise="x")
        self.assertEqual(d.inci_name, "Glycerin")
        self.assertIn("function", d.missing())


# ----------------------------------------------------------------- agent loop (offline)
class AgentOfflineTests(unittest.TestCase):
    def test_happy_path(self):
        result = Agent(ScriptedModel(), build_registry(), glassbox=GlassBox("t")).run("Glycerin")
        self.assertTrue(result.ok)
        self.assertEqual(result.drawer.inci_name, "Glycerin")
        kinds = [e.kind for e in result.glassbox]
        self.assertEqual(kinds[0], "request")
        self.assertEqual(kinds[-1], "run_end")
        self.assertEqual(kinds.count("tool_call"), 2)
        self.assertEqual(kinds.count("gate"), 1)

    def test_gate_rejection_then_recovery(self):
        result = Agent(ScriptedModel(fail_first=True), build_registry(), glassbox=GlassBox("t")).run("Glycerin")
        gates = result.glassbox.of_kind("gate")
        self.assertEqual([g.meta["passed"] for g in gates], [False, True])
        self.assertTrue(result.ok)

    def test_banned_and_unknown_stop_honestly(self):
        for inci in ("Methylisothiazolinone", "Unobtainium"):
            with self.subTest(inci):
                result = Agent(ScriptedModel(), build_registry(), glassbox=GlassBox("t")).run(inci)
                self.assertIsNone(result.drawer)
                self.assertFalse(result.ok)
                self.assertTrue(result.final_text)

    def test_step_budget_stops_runaway(self):
        class LoopForever:
            def complete(self, *, system, messages, tools):
                from agent_lab.models import ModelReply, ToolUseBlock
                return ModelReply([ToolUseBlock("catalogue_lookup", {"inci": "Glycerin"})], "tool_use")

        result = Agent(LoopForever(), build_registry(), glassbox=GlassBox("t"), max_steps=3).run("Glycerin")
        self.assertFalse(result.ok)
        self.assertTrue(result.glassbox.of_kind("budget_exhausted"))
        self.assertIn("3 steps", result.final_text)


# ----------------------------------------------------------------- Claude contract (no network)
class FakeAnthropicClient:
    """Mimics `anthropic.Anthropic().messages.create` closely enough to test the
    tool-use contract: tools -> tool_use blocks -> tool_result with tool_use_id."""

    def __init__(self):
        self.requests = []
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kwargs):
        self.requests.append(kwargs)
        n = len(self.requests)
        if n == 1:
            blocks = [SimpleNamespace(type="text", text="Looking up."),
                      SimpleNamespace(type="tool_use", id="toolu_1", name="catalogue_lookup", input={"inci": "Glycerin"})]
            return SimpleNamespace(content=blocks, stop_reason="tool_use")
        if n == 2:
            blocks = [SimpleNamespace(type="tool_use", id="toolu_2", name="read_supplier_page",
                                      input={"url": "https://supplier.example/glycerin"})]
            return SimpleNamespace(content=blocks, stop_reason="tool_use")
        drawer = good_drawer().to_dict()
        blocks = [SimpleNamespace(type="tool_use", id="toolu_3", name="fill_drawer", input=drawer)]
        return SimpleNamespace(content=blocks, stop_reason="tool_use")


class ClaudeContractTests(unittest.TestCase):
    def test_messages_follow_the_tool_use_contract(self):
        fake = FakeAnthropicClient()
        model = ClaudeModel(client=fake, model="claude-test")
        result = Agent(model, build_registry(), glassbox=GlassBox("t")).run("Glycerin")
        self.assertTrue(result.ok)
        self.assertEqual(len(fake.requests), 3)

        first = fake.requests[0]
        self.assertEqual(first["model"], "claude-test")
        self.assertEqual({t["name"] for t in first["tools"]}, {"catalogue_lookup", "read_supplier_page", "fill_drawer"})
        for t in first["tools"]:
            self.assertEqual(set(t), {"name", "description", "input_schema"})

        second = fake.requests[1]["messages"]
        self.assertEqual([m["role"] for m in second], ["user", "assistant", "user"])
        tool_result = second[2]["content"][0]
        self.assertEqual(tool_result["type"], "tool_result")
        self.assertEqual(tool_result["tool_use_id"], "toolu_1")        # echoes the tool_use id
        self.assertIn("Glycerin", tool_result["content"])

        third = fake.requests[2]["messages"]
        self.assertEqual(third[4]["content"][0]["tool_use_id"], "toolu_2")


class ConversationTests(unittest.TestCase):
    def test_roles_and_copy(self):
        c = Conversation()
        c.add_user("hi")
        c.add_assistant([{"type": "text", "text": "yo"}])
        c.add_tool_results([{"type": "tool_result", "tool_use_id": "x", "content": "1"}])
        api = c.as_api()
        self.assertEqual([m["role"] for m in api], ["user", "assistant", "user"])
        api.clear()
        self.assertEqual(len(c), 3)                                 # as_api returned a copy
        self.assertGreater(c.token_estimate(), 0)


if __name__ == "__main__":
    unittest.main()
